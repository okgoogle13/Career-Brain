# Getting Started with Enhanced Resume Agent 3.0 (FastAPI + Static Front-End Edition)

This guide is written for absolute beginners. It assumes **zero coding background**, a **Chromebook (Linux enabled)** or any browser-based Cloud Shell, and the official Google Cloud Run deployment recipe.

---
## 1. What You Will Build
Enhanced Resume Agent 3.0 is an AI assistant that
1. Scores your resume against any job description or job-ad link
2. Automatically performs company research
3. Generates:  
   • a tailored resume  
   • a custom cover letter  
   • Key Selection Criteria (KSC) answers (for AU government roles)
4. Stores every resume you upload so it gets smarter next time

The system now has two parts:
• **Backend** – FastAPI (Python) that does the heavy AI work.  
• **Front-End** – Simple HTML + CSS + JavaScript served **from the same container** so you click one URL and everything loads.

---
## 2. Files & Folders (high-level)
```
resume-agent-3.0/
├── src/
│   ├── api/                 # FastAPI backend
│   │   ├── main.py          # App entry-point  ← start here
│   │   └── endpoints/
│   │       ├── job.py       # JD paste / URL scrape
│   │       ├── resume.py    # upload / score / store
│   │       └── docs.py      # generate tailored docs (sequential)
│   ├── frontend/            # Static single-page web app
│   │   ├── index.html       # UI layout
│   │   ├── style.css        # colours & fonts
│   │   └── script.js        # fetch() calls to FastAPI
│   └── ...                  # existing business logic (unchanged)
├── Dockerfile               # container build (exposes 8080)
├── requirements.txt         # Python libs (streamlit removed)
├── scripts/
│   └── deploy_cloud_run.sh  # 1-click deploy (max-instances 1)
└── README.md (updated)
```

*(Full source tree is inside this zip → **Enhanced-Resume-Agent-3.0.zip**)*

---
## 3. One-Time Setup (Chromebook + Linux)
### 3.1 Enable Linux (if not already)
Settings → Developers → **Turn On** Linux. Allocate ≥4 GB.

### 3.2 Install prerequisites
```bash
# inside the Linux terminal
sudo apt update && sudo apt install -y python3.11 python3.11-venv git docker.io
sudo usermod -aG docker $USER  # log out/in to activate
```

### 3.3 Clone the repository
```bash
git clone https://github.com/<your-fork>/resume-agent-3.0.git
cd resume-agent-3.0
```

### 3.4 Create a Python environment
```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

---
## 4. Local Test Run
```bash
# still inside the project root
uvicorn src.api.main:app --reload --port 8000
```
Open http://localhost:8000 in your browser.  
You should see the **Resume Scorer** page.

---
## 5. Upload Your API Keys
1. Copy `.env.example` → `.env`
2. Paste your keys:
```
GOOGLE_GEMINI_API_KEY="paste-key-here"
PERPLEXITY_API_KEY="paste-key-here"
```
*(These stay on your machine; Cloud Run uses Secret Manager – see deployment script)*

---
## 6. Using the App
### 6.1 Score a Resume
1. Paste the **Job Description** *or* **full job-listing URL**.  
2. Upload your **resume PDF / DOCX / TXT**.  
3. Click **Score My Resume**.

Behind the scenes:
• If you gave a URL, the backend scrapes the page and extracts role info + KSC.  
• Your resume text is parsed, vectorised, and stored for future jobs.

### 6.2 Generate Tailored Docs (sequential)
1. Click **Generate Tailored Resume** → download appears.  
2. App asks: *Generate cover letter too?* → Yes to proceed.  
3. App asks: *Generate KSC responses?* (only if criteria detected).  
   • You may upload past KSC docs here to teach the model.

Your new documents are saved and also added to history so next time is faster.

---
## 7. Deploy to Google Cloud Run (Option A)
```bash
export GOOGLE_CLOUD_PROJECT="my-gcp-project"
chmod +x scripts/deploy_cloud_run.sh
./scripts/deploy_cloud_run.sh
```
The script will:
1. Build a Docker image
2. Push to Google Artifact Registry
3. Deploy a single instance (no auto-scaling) on Cloud Run
4. Print a public HTTPS URL

> FIRST-TIME ONLY – create the two secrets:
```bash
gcloud secrets create gemini-api-key --data-file=- <<<"<YOUR-GEMINI-KEY>"
gcloud secrets create perplexity-api-key --data-file=- <<<"<YOUR-PERPLEXITY-KEY>"
```

---
## 8. Optional Mobile App (Android Studio)
If you want a mobile wrapper:
1. In Android Studio → *New Project → Empty Activity*.
2. Add a `WebView` pointing to your Cloud Run URL.
3. Enable “Uploads” in WebView settings so the file-picker works.

No backend changes required – it’s just the same web app inside a native shell.

---
## 9. Backup & Restore
Create an archive of **all** personal data (SQLite + vector DB + docs):
```bash
./scripts/backup.sh
```
A dated `.tar.gz` file is stored under `~/.resume_agent_backups`.

---
## 10. Troubleshooting
| Problem | Quick Fix |
|---------|-----------|
| `ModuleNotFoundError` | `source .venv/bin/activate` then `pip install -r requirements.txt` |
| Cannot open `localhost:8000` | Check the terminal – do you see `Uvicorn running?` |
| `403` on Cloud Run | Make sure the service is **unauthenticated** or add IAM binding. |
| No Gemini response | Verify secret value; check Google Cloud “Generative Language API” quota. |

---
## 11. Next Steps
• Customise CSS in `src/frontend/style.css` for your own branding.  
• Add more endpoints in `src/api/endpoints/…` – FastAPI auto-docs appear at `/docs`.  
• If you ever need multi-device sync, enable Firebase Auth + Firestore (instructions in `/docs/firebase.md`).

Happy job-hunting! 🎉
