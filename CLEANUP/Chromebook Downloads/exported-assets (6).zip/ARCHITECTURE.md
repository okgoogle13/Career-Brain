# Architecture – Personal Edition

This architecture document describes *how* the Enhanced Resume Agent 3.0 operates when it is used by **a single individual** on their own machine or personal cloud project.

The core workflow (Input → Analysis → Company Research → Document Generation → QA → Review) remains **unchanged**, but all infrastructure choices are simplified:

| Layer | Original Design (Multi-tenant) | Personal Edition |
|-------|---------------------------------|------------------|
| **Compute** | Google Cloud Run (autoscale 0-5) | Cloud Run **maxInstances=1** *or* local Docker |
| **Database** | Cloud SQL (Postgres) | **SQLite** file (`~/.resume_agent/data.sqlite`) |
| **Vector Store** | Managed ChromaDB cluster | **Embedded ChromaDB** inside app process |
| **Auth** | Firebase Authentication | **None** – the app is private to one user |
| **Secrets** | Secret Manager, IAM roles | `.env` file or shell variables |
| **CI/CD** | Build → Test → Scan → Deploy | Build → Test → Scan (deploy optional) |

Because concurrency is limited to one active session, we can discard:

- Load balancer configuration
- Auto-scaling policies
- Multi-region replication
- Role-based access controls

## Component Diagram

```
┌─────────────┐        ┌─────────────────┐
│  Streamlit  │        │   CLI (Typer)   │
└──────┬──────┘        └───────┬─────────┘
       │ HTTP / CLI Calls             │
┌──────▼────────━━━ Personal Logic ━━━▼──────┐
│  Orchestrator  ───► Agents ◄── Integrations │
│                ┌──────────┐                │
│                │ ChromaDB │ (in-proc)      │
│                └───┬──────┘                │
│                    │                        │
│                SQLite DB                    │
└──────────────────────────────────────────────┘
```

All components run **within a single Python process** (or Docker container).  Memory footprint remains low and latency is minimized.

## Deployment Options

1. **Local:** `make run-web` – launches Streamlit with hot-reload.
2. **Docker:** `make docker-run` – bundles everything; great for Windows/macOS.
3. **Cloud Run (single instance):**
   ```bash
   make docker-build
   gcloud run deploy resume-agent \
      --source . \
      --max-instances 1 \
      --platform managed \
      --region YOUR_REGION
   ```

> **Tip**: Leaving `max-instances` at **1** guarantees zero scaling surprises and keeps the free tier usage low.

## Scaling Considerations

None.  This edition is architected exclusively for **one user**.  If concurrent usage or team sharing becomes a requirement, migrate to the multi-tenant architecture blueprint (see `/docs/multi_user_upgrade.md`).

---

© 2025 – Single-user license.  Redistribution or SaaS hosting is prohibited without consent.