# Enhanced Resume Agent 3.0 – **Personal Edition**

Welcome! This repository contains the **personal, single-user** version of the Enhanced Resume Agent 3.0.  All code, configuration, and documentation have been streamlined for one individual (Nishant Dougall) running the system on their own computer or personal Google Cloud account.

> **Note**
> • Multi-user features, tenancy controls, and horizontal scaling have **been intentionally removed or disabled**.
> • The deployment scripts assume **one active user** at any time, so there are *no scalability or concurrency concerns* to plan for.

---

## Quick Start (One-User Scenario)

1. **Clone the repo**
   ```bash
   git clone https://github.com/your-fork/resume-agent.git && cd resume-agent
   ```
2. **Install requirements** (creates an isolated virtual environment)
   ```bash
   make install   # or  pip install -r requirements.txt
   ```
3. **Set your personal API keys**
   ```bash
   export GEMINI_API_KEY="..."      # Google Gemini 2.5 Pro
   export PERPLEXITY_API_KEY="..."  # Perplexity API
   ```
4. **Launch the interface of your choice**
   ```bash
   make run-web   # Streamlit (http://localhost:8501)
   #-or-
   python -m resume_agent.cli  # Command-line interface
   ```

That’s all!  Because only a single user is expected, default settings use a local SQLite database and in-memory ChromaDB instance.  Resource usage remains minimal (<1 GB RAM and <0.5 vCPU typical).

---

## Personal Deployment Options

| Environment      | Command                                   | Notes |
|------------------|-------------------------------------------|-------|
| **Local laptop** | `make run-web`                            | Best for everyday use; saves everything in `~/.resume_agent/`. |
| **Docker**       | `make docker-run`                         | Encapsulates dependencies; still single-user. |
| **Google Cloud** | `make deploy-cloud-run`                   | Creates one Cloud Run service; no load balancer or autoscaling needed. |

Cloud Run settings force **max instances = 1** to prevent unintended scaling and additional costs.

---

## What’s Inside (Simplified for One User)

- `src/` – Core application logic (agents, integrations, utils)
- `web/streamlit_app.py` – Streamlit UI
- `config/local.yaml` – Pre-tuned defaults for a single user
- `templates/` – Jinja2 resume, cover letter, and KSC templates
- `scripts/backup_local.sh` – Exports your documents to a dated ZIP for safekeeping

---

## Frequently Asked Questions

**Q. Can a friend also log in?**  
A. Not simultaneously.  This edition stores data in local files bound to your user account.  For shared or team use, see the multi-user edition (road-mapped).

**Q. What happens if my laptop is offline?**  
A. The application will still run, but API calls to Gemini or Perplexity will fail.  You can draft content offline and regenerate once connectivity returns.

**Q. Do I need to worry about traffic spikes?**  
A. No.  All endpoints are private, and only you will call them.

---

## Support & Updates

Because this is a personal project, support is self-service.  Open an issue only if you find a reproducible bug.  Pull requests are welcome but reviewed at my discretion.

---

© 2025 Nishant Dougall — Personal Use Only