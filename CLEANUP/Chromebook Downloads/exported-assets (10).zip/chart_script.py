import plotly.graph_objects as go
import plotly.express as px
import numpy as np
import json

# Define the components and their positions for the architecture diagram
components = {
    'Frontend': {'x': 1, 'y': 6, 'color': '#1FB8CD'},
    'FastAPI Backend': {'x': 3, 'y': 4, 'color': '#FFC185'},
    'AI Integration': {'x': 5, 'y': 6, 'color': '#ECEBD5'},
    'Data Storage': {'x': 5, 'y': 2, 'color': '#5D878F'},
    'Document Processing': {'x': 1, 'y': 2, 'color': '#D2BA4C'},
    'Cloud Deployment': {'x': 3, 'y': 8, 'color': '#B4413C'}
}

# Define connections between components
connections = [
    {'from': 'Frontend', 'to': 'FastAPI Backend'},
    {'from': 'FastAPI Backend', 'to': 'AI Integration'},
    {'from': 'FastAPI Backend', 'to': 'Data Storage'},
    {'from': 'FastAPI Backend', 'to': 'Document Processing'},
    {'from': 'Cloud Deployment', 'to': 'FastAPI Backend'},
    {'from': 'Cloud Deployment', 'to': 'Frontend'}
]

# Create the figure
fig = go.Figure()

# Add connection lines
for conn in connections:
    from_comp = components[conn['from']]
    to_comp = components[conn['to']]
    
    fig.add_trace(go.Scatter(
        x=[from_comp['x'], to_comp['x']],
        y=[from_comp['y'], to_comp['y']],
        mode='lines',
        line=dict(color='#13343B', width=2),
        showlegend=False,
        hoverinfo='skip',
        cliponaxis=False
    ))

# Add component nodes
for name, props in components.items():
    # Abbreviate long names for the 15 character limit
    display_name = name
    if len(name) > 15:
        if name == 'FastAPI Backend':
            display_name = 'FastAPI'
        elif name == 'AI Integration':
            display_name = 'AI Layer'
        elif name == 'Document Processing':
            display_name = 'Doc Process'
        elif name == 'Cloud Deployment':
            display_name = 'Cloud Deploy'
    
    fig.add_trace(go.Scatter(
        x=[props['x']],
        y=[props['y']],
        mode='markers',
        marker=dict(
            size=80,
            color=props['color'],
            line=dict(color='#13343B', width=3)
        ),
        name=display_name,
        hovertemplate=f'<b>{display_name}</b><extra></extra>',
        cliponaxis=False
    ))

# Update layout
fig.update_layout(
    title='Resume Agent 3.0 Architecture',
    xaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[0, 6]
    ),
    yaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[0, 9]
    ),
    legend=dict(
        orientation='h',
        yanchor='bottom',
        y=1.05,
        xanchor='center',
        x=0.5
    ),
    plot_bgcolor='white'
)

# Save the chart
fig.write_image('architecture_diagram.png')
fig.show()