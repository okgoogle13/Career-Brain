import plotly.graph_objects as go
import plotly.express as px
import numpy as np

# Define the workflow data
workflow_data = {
    "workflow_steps": ["Input Job Info", "Upload Resumes", "Parse Documents", "Select Theme", "Generate Resume", "Generate Cover Letter", "Generate KSC", "AI Processing"],
    "decision_points": ["Job URL vs Description", "Theme Selection", "Add More Documents"],
    "outputs": ["Tailored Resume", "Tailored Cover Letter", "KSC Responses"]
}

# Create figure
fig = go.Figure()

# Define positions for workflow steps
steps = [
    {"name": "Input Job Info", "x": 1, "y": 8, "type": "input"},
    {"name": "Job URL vs Desc", "x": 1, "y": 7, "type": "decision"},
    {"name": "Upload Resumes", "x": 1, "y": 6, "type": "process"},
    {"name": "Parse Docs", "x": 1, "y": 5, "type": "process"},
    {"name": "Select Theme", "x": 1, "y": 4, "type": "decision"},
    {"name": "Gen Resume", "x": 0.5, "y": 3, "type": "output"},
    {"name": "Gen Cover Ltr", "x": 1, "y": 3, "type": "output"},
    {"name": "Gen KSC", "x": 1.5, "y": 3, "type": "output"},
    {"name": "AI Processing", "x": 1, "y": 2, "type": "ai"},
    {"name": "Gemini API", "x": 0.5, "y": 1, "type": "ai"},
    {"name": "Perplexity API", "x": 1, "y": 1, "type": "ai"},
    {"name": "ChromaDB", "x": 1.5, "y": 1, "type": "ai"}
]

# Define colors for different types
colors = {
    "input": "#1FB8CD",
    "decision": "#FFC185", 
    "process": "#ECEBD5",
    "output": "#5D878F",
    "ai": "#D2BA4C"
}

# Add workflow steps as scatter points
for step in steps:
    fig.add_trace(go.Scatter(
        x=[step["x"]],
        y=[step["y"]],
        mode='markers+text',
        marker=dict(
            size=50,
            color=colors[step["type"]],
            line=dict(width=2, color='white')
        ),
        text=step["name"],
        textposition="middle center",
        textfont=dict(size=10, color='black'),
        showlegend=False,
        hoverinfo='text',
        hovertext=f'{step["name"]}<br>Type: {step["type"]}',
        cliponaxis=False
    ))

# Add arrows to show flow
arrows = [
    (1, 8, 1, 7),  # Input to Decision
    (1, 7, 1, 6),  # Decision to Upload
    (1, 6, 1, 5),  # Upload to Parse
    (1, 5, 1, 4),  # Parse to Theme
    (1, 4, 0.5, 3), # Theme to Resume
    (1, 4, 1, 3),   # Theme to Cover Letter
    (1, 4, 1.5, 3), # Theme to KSC
    (0.5, 3, 1, 2), # Resume to AI
    (1, 3, 1, 2),   # Cover Letter to AI
    (1.5, 3, 1, 2), # KSC to AI
    (1, 2, 0.5, 1), # AI to Gemini
    (1, 2, 1, 1),   # AI to Perplexity
    (1, 2, 1.5, 1)  # AI to ChromaDB
]

# Add arrows as lines
for i, arrow in enumerate(arrows):
    fig.add_trace(go.Scatter(
        x=[arrow[0], arrow[2]],
        y=[arrow[1], arrow[3]],
        mode='lines',
        line=dict(color='gray', width=2),
        showlegend=False,
        hoverinfo='skip',
        cliponaxis=False
    ))

# Create legend manually
legend_items = [
    {"name": "Input", "color": "#1FB8CD"},
    {"name": "Decision", "color": "#FFC185"},
    {"name": "Process", "color": "#ECEBD5"},
    {"name": "Output", "color": "#5D878F"},
    {"name": "AI Service", "color": "#D2BA4C"}
]

for i, item in enumerate(legend_items):
    fig.add_trace(go.Scatter(
        x=[None],
        y=[None],
        mode='markers',
        marker=dict(size=15, color=item["color"]),
        name=item["name"],
        showlegend=True
    ))

# Update layout
fig.update_layout(
    title="Enhanced Resume Agent 3.0 Workflow",
    xaxis=dict(
        range=[-0.5, 2.5],
        showgrid=False,
        showticklabels=False,
        zeroline=False
    ),
    yaxis=dict(
        range=[0, 9],
        showgrid=False,
        showticklabels=False,
        zeroline=False
    ),
    legend=dict(
        orientation='h',
        yanchor='bottom',
        y=1.05,
        xanchor='center',
        x=0.5
    ),
    showlegend=True,
    plot_bgcolor='white'
)

# Save the chart
fig.write_image("resume_agent_workflow.png")