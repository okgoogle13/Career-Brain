# Enhanced Resume Agent 3.0 - FastAPI Main Application
# File: src/api/main.py

from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Depends
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import uvicorn
import logging
import os
from datetime import datetime
import json

# Import custom modules
from src.services.job_scraper import JobScrapingService
from src.services.resume_parser import ResumeParsingService
from src.services.document_generator import DocumentGenerationService
from src.services.theme_manager import ThemeManager
from src.services.workflow_engine import WorkflowEngine
from src.data.database import DatabaseManager
from src.integrations.gemini_client import GeminiClient
from src.integrations.perplexity_client import PerplexityClient
from src.api.middleware.security import SecurityMiddleware
from src.api.utils.responses import StandardResponse
from src.api.utils.exceptions import APIException

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Enhanced Resume Agent 3.0",
    description="AI-powered career document generation system with FastAPI backend and static frontend",
    version="3.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add security middleware
app.add_middleware(SecurityMiddleware)

# Initialize services
db_manager = DatabaseManager()
job_scraper = JobScrapingService()
resume_parser = ResumeParsingService()
document_generator = DocumentGenerationService()
theme_manager = ThemeManager()
workflow_engine = WorkflowEngine()
gemini_client = GeminiClient()
perplexity_client = PerplexityClient()

# Pydantic models for request/response
class JobInputRequest(BaseModel):
    job_description: Optional[str] = None
    job_url: Optional[str] = None
    user_id: str

class JobAnalysisResponse(BaseModel):
    job_title: str
    company: str
    location: str
    key_requirements: List[str]
    key_selection_criteria: List[str]
    salary_range: Optional[str] = None
    job_type: str
    description: str
    scraped_data: Dict[str, Any]

class ResumeUploadResponse(BaseModel):
    resume_id: str
    extracted_data: Dict[str, Any]
    parsing_success: bool
    message: str

class ThemeSelectionRequest(BaseModel):
    theme_name: str
    user_id: str

class DocumentGenerationRequest(BaseModel):
    document_type: str  # 'resume', 'cover_letter', 'ksc'
    job_id: str
    user_id: str
    theme_name: Optional[str] = None
    previous_documents: Optional[List[str]] = None

# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint for monitoring"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

# Job analysis endpoints
@app.post("/api/jobs/analyze", response_model=JobAnalysisResponse)
async def analyze_job(request: JobInputRequest):
    """
    Analyze job posting from description text or URL
    Enhanced workflow: Supports both manual description and automatic URL scraping
    """
    try:
        if request.job_url:
            # Scrape job posting from URL
            logger.info(f"Scraping job from URL: {request.job_url}")
            scraped_data = await job_scraper.scrape_job_posting(request.job_url)
            
            # Extract key information using AI
            job_analysis = await gemini_client.analyze_job_posting(scraped_data)
            
            # Get company research from Perplexity
            company_research = await perplexity_client.research_company(
                scraped_data.get('company', '')
            )
            
            job_analysis.update({
                'scraped_data': scraped_data,
                'company_research': company_research
            })
            
        elif request.job_description:
            # Analyze provided job description
            logger.info("Analyzing provided job description")
            job_analysis = await gemini_client.analyze_job_posting({
                'description': request.job_description
            })
            
            # Get company research if company name is detected
            if 'company' in job_analysis:
                company_research = await perplexity_client.research_company(
                    job_analysis['company']
                )
                job_analysis['company_research'] = company_research
                
        else:
            raise HTTPException(
                status_code=400, 
                detail="Either job_description or job_url must be provided"
            )
        
        # Save job analysis to database
        job_id = await db_manager.save_job_analysis(request.user_id, job_analysis)
        job_analysis['job_id'] = job_id
        
        return JobAnalysisResponse(**job_analysis)
        
    except Exception as e:
        logger.error(f"Error analyzing job: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Job analysis failed: {str(e)}")

# Resume upload and parsing endpoints
@app.post("/api/resumes/upload", response_model=ResumeUploadResponse)
async def upload_resume(
    file: UploadFile = File(...),
    user_id: str = Form(...),
    is_master_resume: bool = Form(False)
):
    """
    Upload and parse resume with automatic information extraction
    Enhanced workflow: Extracts user info (name, contact, experience, education)
    """
    try:
        # Validate file type
        if not file.filename.endswith(('.pdf', '.docx', '.txt')):
            raise HTTPException(
                status_code=400,
                detail="Unsupported file type. Please upload PDF, DOCX, or TXT files."
            )
        
        # Save uploaded file temporarily
        file_path = f"/tmp/{file.filename}"
        with open(file_path, "wb") as buffer:
            buffer.write(await file.read())
        
        # Parse resume and extract information
        logger.info(f"Parsing resume: {file.filename}")
        extracted_data = await resume_parser.parse_resume(file_path)
        
        # Enhanced extraction using AI
        ai_extracted_data = await gemini_client.extract_resume_information(extracted_data)
        
        # Combine traditional and AI extraction
        combined_data = {**extracted_data, **ai_extracted_data}
        
        # Save resume data to database
        resume_id = await db_manager.save_resume(
            user_id=user_id,
            filename=file.filename,
            extracted_data=combined_data,
            is_master_resume=is_master_resume
        )
        
        # Update user profile with extracted information
        await db_manager.update_user_profile(user_id, combined_data)
        
        # Store in vector database for similarity matching
        await db_manager.store_resume_vector(resume_id, combined_data)
        
        # Clean up temporary file
        os.remove(file_path)
        
        return ResumeUploadResponse(
            resume_id=resume_id,
            extracted_data=combined_data,
            parsing_success=True,
            message="Resume uploaded and parsed successfully"
        )
        
    except Exception as e:
        logger.error(f"Error uploading resume: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Resume upload failed: {str(e)}")

# Theme selection endpoint
@app.post("/api/themes/select")
async def select_theme(request: ThemeSelectionRequest):
    """
    Select theme for document generation (one-time selection)
    Enhanced workflow: Theme applies to all subsequent documents
    """
    try:
        # Validate theme name
        available_themes = theme_manager.get_available_themes()
        if request.theme_name not in available_themes:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid theme. Available themes: {', '.join(available_themes)}"
            )
        
        # Save theme selection for user
        await db_manager.save_user_theme_preference(request.user_id, request.theme_name)
        
        return StandardResponse(
            success=True,
            message=f"Theme '{request.theme_name}' selected successfully",
            data={"theme": request.theme_name}
        )
        
    except Exception as e:
        logger.error(f"Error selecting theme: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Theme selection failed: {str(e)}")

# Document generation endpoints
@app.post("/api/documents/generate")
async def generate_document(request: DocumentGenerationRequest):
    """
    Generate documents sequentially (Resume → Cover Letter → KSC)
    Enhanced workflow: Sequential generation with theme consistency
    """
    try:
        # Get user's theme preference
        user_theme = await db_manager.get_user_theme_preference(request.user_id)
        if not user_theme:
            raise HTTPException(
                status_code=400,
                detail="Please select a theme before generating documents"
            )
        
        # Get job analysis data
        job_data = await db_manager.get_job_analysis(request.job_id)
        if not job_data:
            raise HTTPException(
                status_code=404,
                detail="Job analysis not found"
            )
        
        # Get user's resume history for context
        user_resumes = await db_manager.get_user_resumes(request.user_id)
        
        # Get previous similar documents if provided
        previous_context = []
        if request.previous_documents:
            previous_context = await db_manager.get_documents(request.previous_documents)
        
        # Generate document using workflow engine
        generated_document = await workflow_engine.generate_document(
            document_type=request.document_type,
            job_data=job_data,
            user_resumes=user_resumes,
            theme=user_theme,
            previous_context=previous_context
        )
        
        # Save generated document
        document_id = await db_manager.save_generated_document(
            user_id=request.user_id,
            job_id=request.job_id,
            document_type=request.document_type,
            document_data=generated_document,
            theme=user_theme
        )
        
        return StandardResponse(
            success=True,
            message=f"{request.document_type.title()} generated successfully",
            data={
                "document_id": document_id,
                "document_type": request.document_type,
                "download_url": f"/api/documents/{document_id}/download"
            }
        )
        
    except Exception as e:
        logger.error(f"Error generating document: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Document generation failed: {str(e)}")

# Document download endpoint
@app.get("/api/documents/{document_id}/download")
async def download_document(document_id: str):
    """Download generated document as PDF"""
    try:
        # Get document data
        document_data = await db_manager.get_document(document_id)
        if not document_data:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Generate PDF file
        pdf_path = await document_generator.generate_pdf(document_data)
        
        return FileResponse(
            path=pdf_path,
            filename=f"{document_data['type']}_{document_id}.pdf",
            media_type="application/pdf"
        )
        
    except Exception as e:
        logger.error(f"Error downloading document: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Document download failed: {str(e)}")

# User profile endpoints
@app.get("/api/profiles/{user_id}")
async def get_user_profile(user_id: str):
    """Get user profile with extracted information"""
    try:
        profile = await db_manager.get_user_profile(user_id)
        if not profile:
            raise HTTPException(status_code=404, detail="User profile not found")
        
        return StandardResponse(
            success=True,
            data=profile
        )
        
    except Exception as e:
        logger.error(f"Error fetching profile: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Profile fetch failed: {str(e)}")

# Get available themes endpoint
@app.get("/api/themes")
async def get_themes():
    """Get available document themes"""
    try:
        themes = theme_manager.get_available_themes()
        theme_details = {}
        
        for theme in themes:
            theme_details[theme] = theme_manager.get_theme_details(theme)
        
        return StandardResponse(
            success=True,
            data=theme_details
        )
        
    except Exception as e:
        logger.error(f"Error fetching themes: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Theme fetch failed: {str(e)}")

# Exception handlers
@app.exception_handler(APIException)
async def api_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "message": exc.detail}
    )

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "message": exc.detail}
    )

# Mount static files (serve frontend)
# This must be added AFTER all API routes
app.mount("/", StaticFiles(directory="src/frontend", html=True), name="frontend")

# Application startup
@app.on_event("startup")
async def startup_event():
    """Initialize application on startup"""
    logger.info("Enhanced Resume Agent 3.0 starting up...")
    
    # Initialize database
    await db_manager.initialize()
    
    # Initialize AI clients
    await gemini_client.initialize()
    await perplexity_client.initialize()
    
    logger.info("Application startup complete")

# Application shutdown
@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on application shutdown"""
    logger.info("Enhanced Resume Agent 3.0 shutting down...")
    
    # Close database connections
    await db_manager.close()
    
    logger.info("Application shutdown complete")

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", "8000")),
        reload=True
    )