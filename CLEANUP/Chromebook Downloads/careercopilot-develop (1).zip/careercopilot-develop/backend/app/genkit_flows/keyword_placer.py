from typing import List

from app.core.genkit_init import get_model
from app.genkit_flows.flow_decorator import simple_genkit_flow
from pydantic import BaseModel, Field

# --- Pydantic Schemas for Structured Output ---


class KeywordPlacementSuggestion(BaseModel):
    """Defines the structure for a single keyword placement suggestion."""

    keyword: str = Field(description="The missing keyword.")
    suggested_location: str = Field(
        description="A short, specific description of the best place in the resume to add the keyword "
        "(e.g., 'In the summary section' or 'In the bullet points for the Sr. Accountant role')."
    )
    example_sentence: str = Field(
        description="A well-crafted example sentence that naturally incorporates the keyword into the "
        "suggested location."
    )


class KeywordPlacementResponse(BaseModel):
    """A list of keyword placement suggestions."""

    suggestions: List[KeywordPlacementSuggestion]


# --- Genkit Flow ---


@simple_genkit_flow(output_schema=KeywordPlacementResponse)
def suggestKeywordPlacement(
    resumeText: str, list_of_missing_keywords: List[str]
) -> KeywordPlacementResponse:
    """
    Analyzes a resume and a list of missing keywords to suggest the most
    contextually appropriate placement for each keyword.
    """

    prompt = f"""
    Act as an expert resume editor. Your task is to analyze the provided
    resume text and suggest the best placement for a list of missing keywords.

    **Instructions:**
    1.  Review the Resume Text to understand its structure and content.
    2.  For each keyword in the Missing Keywords list, find the most logical
        and contextually appropriate location to insert it. This could be in
        the professional summary, a specific job's responsibilities, or a
        skills section.
    3.  Do not rewrite the resume. Your output must be a list of specific, actionable suggestions.
    4.  Provide a clear example sentence for each suggestion.

    **Resume Text:**
    ---
    {resumeText}
    ---

    **Missing Keywords:**
    ---
    {', '.join(list_of_missing_keywords)}
    ---

    Generate the suggestions now.
    """

    # Model availability is guaranteed by the decorator
    model = get_model()

    response = model.generate(
        prompt=prompt,
        output_schema=KeywordPlacementResponse,
        config={"response_mime_type": "application/json"},
    )

    return response.output()
