# Basic unit test for ResumeOptimizer
import pytest
from modules.resume_optimizer import ResumeOptimizer


def test_generate_resume_returns_dict():
    optimizer = ResumeOptimizer()
    job_description = "Looking for a community support worker with experience in advocacy and stakeholder engagement."
    result = optimizer.generate_resume(job_description, {"role": "Community Support Worker"})
    assert isinstance(result, dict)
    assert "html" in result
    assert "docx" in result
    assert "pdf" in result