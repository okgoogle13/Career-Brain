# Streamlit application entry point for Enhanced Resume Agent 2.0
import os
import yaml
import streamlit as st
from modules.resume_optimizer import ResumeOptimizer
from modules.cover_letter_generator import CoverLetterGenerator
from modules.ksc_responder import KSCResponder
from modules.company_researcher import CompanyResearcher
from dotenv import load_dotenv

load_dotenv()

# Initialize modules
resume_optimizer = ResumeOptimizer()
cover_letter_generator = CoverLetterGenerator()
ksc_responder = KSCResponder()
company_researcher = CompanyResearcher()

st.set_page_config(page_title="Enhanced Resume Agent 2.0", page_icon="📄", layout="wide")

st.title("📄 Enhanced Resume Agent 2.0")

menu = ["Resume", "Cover Letter", "KSC"]
choice = st.sidebar.selectbox("Select document type", menu)

st.sidebar.markdown("---")

# Upload job description or KSC question
input_text = st.sidebar.text_area("Paste Job Description / KSC Question")

# Additional inputs
company_name = st.sidebar.text_input("Company / Organization Name")
role = st.sidebar.text_input("Role Title")

if st.sidebar.button("Generate"):
    if not input_text:
        st.sidebar.error("Please provide job description or KSC question to proceed.")
    else:
        with st.spinner("Generating document..."):
            # Fetch company research context
            research_data = {}
            if company_name:
                research_data = company_researcher.research_company(company_name, role)
            
            # Generate documents based on choice
            if choice == "Resume":
                result = resume_optimizer.generate_resume(input_text, {
                    "company_research": research_data,
                    "role": role
                })
                st.download_button("Download Resume (DOCX)", result["docx"], file_name="resume.docx")
                st.download_button("Download Resume (PDF)", result["pdf"], file_name="resume.pdf")
                st.markdown("---")
                st.subheader("Preview")
                st.markdown(result["html"], unsafe_allow_html=True)
            elif choice == "Cover Letter":
                style = st.sidebar.selectbox("Select Cover Letter Style", ["formal-government", "values-driven-ngo", "corporate-social"])
                cover_letter = cover_letter_generator.generate_cover_letter({
                    "job_description": input_text,
                    "company_research": research_data,
                    "role": role
                }, style)
                st.download_button("Download Cover Letter (DOCX)", cover_letter["docx"], file_name="cover_letter.docx")
                st.download_button("Download Cover Letter (PDF)", cover_letter["pdf"], file_name="cover_letter.pdf")
                st.markdown("---")
                st.subheader("Preview")
                st.markdown(cover_letter["html"], unsafe_allow_html=True)
            else:
                ksc_response = ksc_responder.generate_ksc_response(input_text, {
                    "company_research": research_data,
                    "role": role
                })
                st.download_button("Download KSC Response (DOCX)", ksc_response["docx"], file_name="ksc_response.docx")
                st.download_button("Download KSC Response (PDF)", ksc_response["pdf"], file_name="ksc_response.pdf")
                st.markdown("---")
                st.subheader("Preview")
                st.markdown(ksc_response["html"], unsafe_allow_html=True)

st.sidebar.markdown("---")
st.sidebar.info("Enhanced Resume Agent 2.0\nBuilt with ❤️ for Community Services Sector")
