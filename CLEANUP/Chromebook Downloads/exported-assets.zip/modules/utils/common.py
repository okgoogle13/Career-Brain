# modules/utils/common.py
"""Common utility functions"""

import re
from typing import List


def clean_text(text: str) -> str:
    """Clean up text by removing extra whitespace and special characters"""
    return re.sub(r"\s+", " ", text.strip())


def chunk_text(text: str, chunk_size: int = 4096) -> List[str]:
    """Chunk large text into smaller segments"""
    return [text[i : i + chunk_size] for i in range(0, len(text), chunk_size)]