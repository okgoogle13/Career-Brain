# Enhanced Resume Agent 2.0

**AI-Powered Resume, Cover Letter & KSC Generator for Community Services**

[![Deploy to Google Cloud Run](https://img.shields.io/badge/Deploy-Cloud%20Run-blue)](https://cloud.google.com/run)
[![Python 3.11+](https://img.shields.io/badge/Python-3.11+-green)](https://python.org)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.29+-red)](https://streamlit.io)

## 🎯 Overview

Enhanced Resume Agent 2.0 is a cloud-native, AI-powered solution that automates the creation of tailored resumes, cover letters, and Key Selection Criteria (KSC) responses specifically for the community services and social work sector. 

### Key Features

- **🤖 AI-Powered Generation**: Leverages Gemini 2.5 Pro for intelligent document creation
- **🔍 Real-time Company Research**: Integrates Perplexity Sonar API for organizational intelligence
- **📊 ATS Optimization**: Ensures all documents are ATS-friendly and keyword-optimized
- **📝 STAR Framework**: Uses proven STAR methodology for compelling responses
- **🎨 Style Profiles**: Multiple cover letter styles for different organization types
- **☁️ Cloud-Native**: Designed for Google Cloud Run deployment
- **🔒 Security-First**: Secure API key management and data privacy

## 🏗️ Architecture

```
Enhanced Resume Agent 2.0
├── Resume Optimizer       # Tailored, ATS-friendly resume generation
├── Cover Letter Generator # Context-aware, style-matched cover letters  
├── KSC Responder         # STAR-based government/NGO responses
└── Company Research      # Real-time organizational intelligence
```

### Data Flow
1. **User Input** → Job description, role, or KSC question
2. **Company Research** → Perplexity API fetches organizational context
3. **Experience Matching** → Semantic search finds relevant STAR stories
4. **AI Generation** → Gemini produces tailored documents
5. **Document Output** → Formatted DOCX, PDF, or HTML

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- Google Cloud Account (for deployment)
- Gemini API Key
- Perplexity API Key

### Local Development

1. **Clone and Setup**
```bash
git clone <repository-url>
cd enhanced-resume-agent-2.0
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

2. **Configure Environment**
```bash
cp .env.example .env
# Edit .env with your API keys
```

3. **Customize Knowledge Base**
```bash
# Edit your experience and examples
nano config/experience_database.yaml
nano config/ksc_examples.yaml
```

4. **Run Application**
```bash
streamlit run main.py
```

5. **Run Tests**
```bash
pytest tests/ -v
```

### Cloud Deployment

1. **Prepare for Deployment**
```bash
chmod +x deploy.sh
./deploy.sh
```

2. **Configure Secrets in Google Cloud**
```bash
gcloud secrets create gemini-api-key --data-file=<(echo "your-gemini-key")
gcloud secrets create perplexity-api-key --data-file=<(echo "your-perplexity-key")
```

## 📊 Knowledge Base Structure

### Experience Database
- **STAR Stories**: Situation, Task, Action, Result format
- **Resume Bullets**: Pre-written, impact-focused bullet points
- **Skills Tags**: Semantic matching for relevant experience

### KSC Examples
- **Government Ready**: Compliant with public sector requirements
- **Evidence-Based**: Quantified outcomes and metrics
- **Reusable**: Adaptable to multiple similar criteria

### Cover Letter Styles
- **Formal Government**: Professional, compliance-focused
- **Values-Driven NGO**: Mission-centric, passionate tone
- **Corporate**: Business-focused, results-oriented

## 🧪 Testing Strategy

- **Unit Tests**: Pure functions and prompt builders
- **Integration Tests**: API interactions and response parsing
- **End-to-End Tests**: Complete user workflows
- **Visual Snapshot System**: Regression testing for outputs

## 📁 Project Structure

```
enhanced-resume-agent-2.0/
├── main.py                     # Streamlit application entry point
├── requirements.txt            # Python dependencies
├── Dockerfile                  # Container configuration
├── deploy.sh                   # Cloud Run deployment script
├── .env.example               # Environment variables template
├── config/                    # Configuration and knowledge bases
│   ├── experience_database.yaml
│   ├── ksc_examples.yaml
│   └── cover_letter_styles.yaml
├── modules/                   # Core application modules
│   ├── __init__.py
│   ├── resume_optimizer.py
│   ├── cover_letter_generator.py
│   ├── ksc_responder.py
│   ├── company_researcher.py
│   └── utils/
├── tests/                     # Test suite
│   ├── unit/
│   ├── integration/
│   └── e2e/
├── docs/                      # Additional documentation
│   ├── ARCHITECTURE.md
│   ├── IMPLEMENTATION_GUIDE.md
│   └── API_REFERENCE.md
└── README.md                  # This file
```

## 🔧 Configuration

### Environment Variables
```env
GEMINI_API_KEY=your_gemini_api_key_here
PERPLEXITY_API_KEY=your_perplexity_api_key_here
GOOGLE_CLOUD_PROJECT=your_gcp_project_id
ENVIRONMENT=development  # or production
```

### Google Cloud Run Configuration
- **Memory**: 2Gi
- **CPU**: 2 vCPU
- **Concurrency**: 80
- **Max Instances**: 10

## 📈 Performance & Monitoring

- **Response Time**: < 30 seconds for complete document generation
- **Cache Strategy**: 24-hour company research cache
- **Cost Optimization**: Efficient API usage patterns
- **Logging**: Structured logs for debugging and monitoring

## 🔒 Security & Privacy

- **API Key Management**: Google Secret Manager integration
- **Data Privacy**: No user data leaves deployment environment
- **Input Validation**: Safe YAML loading with schema validation
- **Secure Dependencies**: Regular security updates and audits

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Run tests (`pytest tests/ -v`)
4. Commit changes (`git commit -m 'Add amazing feature'`)
5. Push to branch (`git push origin feature/amazing-feature`)
6. Open a Pull Request

## 📚 Documentation

- [Architecture Guide](docs/ARCHITECTURE.md)
- [Implementation Guide](docs/IMPLEMENTATION_GUIDE.md)
- [API Reference](docs/API_REFERENCE.md)

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For questions, issues, or feature requests:
- Create an issue in this repository
- Contact: nishant.jonas.dougall@example.com
- Documentation: [Implementation Guide](docs/IMPLEMENTATION_GUIDE.md)

## 🎯 Roadmap

- [ ] Automated job scraping integration
- [ ] Application deadline tracking
- [ ] Multi-language support
- [ ] Advanced analytics dashboard
- [ ] Mobile app development
- [ ] Integration with major job boards

---

**Built with ❤️ for the Community Services Sector**