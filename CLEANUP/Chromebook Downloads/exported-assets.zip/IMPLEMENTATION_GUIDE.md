# Implementation Guide - Enhanced Resume Agent 2.0

## Table of Contents
1. [Getting Started](#getting-started)
2. [Local Development Setup](#local-development-setup)
3. [Configuration](#configuration)
4. [Knowledge Base Customization](#knowledge-base-customization)
5. [Testing](#testing)
6. [Cloud Deployment](#cloud-deployment)
7. [Troubleshooting](#troubleshooting)

## Getting Started

### System Requirements
- **Python**: 3.11 or higher
- **Memory**: Minimum 4GB RAM
- **Storage**: 2GB free space
- **Internet**: Required for API calls
- **Browser**: Modern browser for Streamlit interface

### API Keys Required
1. **Gemini API Key** 
   - Visit [Google AI Studio](https://makersuite.google.com/)
   - Create new project and generate API key
   - Copy key for configuration

2. **Perplexity API Key**
   - Visit [Perplexity AI](https://www.perplexity.ai/)
   - Sign up for API access
   - Generate API key from dashboard

## Local Development Setup

### Step 1: Environment Preparation
```bash
# Clone the repository
git clone <repository-url>
cd enhanced-resume-agent-2.0

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Step 2: Environment Configuration
```bash
# Copy environment template
cp .env.example .env

# Edit .env file with your API keys
nano .env  # or use your preferred editor
```

### Step 3: Initial Testing
```bash
# Run tests to verify setup
pytest tests/ -v

# Start the application
streamlit run main.py
```

The application will open in your browser at `http://localhost:8501`

## Configuration

### Environment Variables (.env)
```env
# Required API Keys
GEMINI_API_KEY=your_gemini_api_key_here
PERPLEXITY_API_KEY=your_perplexity_api_key_here

# Google Cloud Configuration (for deployment)
GOOGLE_CLOUD_PROJECT=your_gcp_project_id
GOOGLE_APPLICATION_CREDENTIALS=path/to/service-account.json

# Application Settings
ENVIRONMENT=development  # or production
LOG_LEVEL=INFO
CACHE_DURATION_HOURS=24

# Optional: Custom Model Settings
GEMINI_MODEL=gemini-2.5-pro
TEMPERATURE=0.7
MAX_TOKENS=4096
```

### Application Configuration (config/app_config.yaml)
```yaml
app:
  name: "Enhanced Resume Agent 2.0"
  version: "2.0.0"
  debug: true

ai_models:
  gemini:
    model: "gemini-2.5-pro"
    temperature: 0.7
    max_tokens: 4096
  perplexity:
    model: "sonar-pro"
    timeout: 30

cache:
  enabled: true
  duration_hours: 24
  max_size_mb: 100

documents:
  formats: ["docx", "pdf", "html"]
  max_pages: 10
  font_family: "Arial"
  font_size: 11
```

## Knowledge Base Customization

### Experience Database (config/experience_database.yaml)

This is the most important file to customize with your own experiences:

```yaml
experiences:
  - id: "exp_001"
    role: "Community Support Worker"
    organization: "Local Community Centre"
    dates: "2022-2024"
    situation: "Clients struggling with digital literacy preventing access to essential services"
    task: "Develop and implement digital literacy training program"
    action:
      - "Assessed individual client needs through one-on-one consultations"
      - "Designed step-by-step training materials for different skill levels"
      - "Coordinated with IT department to set up accessible training space"
      - "Delivered weekly group sessions and individual coaching"
      - "Created ongoing support resources and peer mentoring program"
    result: "Improved digital literacy for 85+ clients, with 90% successfully accessing online services independently"
    skills_tags: 
      - "digital-literacy"
      - "program-development"
      - "client-assessment"
      - "training-delivery"
      - "community-engagement"
    resume_bullets:
      - "Developed comprehensive digital literacy program serving 85+ clients, achieving 90% success rate in independent online service access"
      - "Designed and delivered tailored training materials for diverse skill levels, improving community digital inclusion"
      - "Established peer mentoring program that sustained learning outcomes beyond formal training period"
```

### Customization Steps:

1. **Add Your Experiences**
   - Replace sample experiences with your own STAR stories
   - Include quantified results where possible
   - Use relevant skills tags for your sector

2. **Create Multiple Bullet Variations**
   - Write 3-5 different resume bullets per experience
   - Vary the focus (action-oriented, result-oriented, skill-oriented)
   - Different lengths for different resume formats

3. **Update Skills Tags**
   - Use industry-relevant skill keywords
   - Include both hard and soft skills
   - Consider ATS keyword optimization

### KSC Examples (config/ksc_examples.yaml)

Customize with your own Key Selection Criteria examples:

```yaml
ksc_examples:
  - id: "ksc_communication"
    title: "Excellent written and verbal communication skills"
    situation: "Client with complex needs requiring coordination across multiple service providers"
    task: "Facilitate clear communication between client, family, and service providers"
    action:
      - "Conducted initial comprehensive assessment using active listening techniques"
      - "Translated complex information into accessible language for client and family"
      - "Developed communication protocols for service provider team"
      - "Facilitated regular case conferences with all stakeholders"
      - "Created written summaries and action plans after each meeting"
    result: "Achieved seamless service coordination, with client reporting 95% satisfaction and successful goal achievement within 6 months"
    related_skills:
      - "active-listening"
      - "written-communication"
      - "stakeholder-management"
      - "case-coordination"
```

### Cover Letter Styles (config/cover_letter_styles.yaml)

Adjust tone and style for different organization types:

```yaml
styles:
  formal-government:
    name: "Formal Government"
    description: "Professional, compliance-focused tone for public sector roles"
    prompt_modifier: "Use formal language, emphasize policy compliance, evidence-based practice, and accountability. Reference public sector values and frameworks."
    
  values-driven-ngo:
    name: "Values-Driven NGO"
    description: "Warm, mission-centric voice for nonprofit organizations"
    prompt_modifier: "Show passion for social justice, emphasize community impact and mission alignment. Use warm but professional tone."
    
  corporate-social:
    name: "Corporate Social Responsibility"
    description: "Business-focused approach for corporate social programs"
    prompt_modifier: "Emphasize business outcomes, efficiency, and measurable impact. Professional corporate tone with social awareness."
```

## Testing

### Running Tests
```bash
# Run all tests
pytest tests/ -v

# Run specific test categories
pytest tests/unit/ -v           # Unit tests only
pytest tests/integration/ -v    # Integration tests only
pytest tests/e2e/ -v           # End-to-end tests only

# Run with coverage report
pytest tests/ --cov=modules --cov-report=html
```

### Test Categories

1. **Unit Tests** (`tests/unit/`)
   - Test individual functions and components
   - Mock external dependencies
   - Fast execution

2. **Integration Tests** (`tests/integration/`)
   - Test API integrations
   - Test component interactions
   - Use test API keys

3. **End-to-End Tests** (`tests/e2e/`)
   - Test complete user workflows
   - Test document generation
   - Verify output quality

### Adding Your Own Tests

Create test files following this pattern:
```python
# tests/unit/test_my_feature.py
import pytest
from modules.my_feature import MyFeature

def test_my_feature_basic():
    feature = MyFeature()
    result = feature.process("test input")
    assert result is not None
    assert "expected" in result
```

## Cloud Deployment

### Google Cloud Run Deployment

#### Prerequisites
1. Google Cloud Project
2. Cloud Run API enabled
3. gcloud CLI installed and authenticated

#### Step 1: Prepare Google Cloud
```bash
# Set project
gcloud config set project YOUR_PROJECT_ID

# Enable required APIs
gcloud services enable run.googleapis.com
gcloud services enable secretmanager.googleapis.com
gcloud services enable cloudbuild.googleapis.com
```

#### Step 2: Set Up Secrets
```bash
# Create secrets for API keys
echo "your_gemini_api_key" | gcloud secrets create gemini-api-key --data-file=-
echo "your_perplexity_api_key" | gcloud secrets create perplexity-api-key --data-file=-

# Grant Cloud Run access to secrets
gcloud projects add-iam-policy-binding YOUR_PROJECT_ID \
    --member="serviceAccount:YOUR_PROJECT_NUMBER-compute@developer.gserviceaccount.com" \
    --role="roles/secretmanager.secretAccessor"
```

#### Step 3: Deploy Application
```bash
# Make deploy script executable
chmod +x deploy.sh

# Edit deploy.sh with your project ID
nano deploy.sh

# Run deployment
./deploy.sh
```

#### Step 4: Configure Domain (Optional)
```bash
# Map custom domain
gcloud run domain-mappings create --service enhanced-resume-agent --domain your-domain.com
```

### Deployment Configuration

#### Dockerfile Optimization
The included Dockerfile is optimized for:
- Fast build times with layer caching
- Minimal image size using Alpine Linux
- Security best practices
- Efficient dependency installation

#### Cloud Run Configuration
```yaml
# cloud-run-config.yaml
apiVersion: serving.knative.dev/v1
kind: Service
metadata:
  name: enhanced-resume-agent
  annotations:
    run.googleapis.com/ingress: all
spec:
  template:
    metadata:
      annotations:
        autoscaling.knative.dev/maxScale: "10"
        run.googleapis.com/memory: "2Gi"
        run.googleapis.com/cpu: "2"
    spec:
      containerConcurrency: 80
      timeoutSeconds: 300
      containers:
      - image: gcr.io/PROJECT_ID/enhanced-resume-agent
        ports:
        - containerPort: 8080
        env:
        - name: GEMINI_API_KEY
          valueFrom:
            secretKeyRef:
              name: gemini-api-key
              key: latest
        - name: PERPLEXITY_API_KEY
          valueFrom:
            secretKeyRef:
              name: perplexity-api-key
              key: latest
```

## Troubleshooting

### Common Issues

#### 1. API Key Issues
**Problem**: "Invalid API key" errors
**Solution**: 
- Verify API keys are correct in .env file
- Check API key permissions and quotas
- Ensure secrets are properly configured in Cloud Run

#### 2. Import Errors
**Problem**: "ModuleNotFoundError" 
**Solution**:
- Verify virtual environment is activated
- Reinstall requirements: `pip install -r requirements.txt`
- Check Python version compatibility

#### 3. YAML Loading Errors
**Problem**: "yaml.scanner.ScannerError"
**Solution**:
- Validate YAML syntax using online validators
- Check for proper indentation (spaces, not tabs)
- Ensure quotes are properly closed

#### 4. Streamlit Performance Issues
**Problem**: Slow response times
**Solution**:
- Enable caching in configuration
- Reduce knowledge base size if too large
- Check internet connection for API calls

#### 5. Cloud Run Deployment Fails
**Problem**: Deployment errors
**Solution**:
- Check Cloud Run quotas and limits
- Verify IAM permissions
- Review deployment logs: `gcloud run logs tail`

### Getting Help

1. **Check Logs**
   ```bash
   # Local development
   streamlit run main.py --logger.level=debug
   
   # Cloud Run
   gcloud run logs tail --service=enhanced-resume-agent
   ```

2. **Enable Debug Mode**
   ```env
   # In .env file
   ENVIRONMENT=development
   LOG_LEVEL=DEBUG
   ```

3. **Test Individual Components**
   ```bash
   # Test specific modules
   python -m pytest tests/unit/test_resume_optimizer.py -v
   ```

### Support Resources

- **Documentation**: Check docs/ folder for detailed guides
- **GitHub Issues**: Report bugs and request features
- **Community**: Join discussions in project forums
- **Email Support**: Contact project maintainers

---

**Next Steps**: After completing this setup, proceed to customize your knowledge bases and test the application with your own data.