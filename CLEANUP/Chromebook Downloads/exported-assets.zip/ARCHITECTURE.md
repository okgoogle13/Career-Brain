# Architecture Documentation - Enhanced Resume Agent 2.0

## Table of Contents
1. [System Architecture](#system-architecture)
2. [Component Design](#component-design)
3. [Data Flow](#data-flow)
4. [API Integration](#api-integration)
5. [Security Architecture](#security-architecture)
6. [Performance Considerations](#performance-considerations)
7. [Deployment Architecture](#deployment-architecture)

## System Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Enhanced Resume Agent 2.0                    │
├─────────────────────────────────────────────────────────────────┤
│                     Streamlit Web Interface                     │
├─────────────────────────────────────────────────────────────────┤
│  Resume        │  Cover Letter    │  KSC           │  Company   │
│  Optimizer     │  Generator       │  Responder     │  Research  │
├─────────────────────────────────────────────────────────────────┤
│                    AI Orchestration Layer                       │
├─────────────────────────────────────────────────────────────────┤
│  Gemini 2.5 Pro API              │  Perplexity Sonar API       │
├─────────────────────────────────────────────────────────────────┤
│  Knowledge Base                   │  Caching Layer              │
│  (YAML Files)                     │  (Memory/Redis)             │
└─────────────────────────────────────────────────────────────────┘
```

### Core Components

#### 1. User Interface Layer
- **Technology**: Streamlit
- **Purpose**: Provides intuitive web interface for users
- **Features**:
  - Multi-page navigation
  - Real-time document preview
  - Progress indicators
  - Download capabilities

#### 2. Business Logic Layer
- **Resume Optimizer**: ATS-focused resume generation
- **Cover Letter Generator**: Style-matched cover letters
- **KSC Responder**: STAR-based government responses
- **Company Researcher**: Real-time organizational intelligence

#### 3. AI Integration Layer
- **Gemini 2.5 Pro**: Primary AI engine for document generation
- **Perplexity Sonar**: Company research and intelligence
- **Prompt Engineering**: Context-rich prompt assembly

#### 4. Data Layer
- **Knowledge Bases**: YAML-based experience and example storage
- **Caching**: 24-hour company research cache
- **Configuration**: Environment-based settings

## Component Design

### Resume Optimizer Module

```python
class ResumeOptimizer:
    """
    Generates tailored, ATS-optimized resumes based on job descriptions
    and user experience database.
    """
    
    def __init__(self):
        self.experience_db = ExperienceDatabase()
        self.gemini_client = GeminiClient()
        self.ats_optimizer = ATSOptimizer()
    
    def generate_resume(self, job_description: str, user_profile: dict) -> dict:
        """
        Main resume generation workflow:
        1. Parse job description for key requirements
        2. Match relevant experiences from database
        3. Generate tailored resume content
        4. Optimize for ATS compliance
        5. Return formatted resume data
        """
        
    def match_experiences(self, requirements: list) -> list:
        """Semantic matching of experiences to job requirements"""
        
    def optimize_for_ats(self, resume_data: dict) -> dict:
        """Apply ATS optimization rules and formatting"""
```

### Cover Letter Generator Module

```python
class CoverLetterGenerator:
    """
    Generates context-aware cover letters using style profiles
    and company research data.
    """
    
    def __init__(self):
        self.style_profiles = StyleProfileManager()
        self.company_researcher = CompanyResearcher()
        self.gemini_client = GeminiClient()
    
    def generate_cover_letter(self, job_info: dict, style: str) -> str:
        """
        Cover letter generation workflow:
        1. Research company background
        2. Load appropriate style profile
        3. Match relevant experiences
        4. Generate personalized content
        5. Apply style-specific formatting
        """
        
    def research_company(self, company_name: str) -> dict:
        """Fetch company intelligence via Perplexity API"""
        
    def apply_style_profile(self, content: str, style: str) -> str:
        """Apply organization-specific tone and formatting"""
```

### KSC Responder Module

```python
class KSCResponder:
    """
    Generates STAR-based Key Selection Criteria responses
    for government and NGO applications.
    """
    
    def __init__(self):
        self.ksc_examples = KSCExampleDatabase()
        self.star_framework = STARFramework()
        self.gemini_client = GeminiClient()
    
    def generate_ksc_response(self, criteria: str, context: dict) -> dict:
        """
        KSC response generation workflow:
        1. Parse criteria requirements
        2. Find relevant STAR examples
        3. Adapt examples to criteria
        4. Generate compelling response
        5. Ensure compliance with word limits
        """
        
    def validate_star_structure(self, response: dict) -> bool:
        """Ensure response follows STAR methodology"""
        
    def check_word_count(self, response: str, limit: int) -> bool:
        """Validate response length against criteria limits"""
```

### Company Researcher Module

```python
class CompanyResearcher:
    """
    Provides real-time company intelligence using Perplexity API
    with intelligent caching for cost optimization.
    """
    
    def __init__(self):
        self.perplexity_client = PerplexityClient()
        self.cache = CompanyCache()
        self.query_optimizer = QueryOptimizer()
    
    def research_company(self, company_name: str, role: str = None) -> dict:
        """
        Company research workflow:
        1. Check cache for recent data
        2. Construct optimized search queries
        3. Fetch data from Perplexity API
        4. Process and structure results
        5. Cache for future use
        """
        
    def get_company_values(self, company_name: str) -> list:
        """Extract company values and culture information"""
        
    def get_recent_news(self, company_name: str) -> list:
        """Fetch recent company news and developments"""
```

## Data Flow

### Document Generation Flow

```mermaid
graph TD
    A[User Input] --> B[Job Description Parser]
    B --> C[Company Research]
    C --> D[Experience Matching]
    D --> E[Prompt Assembly]
    E --> F[AI Generation]
    F --> G[Document Formatting]
    G --> H[Output Generation]
    
    I[Knowledge Base] --> D
    J[Style Profiles] --> E
    K[Cache] --> C
    L[Templates] --> G
```

### Data Processing Pipeline

1. **Input Processing**
   - Validate and sanitize user input
   - Parse job descriptions for key requirements
   - Extract company information

2. **Context Assembly**
   - Fetch relevant experiences from knowledge base
   - Research company background and culture
   - Apply appropriate style profiles

3. **AI Processing**
   - Construct context-rich prompts
   - Generate content using Gemini 2.5 Pro
   - Apply post-processing optimizations

4. **Output Generation**
   - Format content for target document type
   - Apply ATS optimization rules
   - Generate downloadable files

## API Integration

### Gemini 2.5 Pro Integration

```python
class GeminiClient:
    """
    Handles all interactions with Google's Gemini 2.5 Pro API
    """
    
    def __init__(self):
        self.client = genai.GenerativeModel('gemini-2.5-pro')
        self.config = GenerationConfig(
            temperature=0.7,
            max_output_tokens=4096,
            top_p=0.9,
            top_k=40
        )
    
    async def generate_content(self, prompt: str, context: dict) -> str:
        """Generate content with context injection"""
        
    def optimize_prompt(self, base_prompt: str, context: dict) -> str:
        """Optimize prompts for better AI responses"""
```

### Perplexity Sonar Integration

```python
class PerplexityClient:
    """
    Handles company research via Perplexity Sonar API
    """
    
    def __init__(self):
        self.client = httpx.AsyncClient()
        self.base_url = "https://api.perplexity.ai"
        self.model = "sonar-pro"
    
    async def search_company(self, query: str) -> dict:
        """Search for company information"""
        
    async def get_company_insights(self, company_name: str) -> dict:
        """Get comprehensive company insights"""
```

## Security Architecture

### Authentication & Authorization

```python
class SecurityManager:
    """
    Handles security aspects of the application
    """
    
    def __init__(self):
        self.secret_manager = GoogleSecretManager()
        self.input_validator = InputValidator()
        self.rate_limiter = RateLimiter()
    
    def get_api_key(self, service: str) -> str:
        """Securely retrieve API keys from Secret Manager"""
        
    def validate_input(self, data: dict) -> bool:
        """Validate and sanitize user input"""
        
    def check_rate_limit(self, user_id: str) -> bool:
        """Enforce API rate limits"""
```

### Data Protection

1. **API Key Management**
   - Google Secret Manager for production
   - Environment variables for development
   - Automatic key rotation support

2. **Input Validation**
   - YAML safe loading with schema validation
   - Input sanitization and length limits
   - XSS and injection protection

3. **Data Privacy**
   - No persistent storage of user data
   - In-memory processing only
   - Secure API communications

## Performance Considerations

### Caching Strategy

```python
class CacheManager:
    """
    Manages application caching for performance optimization
    """
    
    def __init__(self):
        self.company_cache = TTLCache(maxsize=1000, ttl=86400)  # 24 hours
        self.prompt_cache = TTLCache(maxsize=500, ttl=3600)    # 1 hour
        self.response_cache = TTLCache(maxsize=200, ttl=1800)   # 30 minutes
    
    def get_cached_company_data(self, company_name: str) -> dict:
        """Retrieve cached company research data"""
        
    def cache_company_data(self, company_name: str, data: dict):
        """Cache company research results"""
```

### Optimization Strategies

1. **API Call Optimization**
   - Intelligent caching (24-hour company data)
   - Batch processing where possible
   - Async API calls for better performance

2. **Memory Management**
   - Streaming responses for large documents
   - Garbage collection optimization
   - Memory pool management

3. **Response Time Optimization**
   - Parallel processing of independent tasks
   - Progressive loading of UI components
   - Efficient data structures

## Deployment Architecture

### Google Cloud Run Architecture

```yaml
apiVersion: serving.knative.dev/v1
kind: Service
metadata:
  name: enhanced-resume-agent
  annotations:
    run.googleapis.com/ingress: all
    run.googleapis.com/execution-environment: gen2
spec:
  template:
    metadata:
      annotations:
        autoscaling.knative.dev/minScale: "0"
        autoscaling.knative.dev/maxScale: "10"
        run.googleapis.com/memory: "2Gi"
        run.googleapis.com/cpu: "2"
        run.googleapis.com/startup-cpu-boost: "true"
    spec:
      containerConcurrency: 80
      timeoutSeconds: 300
      containers:
      - image: gcr.io/PROJECT_ID/enhanced-resume-agent
        ports:
        - containerPort: 8080
        resources:
          limits:
            memory: "2Gi"
            cpu: "2"
        env:
        - name: GEMINI_API_KEY
          valueFrom:
            secretKeyRef:
              name: gemini-api-key
              key: latest
        - name: PERPLEXITY_API_KEY
          valueFrom:
            secretKeyRef:
              name: perplexity-api-key
              key: latest
```

### Container Architecture

```dockerfile
# Multi-stage build for optimized container
FROM python:3.11-slim as builder
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

FROM python:3.11-slim
WORKDIR /app
COPY --from=builder /usr/local/lib/python3.11/site-packages /usr/local/lib/python3.11/site-packages
COPY . .
EXPOSE 8080
CMD ["streamlit", "run", "main.py", "--server.port=8080", "--server.address=0.0.0.0"]
```

### Monitoring & Logging

```python
class MonitoringManager:
    """
    Handles application monitoring and logging
    """
    
    def __init__(self):
        self.logger = self.setup_logging()
        self.metrics = self.setup_metrics()
    
    def setup_logging(self):
        """Configure structured logging"""
        
    def setup_metrics(self):
        """Configure application metrics"""
        
    def log_api_call(self, service: str, duration: float, status: str):
        """Log API call metrics"""
        
    def track_user_action(self, action: str, metadata: dict):
        """Track user interactions"""
```

## Scalability Considerations

### Horizontal Scaling
- **Stateless Design**: No server-side session storage
- **Load Balancing**: Google Cloud Load Balancer
- **Auto-scaling**: Based on CPU and memory usage

### Vertical Scaling
- **Memory Optimization**: Efficient data structures
- **CPU Optimization**: Async processing
- **I/O Optimization**: Connection pooling

### Cost Optimization
- **API Usage**: Intelligent caching to minimize API calls
- **Compute Resources**: Right-sized containers
- **Storage**: Minimal persistent storage requirements

---

This architecture provides a robust, scalable, and secure foundation for the Enhanced Resume Agent 2.0, designed to handle production workloads while maintaining flexibility for future enhancements.