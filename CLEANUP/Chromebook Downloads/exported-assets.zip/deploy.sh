#!/usr/bin/env bash
# Deployment script for Enhanced Resume Agent 2.0 on Google Cloud Run

set -e

PROJECT_ID=${GOOGLE_CLOUD_PROJECT:-"YOUR_GCP_PROJECT_ID"}
SERVICE_NAME="enhanced-resume-agent"
REGION="australia-southeast1"
IMAGE="gcr.io/$PROJECT_ID/$SERVICE_NAME"

if [ "$PROJECT_ID" == "YOUR_GCP_PROJECT_ID" ]; then
  echo "Please set your GOOGLE_CLOUD_PROJECT environment variable or edit deploy.sh with your project ID."
  exit 1
fi

# Build container image
printf "\n[1/3] Building Docker image...\n"
gcloud builds submit --tag $IMAGE .

# Deploy to Cloud Run
printf "\n[2/3] Deploying to Cloud Run...\n"
gcloud run deploy $SERVICE_NAME \
  --image $IMAGE \
  --platform managed \
  --region $REGION \
  --cpu 2 \
  --memory 2Gi \
  --concurrency 80 \
  --allow-unauthenticated \
  --set-secrets GEMINI_API_KEY=gemini-api-key:latest,PERPLEXITY_API_KEY=perplexity-api-key:latest

# Output service URL
printf "\n[3/3] Deployment completed!\n"
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --platform managed --region $REGION --format='value(status.url)')

echo "Service deployed at: $SERVICE_URL"