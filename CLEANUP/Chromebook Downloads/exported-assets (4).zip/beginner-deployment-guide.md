# Enhanced Resume Agent 3.0: Complete Beginner's Guide

## Table of Contents
1. [What You're Building](#what-youre-building)
2. [What You'll Need](#what-youll-need)
3. [Step-by-Step Setup](#step-by-step-setup)
4. [Running Your Resume Agent](#running-your-resume-agent)
5. [Deploying to the Cloud](#deploying-to-the-cloud)
6. [Troubleshooting](#troubleshooting)
7. [Next Steps](#next-steps)

---

## What You're Building

The Enhanced Resume Agent 3.0 is like having a personal career assistant that helps you create perfect resumes, cover letters, and job application responses. Here's what it does:

- **Analyzes job postings** to understand what employers want
- **Customizes your resume** to match each job perfectly
- **Writes cover letters** that sound like you wrote them
- **Generates professional responses** to application questions
- **Ensures your documents** pass through automated screening systems (ATS)

Think of it as a smart tool that takes your basic information and transforms it into polished, professional documents tailored for each job you apply to.

---

## What You'll Need

### Before You Start
- **A computer** (Windows, Mac, or Linux)
- **Internet connection**
- **About 2-3 hours** for the complete setup
- **Basic willingness to follow instructions** (no coding knowledge required!)

### Accounts You'll Need to Create (Free)
1. **GitHub Account** - Where your code will live (like Google Drive for developers)
2. **Google Cloud Account** - Where your app will run online
3. **Google AI Studio Account** - For the AI brain of your system
4. **Perplexity API Account** - For research capabilities

### Software to Install
Don't worry - we'll walk through installing everything step by step!

---

## Step-by-Step Setup

### Phase 1: Getting the Foundation Ready

#### Step 1: Install Python
Python is the programming language your resume agent uses.

**For Windows:**
1. Go to https://www.python.org/downloads/
2. Click "Download Python 3.11" (or the latest version)
3. Run the installer
4. **IMPORTANT**: Check the box that says "Add Python to PATH"
5. Click "Install Now"

**For Mac:**
1. Go to https://www.python.org/downloads/
2. Download Python 3.11 for macOS
3. Open the downloaded file and follow the installation wizard

**For Linux (Ubuntu/Debian):**
Open Terminal and type:
```bash
sudo apt update
sudo apt install python3.11 python3.11-pip
```

#### Step 2: Install Git
Git helps you manage your code versions.

**For Windows:**
1. Go to https://git-scm.com/download/win
2. Download and run the installer
3. Use all default settings during installation

**For Mac:**
1. Open Terminal (found in Applications > Utilities)
2. Type: `git --version`
3. If it's not installed, follow the prompts to install Xcode Command Line Tools

**For Linux:**
```bash
sudo apt install git
```

#### Step 3: Install Docker (Optional but Recommended)
Docker packages your application so it runs the same way everywhere.

1. Go to https://www.docker.com/products/docker-desktop/
2. Download Docker Desktop for your operating system
3. Install and start Docker Desktop
4. Create a free Docker Hub account when prompted

#### Step 4: Install Visual Studio Code (Recommended)
This is a user-friendly code editor.

1. Go to https://code.visualstudio.com/
2. Download and install for your operating system
3. Open VS Code and install these extensions:
   - Python
   - Docker
   - GitLens

### Phase 2: Setting Up Your Resume Agent

#### Step 1: Get Your Code
1. Open your terminal/command prompt
2. Navigate to where you want to store your project:
   ```bash
   cd Desktop
   mkdir resume-agent
   cd resume-agent
   ```
3. Download the Enhanced Resume Agent 3.0 code (you'll get this from the previous conversation's zip file)
4. Extract the zip file contents into your resume-agent folder

#### Step 2: Set Up Your Development Environment
1. Open terminal in your resume-agent folder
2. Create a virtual environment (this keeps your project organized):
   ```bash
   python -m venv venv
   ```
3. Activate the virtual environment:
   - **Windows:** `venv\Scripts\activate`
   - **Mac/Linux:** `source venv/bin/activate`
4. Install the required packages:
   ```bash
   pip install -r requirements.txt
   ```

### Phase 3: Configuration

#### Step 1: Get Your API Keys
You need these for the AI features to work.

**Google Gemini API:**
1. Go to https://makersuite.google.com/app/apikey
2. Sign in with your Google account
3. Click "Create API Key"
4. Copy the key and save it somewhere safe

**Perplexity API:**
1. Go to https://www.perplexity.ai/
2. Sign up for an account
3. Go to API settings
4. Generate an API key
5. Copy and save the key

#### Step 2: Configure Your Environment
1. In your resume-agent folder, find the file called `.env.example`
2. Make a copy and rename it to `.env`
3. Open the `.env` file in a text editor
4. Fill in your API keys:
   ```
   GOOGLE_API_KEY=your_gemini_key_here
   PERPLEXITY_API_KEY=your_perplexity_key_here
   ```

#### Step 3: Set Up Your Personal Information
1. Open the `config/app.yaml` file
2. Replace the placeholder information with your details:
   ```yaml
   user_profile:
     name: "Your Full Name"
     email: "your.email@example.com"
     phone: "Your Phone Number"
     location: "Your City, State"
   ```

---

## Running Your Resume Agent

### Method 1: Using the Web Interface (Recommended for Beginners)

#### Step 1: Start the Application
1. Open terminal in your resume-agent folder
2. Make sure your virtual environment is activated
3. Run the command:
   ```bash
   make run-web
   ```
4. Wait for the message "You can now view your Streamlit app in your browser"
5. Open your web browser and go to `http://localhost:8501`

#### Step 2: Using the Web Interface
1. **Upload Your Information**: On the Profile page, upload your existing resume or fill in your details
2. **Analyze a Job**: Go to the Job Analysis page and paste a job posting
3. **Generate Documents**: Navigate to Document Generation to create your tailored resume and cover letter
4. **Review Results**: Check the generated documents in the Results page

### Method 2: Using the Command Line Interface

If you're feeling adventurous, you can use text commands:

```bash
# Initialize your profile
python -m src.cli init

# Generate a resume for a specific job
python -m src.cli generate resume --job-posting "paste job posting here"

# Create a cover letter
python -m src.cli generate cover-letter --job-posting "paste job posting here"
```

---

## Deploying to the Cloud

### Why Deploy to the Cloud?
Deploying to the cloud means your resume agent will be available from anywhere with an internet connection, not just your computer.

### Step 1: Set Up Google Cloud

#### Create a Google Cloud Account
1. Go to https://cloud.google.com/
2. Click "Get started for free"
3. Sign up with your Google account
4. You'll get $300 in free credits (more than enough for this project)

#### Install Google Cloud CLI
1. Go to https://cloud.google.com/sdk/docs/install
2. Download the installer for your operating system
3. Follow the installation instructions
4. Open terminal and run: `gcloud auth login`
5. Follow the prompts to authenticate

#### Create a New Project
1. In terminal, run:
   ```bash
   gcloud projects create resume-agent-[YOUR-NAME] --name="Resume Agent"
   gcloud config set project resume-agent-[YOUR-NAME]
   ```
2. Enable required services:
   ```bash
   gcloud services enable run.googleapis.com
   gcloud services enable cloudbuild.googleapis.com
   ```

### Step 2: Deploy Your Application

#### Build and Deploy
1. In your resume-agent folder, run:
   ```bash
   make docker-build
   ```
2. Deploy to Cloud Run:
   ```bash
   ./scripts/deploy_cloud_run.sh
   ```
3. When prompted, choose:
   - Region: Choose one close to you (e.g., us-central1)
   - Allow unauthenticated invocations: Yes

#### Set Up Environment Variables
1. Go to https://console.cloud.google.com/run
2. Click on your resume-agent service
3. Click "Edit & Deploy New Revision"
4. Under "Variables & Secrets", add:
   - `GOOGLE_API_KEY`: Your Gemini API key
   - `PERPLEXITY_API_KEY`: Your Perplexity API key
5. Click "Deploy"

### Step 3: Access Your Live Application
1. After deployment, you'll get a URL like `https://resume-agent-xxx.run.app`
2. Open this URL in your browser
3. Your resume agent is now live and accessible from anywhere!

---

## Troubleshooting

### Common Issues and Solutions

#### "Python not found" or "Command not found"
- **Problem**: Python isn't installed or not in your PATH
- **Solution**: Reinstall Python and make sure to check "Add Python to PATH"

#### "Permission denied" errors
- **Problem**: Your user doesn't have permission to install packages
- **Solution**: 
  - On Windows: Run command prompt as Administrator
  - On Mac/Linux: Add `sudo` before commands (e.g., `sudo pip install...`)

#### "API key not working"
- **Problem**: API keys are incorrect or not properly configured
- **Solution**: 
  - Double-check your API keys in the `.env` file
  - Make sure there are no extra spaces or characters
  - Verify the keys work by testing them in the API provider's playground

#### "Port already in use" when running web interface
- **Problem**: Something else is using port 8501
- **Solution**: 
  - Close other applications that might be using the port
  - Or run: `streamlit run web/streamlit_app.py --server.port 8502`

#### Docker errors
- **Problem**: Docker Desktop isn't running or not installed properly
- **Solution**: 
  - Make sure Docker Desktop is running
  - Restart Docker Desktop
  - Try running `docker --version` to test

#### Cloud deployment fails
- **Problem**: Authentication or permission issues
- **Solution**: 
  - Run `gcloud auth login` again
  - Check that you've enabled the required Google Cloud services
  - Verify your project billing is set up

### Getting Help
If you're stuck:
1. Check the error message carefully - it often tells you exactly what's wrong
2. Search for the exact error message online
3. Ask for help in programming communities like Stack Overflow
4. Review the documentation in the `docs/` folder

---

## Next Steps

### Once Everything is Working

#### 1. Customize Your Templates
- Open the `templates/` folder
- Edit the resume, cover letter, and response templates to match your style
- Test different formats to see what works best for your industry

#### 2. Add Your Work History
- Create a comprehensive profile in the `data/experience.yaml` file
- Include all your jobs, education, skills, and achievements
- The more detailed your profile, the better your generated documents will be

#### 3. Test with Real Job Postings
- Start with job postings from your target industry
- Generate documents and compare them to your manually created ones
- Adjust settings based on what works best

#### 4. Set Up Monitoring
- Check your Google Cloud console regularly for usage and costs
- Set up billing alerts to avoid unexpected charges
- Monitor your API usage to stay within free limits

### Advanced Features to Explore Later

#### 1. Batch Processing
- Learn to generate documents for multiple jobs at once
- Set up automated workflows for your job search

#### 2. Integration with Job Boards
- Connect your resume agent to job sites like LinkedIn or Indeed
- Automatically generate applications for relevant positions

#### 3. Analytics and Optimization
- Track which versions of your documents get the best response
- A/B test different approaches and styles

#### 4. Team Collaboration
- Share your resume agent with career counselors or mentors
- Get feedback and iterate on your documents

---

## Maintenance and Updates

### Regular Tasks
- **Weekly**: Check for new job postings and generate fresh documents
- **Monthly**: Review and update your experience data
- **Quarterly**: Update your API keys if needed and check for system updates

### Keeping Your System Secure
- Never share your API keys publicly
- Regularly update your passwords
- Keep your software and dependencies updated
- Monitor your cloud costs and usage

### Backup Your Data
- Regularly backup your `data/` folder
- Keep copies of your customized templates
- Export your generated documents regularly

---

## Conclusion

Congratulations! You've successfully deployed your own AI-powered resume agent. This system will save you hours of time and help you create more effective job applications.

Remember:
- **Practice makes perfect** - the more you use it, the better your results will be
- **Customize everything** - tailor the system to your specific needs and industry
- **Stay updated** - technology changes quickly, so keep learning and adapting
- **Have fun with it** - you've built something pretty amazing!

Your resume agent is now ready to help you land your dream job. Good luck with your job search!

---

## Quick Reference Commands

```bash
# Activate your environment
source venv/bin/activate  # Mac/Linux
venv\Scripts\activate     # Windows

# Run the web interface
make run-web

# Generate a resume via CLI
python -m src.cli generate resume --job-posting "job description here"

# Deploy to cloud
./scripts/deploy_cloud_run.sh

# Run tests
make test

# Update dependencies
pip install -r requirements.txt --upgrade
```

---

*This guide was created to help non-technical users successfully deploy and use the Enhanced Resume Agent 3.0. If you find any errors or have suggestions for improvement, please update this document to help future users.*