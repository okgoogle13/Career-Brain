import shutil
shutil.make_archive('enhanced-resume-agent-3.0', 'zip', 'enhanced-resume-agent-3.0')
print('Created zip file.')