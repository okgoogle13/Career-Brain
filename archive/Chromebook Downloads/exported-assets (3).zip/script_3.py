# Create configuration files
app_config_content = """# Application Configuration
app:
  name: "Enhanced Resume Agent 3.0"
  version: "3.0.0"
  description: "Production-grade AI-powered career document generation system"
  author: "Enhanced Resume Agent Team"
  debug: false
  environment: "production"
  
# Server Configuration
server:
  host: "0.0.0.0"
  port: 8000
  workers: 4
  reload: false
  
# Streamlit Configuration
streamlit:
  port: 8501
  max_upload_size: 10485760  # 10MB
  theme:
    primary_color: "#1f77b4"
    background_color: "#ffffff"
    secondary_background_color: "#f0f2f6"
    text_color: "#262730"
    
# Database Configuration
database:
  url: "sqlite:///./app.db"
  echo: false
  pool_size: 10
  max_overflow: 20
  
# Vector Store Configuration
vector_store:
  provider: "chromadb"
  persist_directory: "./chromadb_data"
  collection_name: "resume_agent_vectors"
  embedding_model: "all-MiniLM-L6-v2"
  chunk_size: 1000
  chunk_overlap: 200
  
# Document Processing
document_processing:
  max_file_size: 10485760  # 10MB
  allowed_extensions: [".pdf", ".docx", ".txt"]
  output_formats: ["pdf", "docx", "html"]
  
# Security
security:
  secret_key: "your-secret-key-here"
  algorithm: "HS256"
  access_token_expire_minutes: 30
  
# Rate Limiting
rate_limiting:
  enabled: true
  requests_per_minute: 100
  requests_per_hour: 1000
  
# Feature Flags
features:
  company_research: true
  ats_optimization: true
  real_time_feedback: true
  multi_language: false
  analytics: true
  
# Monitoring
monitoring:
  metrics_enabled: true
  health_check_interval: 30
  log_requests: true
"""

agent_config_content = """# Agent Configuration
agents:
  company_research:
    enabled: true
    model: "gemini-1.5-pro"
    temperature: 0.3
    max_tokens: 2048
    timeout: 30
    retry_attempts: 3
    
  resume_optimizer:
    enabled: true
    model: "gemini-1.5-pro"
    temperature: 0.2
    max_tokens: 4096
    ats_optimization: true
    keyword_density_target: 0.03
    
  cover_letter_generator:
    enabled: true
    model: "gemini-1.5-pro"
    temperature: 0.4
    max_tokens: 2048
    personalization_level: "high"
    
  ksc_responder:
    enabled: true
    model: "gemini-1.5-pro"
    temperature: 0.2
    max_tokens: 3072
    word_limit: 250
    
  nlp_engine:
    enabled: true
    spacy_model: "en_core_web_sm"
    sentence_transformer_model: "all-MiniLM-L6-v2"
    skill_extraction_threshold: 0.7
    
# Workflow Configuration
workflow:
  max_concurrent_agents: 3
  timeout_seconds: 300
  retry_policy:
    max_retries: 3
    backoff_factor: 2
    
# Model Configuration
models:
  gemini:
    model_name: "gemini-1.5-pro"
    temperature: 0.3
    max_output_tokens: 4096
    top_p: 0.8
    top_k: 40
    safety_settings:
      harassment: "BLOCK_MEDIUM_AND_ABOVE"
      hate_speech: "BLOCK_MEDIUM_AND_ABOVE"
      sexually_explicit: "BLOCK_MEDIUM_AND_ABOVE"
      dangerous_content: "BLOCK_MEDIUM_AND_ABOVE"
      
  perplexity:
    model: "pplx-70b-online"
    temperature: 0.3
    max_tokens: 2048
    top_p: 0.9
    
# Prompt Templates
prompts:
  company_research: |
    Research the following company and provide comprehensive information:
    Company: {company_name}
    
    Please provide:
    1. Company overview and mission
    2. Recent news and developments
    3. Company culture and values
    4. Key products/services
    5. Growth trajectory and market position
    
  resume_optimization: |
    Optimize the following resume for the job description:
    
    Job Description: {job_description}
    Current Resume: {current_resume}
    
    Please:
    1. Identify key skills and keywords from the job description
    2. Optimize the resume content to match job requirements
    3. Ensure ATS compatibility
    4. Maintain authenticity while improving relevance
    
  cover_letter_generation: |
    Generate a personalized cover letter:
    
    Job Description: {job_description}
    Company Information: {company_info}
    User Profile: {user_profile}
    
    Create a compelling cover letter that:
    1. Addresses the specific role and company
    2. Highlights relevant experience and achievements
    3. Demonstrates knowledge of the company
    4. Shows enthusiasm and cultural fit
"""

logging_config_content = """# Logging Configuration
version: 1
disable_existing_loggers: false

formatters:
  default:
    format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    datefmt: "%Y-%m-%d %H:%M:%S"
    
  detailed:
    format: "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s"
    datefmt: "%Y-%m-%d %H:%M:%S"
    
  json:
    format: "%(asctime)s"
    class: "pythonjsonlogger.jsonlogger.JsonFormatter"
    
handlers:
  console:
    class: logging.StreamHandler
    level: INFO
    formatter: default
    stream: ext://sys.stdout
    
  file:
    class: logging.handlers.RotatingFileHandler
    level: DEBUG
    formatter: detailed
    filename: logs/app.log
    maxBytes: 10485760  # 10MB
    backupCount: 5
    
  error_file:
    class: logging.handlers.RotatingFileHandler
    level: ERROR
    formatter: detailed
    filename: logs/errors.log
    maxBytes: 10485760  # 10MB
    backupCount: 5
    
loggers:
  src:
    level: DEBUG
    handlers: [console, file]
    propagate: false
    
  web:
    level: DEBUG
    handlers: [console, file]
    propagate: false
    
  src.agents:
    level: DEBUG
    handlers: [console, file]
    propagate: false
    
  src.integrations:
    level: DEBUG
    handlers: [console, file]
    propagate: false
    
  uvicorn:
    level: INFO
    handlers: [console, file]
    propagate: false
    
  streamlit:
    level: INFO
    handlers: [console, file]
    propagate: false
    
root:
  level: INFO
  handlers: [console, file]
"""

deployment_config_content = """# Deployment Configuration
deployment:
  environment: "production"
  platform: "google_cloud_run"
  
# Google Cloud Run Configuration
cloud_run:
  service_name: "enhanced-resume-agent"
  region: "us-central1"
  cpu: 2
  memory: "4Gi"
  timeout: 300
  concurrency: 100
  min_instances: 0
  max_instances: 10
  
  environment_variables:
    ENVIRONMENT: "production"
    DEBUG: "false"
    LOG_LEVEL: "INFO"
    
  secrets:
    - name: "GEMINI_API_KEY"
      version: "latest"
    - name: "PERPLEXITY_API_KEY"
      version: "latest"
    - name: "SECRET_KEY"
      version: "latest"
      
# Docker Configuration
docker:
  image_name: "enhanced-resume-agent"
  tag: "3.0"
  port: 8000
  health_check:
    path: "/health"
    interval: 30
    timeout: 5
    retries: 3
    
# Load Balancer Configuration
load_balancer:
  ssl_certificate: "managed"
  cdn_enabled: true
  
# Monitoring Configuration
monitoring:
  prometheus:
    enabled: true
    port: 9090
    
  grafana:
    enabled: true
    port: 3000
    
  alertmanager:
    enabled: true
    
# Backup Configuration
backup:
  enabled: true
  schedule: "0 2 * * *"  # Daily at 2 AM
  retention_days: 30
  
# Scaling Configuration
scaling:
  auto_scaling:
    enabled: true
    min_replicas: 1
    max_replicas: 10
    target_cpu_utilization: 70
    target_memory_utilization: 80
    
# Network Configuration
network:
  ingress: "all"
  egress: "all"
  
# Security Configuration
security:
  iam_policy: "roles/run.invoker"
  binary_authorization: false
  
# CI/CD Configuration
cicd:
  trigger_branch: "main"
  build_config: "cloudbuild.yaml"
  deploy_on_merge: true
  
# Development Configuration
development:
  hot_reload: true
  debug_mode: true
  profiling: true
"""

# Write configuration files
with open("enhanced-resume-agent-3.0/config/app_config.yaml", "w") as f:
    f.write(app_config_content)

with open("enhanced-resume-agent-3.0/config/agent_config.yaml", "w") as f:
    f.write(agent_config_content)

with open("enhanced-resume-agent-3.0/config/logging_config.yaml", "w") as f:
    f.write(logging_config_content)

with open("enhanced-resume-agent-3.0/config/deployment_config.yaml", "w") as f:
    f.write(deployment_config_content)

print("Created configuration files: app_config.yaml, agent_config.yaml, logging_config.yaml, deployment_config.yaml")