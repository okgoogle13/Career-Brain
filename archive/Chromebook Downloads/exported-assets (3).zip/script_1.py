# Let's create the requirements.txt file with all the core dependencies
requirements_content = """# Core Dependencies
fastapi==0.104.1
uvicorn[standard]==0.24.0
streamlit==1.28.1
click==8.1.7
typer==0.9.0

# AI & Language Models
google-generativeai==0.3.1
langchain==0.0.340
langchain-google-genai==0.0.6
sentence-transformers==2.2.2
spacy==3.7.2
transformers==4.35.2

# Data & Vector Stores
chromadb==0.4.15
faiss-cpu==1.7.4
sqlalchemy==2.0.23
pydantic==2.5.0
pydantic-settings==2.1.0

# Document Processing
jinja2==3.1.2
python-docx==1.1.0
PyMuPDF==1.23.8
pypdf==3.17.1
python-multipart==0.0.6

# Web & API
httpx==0.25.2
requests==2.31.0
aiohttp==3.9.1

# Development & Testing
pytest==7.4.3
pytest-asyncio==0.21.1
pytest-cov==4.1.0
pytest-mock==3.12.0

# Code Quality
black==23.11.0
isort==5.12.0
flake8==6.1.0
mypy==1.7.1
bandit==1.7.5

# Pre-commit & Automation
pre-commit==3.5.0
safety==2.3.5

# MLOps & Monitoring
mlflow==2.8.1

# Configuration & Environment
python-dotenv==1.0.0
pyyaml==6.0.1
toml==0.10.2

# Documentation
mkdocs==1.5.3
mkdocs-material==9.4.8
mkdocs-mermaid2-plugin==1.1.1

# Cloud & Deployment
google-cloud-run==0.8.0
google-cloud-storage==2.10.0
docker==6.1.3
"""

# Development-specific requirements
dev_requirements_content = """# Development Dependencies
-r requirements.txt

# Additional development tools
jupyter==1.0.0
ipython==8.17.2
notebook==7.0.6

# Advanced testing
factory-boy==3.3.0
faker==20.1.0
hypothesis==6.92.1

# Performance profiling
py-spy==0.3.14
memory-profiler==0.61.0

# Additional code quality tools
pylint==3.0.3
autopep8==2.0.4
vulture==2.10

# Documentation generation
sphinx==7.2.6
sphinx-rtd-theme==1.3.0
"""

# pyproject.toml file
pyproject_content = """[build-system]
requires = ["setuptools>=61.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "enhanced-resume-agent"
version = "3.0.0"
description = "Production-grade AI-powered career document generation system"
readme = "README.md"
requires-python = ">=3.11"
license = {text = "MIT"}
authors = [
    {name = "Enhanced Resume Agent Team", email = "team@enhanced-resume-agent.com"},
]
maintainers = [
    {name = "Enhanced Resume Agent Team", email = "team@enhanced-resume-agent.com"},
]
keywords = [
    "ai", "resume", "career", "nlp", "document-generation", 
    "job-application", "ats", "cover-letter", "gemini", "langchain"
]
classifiers = [
    "Development Status :: 4 - Beta",
    "Intended Audience :: Developers",
    "Intended Audience :: End Users/Desktop",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Topic :: Software Development :: Libraries :: Python Modules",
    "Topic :: Office/Business",
    "Topic :: Scientific/Engineering :: Artificial Intelligence",
    "Topic :: Text Processing :: General",
]
dependencies = [
    "fastapi>=0.104.1",
    "uvicorn[standard]>=0.24.0",
    "streamlit>=1.28.1",
    "click>=8.1.7",
    "typer>=0.9.0",
    "google-generativeai>=0.3.1",
    "langchain>=0.0.340",
    "sentence-transformers>=2.2.2",
    "spacy>=3.7.2",
    "chromadb>=0.4.15",
    "jinja2>=3.1.2",
    "python-docx>=1.1.0",
    "PyMuPDF>=1.23.8",
    "pydantic>=2.5.0",
    "python-dotenv>=1.0.0",
    "pyyaml>=6.0.1",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.4.3",
    "pytest-asyncio>=0.21.1",
    "pytest-cov>=4.1.0",
    "black>=23.11.0",
    "isort>=5.12.0",
    "flake8>=6.1.0",
    "mypy>=1.7.1",
    "pre-commit>=3.5.0",
    "jupyter>=1.0.0",
]
docs = [
    "mkdocs>=1.5.3",
    "mkdocs-material>=9.4.8",
    "mkdocs-mermaid2-plugin>=1.1.1",
]
cloud = [
    "google-cloud-run>=0.8.0",
    "google-cloud-storage>=2.10.0",
]

[project.urls]
Homepage = "https://github.com/enhanced-resume-agent/enhanced-resume-agent-3.0"
Documentation = "https://enhanced-resume-agent.readthedocs.io"
Repository = "https://github.com/enhanced-resume-agent/enhanced-resume-agent-3.0.git"
Issues = "https://github.com/enhanced-resume-agent/enhanced-resume-agent-3.0/issues"
Changelog = "https://github.com/enhanced-resume-agent/enhanced-resume-agent-3.0/blob/main/CHANGELOG.md"

[project.scripts]
resume-agent = "src.cli:main"
resume-agent-web = "web.streamlit_app:main"

[tool.setuptools]
package-dir = {"" = "."}

[tool.setuptools.packages.find]
where = ["."]
include = ["src*", "web*"]
exclude = ["tests*"]

[tool.black]
line-length = 88
target-version = ['py311']
include = '\\.pyi?$'
extend-exclude = '''
/(
  # directories
  \\.eggs
  | \\.git
  | \\.hg
  | \\.mypy_cache
  | \\.tox
  | \\.venv
  | _build
  | buck-out
  | build
  | dist
)/
'''

[tool.isort]
profile = "black"
multi_line_output = 3
line_length = 88
known_first_party = ["src", "web"]
known_third_party = ["fastapi", "streamlit", "langchain", "chromadb"]

[tool.mypy]
python_version = "3.11"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
disallow_incomplete_defs = true
check_untyped_defs = true
disallow_untyped_decorators = true
no_implicit_optional = true
warn_redundant_casts = true
warn_unused_ignores = true
warn_no_return = true
warn_unreachable = true
strict_equality = true
show_error_codes = true
show_error_context = true
pretty = true

[[tool.mypy.overrides]]
module = [
    "chromadb.*",
    "sentence_transformers.*",
    "spacy.*",
    "google.generativeai.*",
    "langchain.*",
    "streamlit.*",
    "plotly.*",
    "altair.*",
]
ignore_missing_imports = true

[tool.pytest.ini_options]
testpaths = ["tests"]
python_files = ["test_*.py", "*_test.py"]
python_classes = ["Test*"]
python_functions = ["test_*"]
addopts = [
    "-v",
    "--strict-markers",
    "--strict-config",
    "--cov=src",
    "--cov=web",
    "--cov-report=html",
    "--cov-report=term-missing",
    "--cov-fail-under=80",
]
markers = [
    "slow: marks tests as slow (deselect with '-m \"not slow\"')",
    "integration: marks tests as integration tests",
    "unit: marks tests as unit tests",
]
filterwarnings = [
    "ignore::DeprecationWarning",
    "ignore::PendingDeprecationWarning",
]

[tool.coverage.run]
source = ["src", "web"]
omit = [
    "*/tests/*",
    "*/test_*",
    "*/__pycache__/*",
    "*/venv/*",
    "*/env/*",
    "setup.py",
]

[tool.coverage.report]
exclude_lines = [
    "pragma: no cover",
    "def __repr__",
    "if self.debug:",
    "if settings.DEBUG",
    "raise AssertionError",
    "raise NotImplementedError",
    "if 0:",
    "if __name__ == .__main__.:",
    "class .*\\bProtocol\\):",
    "@(abc\\.)?abstractmethod",
]

[tool.bandit]
exclude_dirs = ["tests", "docs"]
skips = ["B101", "B601"]

[tool.flake8]
max-line-length = 88
extend-ignore = [
    "E203",  # whitespace before ':'
    "E501",  # line too long
    "W503",  # line break before binary operator
]
exclude = [
    ".git",
    "__pycache__",
    "build",
    "dist",
    ".venv",
    "venv",
    ".mypy_cache",
    ".pytest_cache",
]
per-file-ignores = [
    "__init__.py:F401",  # imported but unused
    "tests/*:S101",      # use of assert
]
"""

# Write the files
with open("enhanced-resume-agent-3.0/requirements.txt", "w") as f:
    f.write(requirements_content)

with open("enhanced-resume-agent-3.0/requirements-dev.txt", "w") as f:
    f.write(dev_requirements_content)

with open("enhanced-resume-agent-3.0/pyproject.toml", "w") as f:
    f.write(pyproject_content)

print("Created requirements.txt, requirements-dev.txt, and pyproject.toml")