# Create the .env.example file
env_example_content = """# API Keys
GEMINI_API_KEY=your_gemini_api_key_here
PERPLEXITY_API_KEY=your_perplexity_api_key_here
OPENAI_API_KEY=your_openai_api_key_here

# Environment
ENVIRONMENT=development
DEBUG=true
LOG_LEVEL=INFO

# Database
DATABASE_URL=sqlite:///./app.db
CHROMADB_PERSIST_DIR=./chromadb_data
VECTOR_STORE_COLLECTION=resume_agent_vectors

# Application Settings
APP_NAME=Enhanced Resume Agent 3.0
APP_VERSION=3.0.0
APP_DESCRIPTION=Production-grade AI-powered career document generation system
MAX_UPLOAD_SIZE=10485760  # 10MB
ALLOWED_FILE_TYPES=pdf,docx,txt

# Security
SECRET_KEY=your_secret_key_here
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Google Cloud
GOOGLE_CLOUD_PROJECT=your_project_id
GOOGLE_CLOUD_REGION=us-central1
GOOGLE_APPLICATION_CREDENTIALS=path/to/service-account-key.json

# Monitoring & Logging
MLFLOW_TRACKING_URI=http://localhost:5000
SENTRY_DSN=your_sentry_dsn_here

# Cache Settings
REDIS_URL=redis://localhost:6379
CACHE_TTL=3600

# Rate Limiting
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=60

# Feature Flags
ENABLE_COMPANY_RESEARCH=true
ENABLE_ATS_OPTIMIZATION=true
ENABLE_REAL_TIME_FEEDBACK=true
ENABLE_MULTI_LANGUAGE=false
"""

# Create the .gitignore file
gitignore_content = """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# PyInstaller
*.manifest
*.spec

# Installer logs
pip-log.txt
pip-delete-this-directory.txt

# Unit test / coverage reports
htmlcov/
.tox/
.nox/
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover
*.py,cover
.hypothesis/
.pytest_cache/

# Virtual environments
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# OS
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# Project specific
chromadb_data/
logs/
temp/
uploads/
downloads/
*.log
*.db
*.sqlite3

# MLflow
mlruns/
mlflow.db

# Jupyter
.ipynb_checkpoints

# Docker
.dockerignore

# Documentation
docs/site/
site/

# Streamlit
.streamlit/
streamlit_app.log

# Google Cloud
service-account-key.json
credentials.json
"""

# Create the .dockerignore file  
dockerignore_content = """# Python
__pycache__
*.pyc
*.pyo
*.pyd
.Python
pip-log.txt
pip-delete-this-directory.txt
.tox
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover
*.log
.git
.mypy_cache
.pytest_cache
.hypothesis

# Virtual environments
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# OS
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# Project specific
chromadb_data/
logs/
temp/
uploads/
downloads/
*.db
*.sqlite3

# Documentation
docs/
README.md
CHANGELOG.md
CONTRIBUTING.md
LICENSE

# Testing
tests/
.pytest_cache/
htmlcov/

# Development
requirements-dev.txt
.pre-commit-config.yaml
scripts/
"""

# Create the pre-commit configuration
precommit_content = """repos:
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.5.0
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
      - id: check-yaml
      - id: check-added-large-files
      - id: check-merge-conflict
      - id: check-case-conflict
      - id: check-docstring-first
      - id: check-json
      - id: check-toml
      - id: debug-statements
      - id: requirements-txt-fixer

  - repo: https://github.com/psf/black
    rev: 23.11.0
    hooks:
      - id: black
        language_version: python3.11

  - repo: https://github.com/pycqa/isort
    rev: 5.12.0
    hooks:
      - id: isort
        args: ["--profile", "black"]

  - repo: https://github.com/pycqa/flake8
    rev: 6.1.0
    hooks:
      - id: flake8
        additional_dependencies: [flake8-docstrings]

  - repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.7.1
    hooks:
      - id: mypy
        additional_dependencies: [types-requests, types-PyYAML, types-toml]
        exclude: ^(tests/|docs/)

  - repo: https://github.com/pycqa/bandit
    rev: 1.7.5
    hooks:
      - id: bandit
        args: ["-c", "pyproject.toml"]
        additional_dependencies: ["bandit[toml]"]

  - repo: https://github.com/Lucas-C/pre-commit-hooks-safety
    rev: v1.3.2
    hooks:
      - id: python-safety-dependencies-check

  - repo: https://github.com/pycqa/pylint
    rev: v3.0.3
    hooks:
      - id: pylint
        additional_dependencies: [pylint-pydantic]
        files: ^src/
"""

# Create Makefile
makefile_content = """# Enhanced Resume Agent 3.0 - Makefile

.PHONY: help install install-dev test test-cov lint format clean build run run-web docker-build docker-run deploy docs

# Variables
PYTHON := python3.11
PIP := pip
VENV := venv
SRC_DIR := src
WEB_DIR := web
TESTS_DIR := tests
DOCS_DIR := docs

# Help
help:
	@echo "Enhanced Resume Agent 3.0 - Available commands:"
	@echo ""
	@echo "  Setup:"
	@echo "    install      Install production dependencies"
	@echo "    install-dev  Install development dependencies"
	@echo "    setup        Setup development environment"
	@echo ""
	@echo "  Development:"
	@echo "    test         Run tests"
	@echo "    test-cov     Run tests with coverage"
	@echo "    lint         Run linting checks"
	@echo "    format       Format code"
	@echo "    clean        Clean build artifacts"
	@echo ""
	@echo "  Running:"
	@echo "    run          Run CLI application"
	@echo "    run-web      Run Streamlit web application"
	@echo "    run-api      Run FastAPI server"
	@echo ""
	@echo "  Docker:"
	@echo "    docker-build Build Docker image"
	@echo "    docker-run   Run Docker container"
	@echo ""
	@echo "  Deployment:"
	@echo "    build        Build distribution packages"
	@echo "    deploy       Deploy to Google Cloud Run"
	@echo "    docs         Build documentation"
	@echo "    serve-docs   Serve documentation locally"

# Setup
install:
	$(PIP) install -r requirements.txt

install-dev:
	$(PIP) install -r requirements-dev.txt
	pre-commit install

setup: install-dev
	$(PYTHON) -m spacy download en_core_web_sm
	@echo "Development environment setup complete!"

# Development
test:
	pytest $(TESTS_DIR) -v

test-cov:
	pytest $(TESTS_DIR) --cov=$(SRC_DIR) --cov=$(WEB_DIR) --cov-report=html --cov-report=term-missing

lint:
	flake8 $(SRC_DIR) $(WEB_DIR) $(TESTS_DIR)
	mypy $(SRC_DIR) $(WEB_DIR)
	bandit -r $(SRC_DIR) -c pyproject.toml

format:
	black $(SRC_DIR) $(WEB_DIR) $(TESTS_DIR)
	isort $(SRC_DIR) $(WEB_DIR) $(TESTS_DIR)

clean:
	find . -type f -name "*.pyc" -delete
	find . -type d -name "__pycache__" -delete
	find . -type d -name "*.egg-info" -exec rm -rf {} +
	rm -rf build/
	rm -rf dist/
	rm -rf .pytest_cache/
	rm -rf .mypy_cache/
	rm -rf htmlcov/
	rm -rf .coverage

# Running
run:
	$(PYTHON) -m src.cli

run-web:
	streamlit run $(WEB_DIR)/streamlit_app.py

run-api:
	uvicorn src.main:app --reload --host 0.0.0.0 --port 8000

# Docker
docker-build:
	docker build -t enhanced-resume-agent:3.0 .

docker-run:
	docker run -p 8000:8000 -p 8501:8501 enhanced-resume-agent:3.0

docker-compose-up:
	docker-compose up --build

docker-compose-down:
	docker-compose down

# Deployment
build:
	$(PYTHON) -m build

deploy:
	./scripts/deploy_cloud_run.sh

# Documentation
docs:
	cd $(DOCS_DIR) && mkdocs build

serve-docs:
	cd $(DOCS_DIR) && mkdocs serve

# Pre-commit
pre-commit:
	pre-commit run --all-files

# Database
init-db:
	$(PYTHON) -c "from src.data.models import init_db; init_db()"

# Development utilities
freeze:
	$(PIP) freeze > requirements.txt

check-deps:
	$(PIP) check
	safety check

# Performance
profile:
	py-spy top --pid $$(pgrep -f "streamlit run")

# Security
security-scan:
	bandit -r $(SRC_DIR) -c pyproject.toml
	safety check
	$(PYTHON) -m pip_audit

# MLflow
mlflow-ui:
	mlflow ui

# Streamlit specific
streamlit-config:
	mkdir -p ~/.streamlit
	echo '[general]' > ~/.streamlit/config.toml
	echo 'developmentMode = false' >> ~/.streamlit/config.toml

# All-in-one commands
dev-setup: setup streamlit-config init-db
	@echo "Complete development setup finished!"

ci-test: lint test-cov security-scan
	@echo "CI pipeline tests completed!"

release: clean build
	@echo "Release build completed!"
"""

# Write the files
with open("enhanced-resume-agent-3.0/.env.example", "w") as f:
    f.write(env_example_content)

with open("enhanced-resume-agent-3.0/.gitignore", "w") as f:
    f.write(gitignore_content)

with open("enhanced-resume-agent-3.0/.dockerignore", "w") as f:
    f.write(dockerignore_content)

with open("enhanced-resume-agent-3.0/.pre-commit-config.yaml", "w") as f:
    f.write(precommit_content)

with open("enhanced-resume-agent-3.0/Makefile", "w") as f:
    f.write(makefile_content)

print("Created .env.example, .gitignore, .dockerignore, .pre-commit-config.yaml, and Makefile")