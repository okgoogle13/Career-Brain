import os
import json
from pathlib import Path

# Create the enhanced resume agent 3.0 project structure
project_structure = {
    "enhanced-resume-agent-3.0": {
        "src": {
            "agents": {
                "__init__.py": "",
                "company_research.py": "",
                "resume_optimizer.py": "",
                "cover_letter_generator.py": "",
                "ksc_responder.py": "",
                "nlp_engine.py": "",
                "orchestrator.py": ""
            },
            "integrations": {
                "__init__.py": "",
                "gemini_service.py": "",
                "perplexity_service.py": "",
                "base_service.py": ""
            },
            "data": {
                "__init__.py": "",
                "vector_store.py": "",
                "yaml_manager.py": "",
                "models.py": ""
            },
            "utils": {
                "__init__.py": "",
                "logger.py": "",
                "config.py": "",
                "validators.py": ""
            },
            "__init__.py": "",
            "cli.py": "",
            "main.py": ""
        },
        "web": {
            "__init__.py": "",
            "streamlit_app.py": "",
            "pages": {
                "__init__.py": "",
                "home.py": "",
                "user_profile.py": "",
                "job_analysis.py": "",
                "document_generation.py": "",
                "results.py": ""
            },
            "components": {
                "__init__.py": "",
                "sidebar.py": "",
                "forms.py": "",
                "charts.py": ""
            }
        },
        "templates": {
            "resumes": {
                "modern_resume.jinja2": "",
                "professional_resume.jinja2": "",
                "technical_resume.jinja2": ""
            },
            "cover_letters": {
                "standard_cover_letter.jinja2": "",
                "technical_cover_letter.jinja2": ""
            },
            "ksc": {
                "government_ksc.jinja2": "",
                "corporate_ksc.jinja2": ""
            }
        },
        "config": {
            "app_config.yaml": "",
            "agent_config.yaml": "",
            "logging_config.yaml": "",
            "deployment_config.yaml": ""
        },
        "data": {
            "experience_templates": {
                "software_engineer.yaml": "",
                "data_scientist.yaml": "",
                "product_manager.yaml": ""
            },
            "industry_keywords": {
                "tech.yaml": "",
                "healthcare.yaml": "",
                "finance.yaml": ""
            }
        },
        "tests": {
            "__init__.py": "",
            "test_agents": {
                "__init__.py": "",
                "test_company_research.py": "",
                "test_resume_optimizer.py": "",
                "test_cover_letter_generator.py": "",
                "test_ksc_responder.py": "",
                "test_nlp_engine.py": ""
            },
            "test_integrations": {
                "__init__.py": "",
                "test_gemini_service.py": "",
                "test_perplexity_service.py": ""
            },
            "test_data": {
                "__init__.py": "",
                "test_vector_store.py": "",
                "test_yaml_manager.py": ""
            },
            "test_utils": {
                "__init__.py": "",
                "test_config.py": "",
                "test_validators.py": ""
            },
            "test_cli.py": "",
            "conftest.py": ""
        },
        "docs": {
            "mkdocs.yml": "",
            "docs": {
                "index.md": "",
                "installation.md": "",
                "quick-start.md": "",
                "user-guide": {
                    "getting-started.md": "",
                    "configuration.md": "",
                    "cli-usage.md": "",
                    "web-interface.md": ""
                },
                "developer-guide": {
                    "architecture.md": "",
                    "api-reference.md": "",
                    "contributing.md": "",
                    "deployment.md": ""
                },
                "examples": {
                    "basic-usage.md": "",
                    "advanced-features.md": "",
                    "custom-templates.md": ""
                }
            }
        },
        "scripts": {
            "setup.py": "",
            "build_docker.sh": "",
            "deploy_cloud_run.sh": "",
            "run_tests.sh": "",
            "format_code.sh": ""
        },
        ".github": {
            "workflows": {
                "ci-cd.yml": "",
                "security-scan.yml": "",
                "docs-deploy.yml": ""
            },
            "ISSUE_TEMPLATE": {
                "bug_report.md": "",
                "feature_request.md": ""
            },
            "PULL_REQUEST_TEMPLATE.md": ""
        },
        "requirements.txt": "",
        "requirements-dev.txt": "",
        "pyproject.toml": "",
        "Dockerfile": "",
        "docker-compose.yml": "",
        ".dockerignore": "",
        ".env.example": "",
        ".gitignore": "",
        ".pre-commit-config.yaml": "",
        "Makefile": "",
        "README.md": "",
        "ARCHITECTURE.md": "",
        "CONTRIBUTING.md": "",
        "LICENSE": "",
        "CHANGELOG.md": ""
    }
}

# Function to create directory structure
def create_structure(base_path, structure):
    for name, content in structure.items():
        path = base_path / name
        if isinstance(content, dict):
            path.mkdir(parents=True, exist_ok=True)
            create_structure(path, content)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            # Create empty file for now
            path.write_text("")

# Create the project structure
base_path = Path(".")
create_structure(base_path, project_structure)

print("Created Enhanced Resume Agent 3.0 project structure")
print("\nDirectory structure:")
for root, dirs, files in os.walk("enhanced-resume-agent-3.0"):
    level = root.replace("enhanced-resume-agent-3.0", "").count(os.sep)
    indent = " " * 2 * level
    print(f"{indent}{os.path.basename(root)}/")
    subindent = " " * 2 * (level + 1)
    for file in files:
        print(f"{subindent}{file}")