# Create utility files

# config.py - Configuration management
config_py_content = '''"""Configuration management for Enhanced Resume Agent 3.0."""

import os
from pathlib import Path
from typing import Any, Dict, Optional

import yaml
from pydantic import BaseSettings, Field


class Settings(BaseSettings):
    """Application settings with environment variable support."""
    
    # Application
    app_name: str = Field(default="Enhanced Resume Agent 3.0", env="APP_NAME")
    app_version: str = Field(default="3.0.0", env="APP_VERSION")
    environment: str = Field(default="development", env="ENVIRONMENT")
    debug: bool = Field(default=False, env="DEBUG")
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    
    # API Keys
    gemini_api_key: str = Field(..., env="GEMINI_API_KEY")
    perplexity_api_key: str = Field(..., env="PERPLEXITY_API_KEY")
    openai_api_key: Optional[str] = Field(None, env="OPENAI_API_KEY")
    
    # Database
    database_url: str = Field(default="sqlite:///./app.db", env="DATABASE_URL")
    chromadb_persist_dir: str = Field(default="./chromadb_data", env="CHROMADB_PERSIST_DIR")
    vector_store_collection: str = Field(default="resume_agent_vectors", env="VECTOR_STORE_COLLECTION")
    
    # Security
    secret_key: str = Field(..., env="SECRET_KEY")
    algorithm: str = Field(default="HS256", env="ALGORITHM")
    access_token_expire_minutes: int = Field(default=30, env="ACCESS_TOKEN_EXPIRE_MINUTES")
    
    # Google Cloud
    google_cloud_project: Optional[str] = Field(None, env="GOOGLE_CLOUD_PROJECT")
    google_cloud_region: str = Field(default="us-central1", env="GOOGLE_CLOUD_REGION")
    google_application_credentials: Optional[str] = Field(None, env="GOOGLE_APPLICATION_CREDENTIALS")
    
    # Feature Flags
    enable_company_research: bool = Field(default=True, env="ENABLE_COMPANY_RESEARCH")
    enable_ats_optimization: bool = Field(default=True, env="ENABLE_ATS_OPTIMIZATION")
    enable_real_time_feedback: bool = Field(default=True, env="ENABLE_REAL_TIME_FEEDBACK")
    enable_multi_language: bool = Field(default=False, env="ENABLE_MULTI_LANGUAGE")
    
    # Rate Limiting
    rate_limit_requests: int = Field(default=100, env="RATE_LIMIT_REQUESTS")
    rate_limit_window: int = Field(default=60, env="RATE_LIMIT_WINDOW")
    
    # File Upload
    max_upload_size: int = Field(default=10485760, env="MAX_UPLOAD_SIZE")  # 10MB
    allowed_file_types: str = Field(default="pdf,docx,txt", env="ALLOWED_FILE_TYPES")
    
    # MLflow
    mlflow_tracking_uri: str = Field(default="http://localhost:5000", env="MLFLOW_TRACKING_URI")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


class ConfigManager:
    """Manages application configuration from YAML files and environment variables."""
    
    def __init__(self, config_dir: str = "config"):
        self.config_dir = Path(config_dir)
        self.settings = Settings()
        self._configs: Dict[str, Any] = {}
        self._load_configs()
    
    def _load_configs(self) -> None:
        """Load all YAML configuration files."""
        config_files = [
            "app_config.yaml",
            "agent_config.yaml",
            "logging_config.yaml",
            "deployment_config.yaml"
        ]
        
        for config_file in config_files:
            config_path = self.config_dir / config_file
            if config_path.exists():
                with open(config_path, 'r', encoding='utf-8') as f:
                    config_name = config_file.replace('.yaml', '')
                    self._configs[config_name] = yaml.safe_load(f)
    
    def get_config(self, config_name: str) -> Dict[str, Any]:
        """Get configuration by name."""
        return self._configs.get(config_name, {})
    
    def get_app_config(self) -> Dict[str, Any]:
        """Get application configuration."""
        return self.get_config("app_config")
    
    def get_agent_config(self) -> Dict[str, Any]:
        """Get agent configuration."""
        return self.get_config("agent_config")
    
    def get_logging_config(self) -> Dict[str, Any]:
        """Get logging configuration."""
        return self.get_config("logging_config")
    
    def get_deployment_config(self) -> Dict[str, Any]:
        """Get deployment configuration."""
        return self.get_config("deployment_config")
    
    def get_setting(self, key: str, default: Any = None) -> Any:
        """Get a setting value."""
        return getattr(self.settings, key, default)
    
    def is_development(self) -> bool:
        """Check if running in development environment."""
        return self.settings.environment == "development"
    
    def is_production(self) -> bool:
        """Check if running in production environment."""
        return self.settings.environment == "production"
    
    def get_allowed_file_types(self) -> list[str]:
        """Get list of allowed file types."""
        return self.settings.allowed_file_types.split(',')


# Global configuration instance
config = ConfigManager()
'''

# logger.py - Logging configuration
logger_py_content = '''"""Logging configuration for Enhanced Resume Agent 3.0."""

import logging
import logging.config
import sys
from pathlib import Path
from typing import Any, Dict, Optional

import yaml
from pythonjsonlogger import jsonlogger


class LoggerManager:
    """Manages application logging configuration."""
    
    def __init__(self, config_path: str = "config/logging_config.yaml"):
        self.config_path = Path(config_path)
        self._setup_logging()
    
    def _setup_logging(self) -> None:
        """Setup logging configuration."""
        # Create logs directory if it doesn't exist
        logs_dir = Path("logs")
        logs_dir.mkdir(exist_ok=True)
        
        # Load logging configuration
        if self.config_path.exists():
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
                logging.config.dictConfig(config)
        else:
            # Fallback to basic configuration
            logging.basicConfig(
                level=logging.INFO,
                format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                handlers=[
                    logging.StreamHandler(sys.stdout),
                    logging.FileHandler('logs/app.log')
                ]
            )
    
    def get_logger(self, name: str) -> logging.Logger:
        """Get a logger instance."""
        return logging.getLogger(name)


class StructuredLogger:
    """Structured logging with context support."""
    
    def __init__(self, name: str, context: Optional[Dict[str, Any]] = None):
        self.logger = logging.getLogger(name)
        self.context = context or {}
    
    def _log(self, level: int, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        """Log message with context."""
        log_extra = self.context.copy()
        if extra:
            log_extra.update(extra)
        
        self.logger.log(level, message, extra=log_extra)
    
    def debug(self, message: str, **kwargs) -> None:
        """Log debug message."""
        self._log(logging.DEBUG, message, kwargs)
    
    def info(self, message: str, **kwargs) -> None:
        """Log info message."""
        self._log(logging.INFO, message, kwargs)
    
    def warning(self, message: str, **kwargs) -> None:
        """Log warning message."""
        self._log(logging.WARNING, message, kwargs)
    
    def error(self, message: str, **kwargs) -> None:
        """Log error message."""
        self._log(logging.ERROR, message, kwargs)
    
    def critical(self, message: str, **kwargs) -> None:
        """Log critical message."""
        self._log(logging.CRITICAL, message, kwargs)
    
    def exception(self, message: str, **kwargs) -> None:
        """Log exception with traceback."""
        self._log(logging.ERROR, message, kwargs)
        self.logger.exception(message)


class AgentLogger:
    """Specialized logger for AI agents."""
    
    def __init__(self, agent_name: str):
        self.agent_name = agent_name
        self.logger = StructuredLogger(f"src.agents.{agent_name}")
    
    def log_agent_start(self, task: str, inputs: Dict[str, Any]) -> None:
        """Log agent task start."""
        self.logger.info(
            f"Agent {self.agent_name} started task: {task}",
            agent=self.agent_name,
            task=task,
            inputs=inputs
        )
    
    def log_agent_completion(self, task: str, outputs: Dict[str, Any], 
                           duration: float) -> None:
        """Log agent task completion."""
        self.logger.info(
            f"Agent {self.agent_name} completed task: {task}",
            agent=self.agent_name,
            task=task,
            outputs=outputs,
            duration=duration
        )
    
    def log_agent_error(self, task: str, error: Exception) -> None:
        """Log agent error."""
        self.logger.error(
            f"Agent {self.agent_name} error in task: {task}",
            agent=self.agent_name,
            task=task,
            error=str(error),
            error_type=type(error).__name__
        )


class APILogger:
    """Specialized logger for API calls."""
    
    def __init__(self, service_name: str):
        self.service_name = service_name
        self.logger = StructuredLogger(f"src.integrations.{service_name}")
    
    def log_api_request(self, endpoint: str, method: str, 
                       params: Dict[str, Any]) -> None:
        """Log API request."""
        self.logger.info(
            f"API request to {self.service_name}",
            service=self.service_name,
            endpoint=endpoint,
            method=method,
            params=params
        )
    
    def log_api_response(self, endpoint: str, status_code: int, 
                        duration: float) -> None:
        """Log API response."""
        self.logger.info(
            f"API response from {self.service_name}",
            service=self.service_name,
            endpoint=endpoint,
            status_code=status_code,
            duration=duration
        )
    
    def log_api_error(self, endpoint: str, error: Exception) -> None:
        """Log API error."""
        self.logger.error(
            f"API error from {self.service_name}",
            service=self.service_name,
            endpoint=endpoint,
            error=str(error),
            error_type=type(error).__name__
        )


# Global logger manager
logger_manager = LoggerManager()

# Convenience functions
def get_logger(name: str) -> logging.Logger:
    """Get a logger instance."""
    return logger_manager.get_logger(name)

def get_structured_logger(name: str, context: Optional[Dict[str, Any]] = None) -> StructuredLogger:
    """Get a structured logger instance."""
    return StructuredLogger(name, context)

def get_agent_logger(agent_name: str) -> AgentLogger:
    """Get an agent logger instance."""
    return AgentLogger(agent_name)

def get_api_logger(service_name: str) -> APILogger:
    """Get an API logger instance."""
    return APILogger(service_name)
'''

# validators.py - Input validation
validators_py_content = '''"""Input validation utilities for Enhanced Resume Agent 3.0."""

import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field, validator


class JobDescriptionValidator(BaseModel):
    """Validator for job description input."""
    
    title: str = Field(..., min_length=1, max_length=200)
    company: str = Field(..., min_length=1, max_length=100)
    description: str = Field(..., min_length=50, max_length=50000)
    requirements: Optional[str] = Field(None, max_length=10000)
    benefits: Optional[str] = Field(None, max_length=5000)
    location: Optional[str] = Field(None, max_length=100)
    salary_range: Optional[str] = Field(None, max_length=100)
    employment_type: Optional[str] = Field(None, max_length=50)
    
    @validator('title')
    def validate_title(cls, v):
        if not v.strip():
            raise ValueError('Job title cannot be empty')
        return v.strip()
    
    @validator('company')
    def validate_company(cls, v):
        if not v.strip():
            raise ValueError('Company name cannot be empty')
        return v.strip()
    
    @validator('description')
    def validate_description(cls, v):
        if len(v.strip()) < 50:
            raise ValueError('Job description must be at least 50 characters long')
        return v.strip()


class UserProfileValidator(BaseModel):
    """Validator for user profile input."""
    
    name: str = Field(..., min_length=1, max_length=100)
    email: str = Field(..., regex=r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    phone: Optional[str] = Field(None, max_length=20)
    location: Optional[str] = Field(None, max_length=100)
    summary: Optional[str] = Field(None, max_length=2000)
    skills: List[str] = Field(default_factory=list)
    experience: List[Dict[str, Any]] = Field(default_factory=list)
    education: List[Dict[str, Any]] = Field(default_factory=list)
    
    @validator('name')
    def validate_name(cls, v):
        if not v.strip():
            raise ValueError('Name cannot be empty')
        if not re.match(r'^[a-zA-Z\s\-\.]+$', v.strip()):
            raise ValueError('Name can only contain letters, spaces, hyphens, and periods')
        return v.strip()
    
    @validator('phone')
    def validate_phone(cls, v):
        if v is None:
            return v
        phone_pattern = r'^\+?[\d\s\-\(\)]{7,20}$'
        if not re.match(phone_pattern, v):
            raise ValueError('Invalid phone number format')
        return v
    
    @validator('skills')
    def validate_skills(cls, v):
        if len(v) > 50:
            raise ValueError('Maximum 50 skills allowed')
        return [skill.strip() for skill in v if skill.strip()]


class DocumentValidator(BaseModel):
    """Validator for document input."""
    
    content: str = Field(..., min_length=1)
    document_type: str = Field(..., regex=r'^(resume|cover_letter|ksc)$')
    format: str = Field(default='text', regex=r'^(text|markdown|html)$')
    
    @validator('content')
    def validate_content(cls, v):
        if not v.strip():
            raise ValueError('Document content cannot be empty')
        if len(v) > 100000:  # 100KB limit
            raise ValueError('Document content too large')
        return v.strip()


class FileValidator:
    """Validator for file uploads."""
    
    ALLOWED_EXTENSIONS = {'.pdf', '.docx', '.txt', '.doc'}
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
    
    @classmethod
    def validate_file(cls, file_path: Union[str, Path]) -> bool:
        """Validate file extension and size."""
        path = Path(file_path)
        
        # Check if file exists
        if not path.exists():
            raise ValueError(f"File does not exist: {file_path}")
        
        # Check file extension
        if path.suffix.lower() not in cls.ALLOWED_EXTENSIONS:
            raise ValueError(f"File type not allowed: {path.suffix}")
        
        # Check file size
        file_size = path.stat().st_size
        if file_size > cls.MAX_FILE_SIZE:
            raise ValueError(f"File too large: {file_size} bytes")
        
        return True
    
    @classmethod
    def validate_filename(cls, filename: str) -> bool:
        """Validate filename format."""
        # Check for valid characters
        if not re.match(r'^[a-zA-Z0-9._\-\s]+$', filename):
            raise ValueError("Filename contains invalid characters")
        
        # Check length
        if len(filename) > 255:
            raise ValueError("Filename too long")
        
        return True


class ConfigValidator:
    """Validator for configuration values."""
    
    @staticmethod
    def validate_api_key(api_key: str, service_name: str) -> bool:
        """Validate API key format."""
        if not api_key or not api_key.strip():
            raise ValueError(f"{service_name} API key cannot be empty")
        
        # Basic length check
        if len(api_key) < 10:
            raise ValueError(f"{service_name} API key too short")
        
        return True
    
    @staticmethod
    def validate_url(url: str) -> bool:
        """Validate URL format."""
        url_pattern = r'^https?://[^\s/$.?#].[^\s]*$'
        if not re.match(url_pattern, url):
            raise ValueError("Invalid URL format")
        return True
    
    @staticmethod
    def validate_environment(env: str) -> bool:
        """Validate environment value."""
        valid_envs = {'development', 'staging', 'production'}
        if env not in valid_envs:
            raise ValueError(f"Environment must be one of: {valid_envs}")
        return True


class BusinessRuleValidator:
    """Validator for business rules."""
    
    @staticmethod
    def validate_resume_length(content: str) -> bool:
        """Validate resume content length."""
        word_count = len(content.split())
        if word_count < 100:
            raise ValueError("Resume too short (minimum 100 words)")
        if word_count > 2000:
            raise ValueError("Resume too long (maximum 2000 words)")
        return True
    
    @staticmethod
    def validate_cover_letter_length(content: str) -> bool:
        """Validate cover letter content length."""
        word_count = len(content.split())
        if word_count < 50:
            raise ValueError("Cover letter too short (minimum 50 words)")
        if word_count > 500:
            raise ValueError("Cover letter too long (maximum 500 words)")
        return True
    
    @staticmethod
    def validate_ksc_response_length(content: str, word_limit: int = 250) -> bool:
        """Validate KSC response content length."""
        word_count = len(content.split())
        if word_count > word_limit:
            raise ValueError(f"KSC response too long (maximum {word_limit} words)")
        return True
    
    @staticmethod
    def validate_skills_match(user_skills: List[str], job_requirements: str) -> float:
        """Validate and calculate skills match percentage."""
        if not user_skills:
            return 0.0
        
        # Simple keyword matching (to be enhanced with NLP)
        job_requirements_lower = job_requirements.lower()
        matched_skills = [
            skill for skill in user_skills 
            if skill.lower() in job_requirements_lower
        ]
        
        return len(matched_skills) / len(user_skills) * 100
'''

# Write the utility files
with open("enhanced-resume-agent-3.0/src/utils/config.py", "w") as f:
    f.write(config_py_content)

with open("enhanced-resume-agent-3.0/src/utils/logger.py", "w") as f:
    f.write(logger_py_content)

with open("enhanced-resume-agent-3.0/src/utils/validators.py", "w") as f:
    f.write(validators_py_content)

# Create __init__.py files
init_content = '''"""Enhanced Resume Agent 3.0 - Utils module."""

from .config import ConfigManager, Settings, config
from .logger import (
    LoggerManager, 
    StructuredLogger, 
    AgentLogger, 
    APILogger,
    get_logger,
    get_structured_logger,
    get_agent_logger,
    get_api_logger
)
from .validators import (
    JobDescriptionValidator,
    UserProfileValidator,
    DocumentValidator,
    FileValidator,
    ConfigValidator,
    BusinessRuleValidator
)

__all__ = [
    "ConfigManager",
    "Settings", 
    "config",
    "LoggerManager",
    "StructuredLogger",
    "AgentLogger", 
    "APILogger",
    "get_logger",
    "get_structured_logger",
    "get_agent_logger",
    "get_api_logger",
    "JobDescriptionValidator",
    "UserProfileValidator", 
    "DocumentValidator",
    "FileValidator",
    "ConfigValidator",
    "BusinessRuleValidator",
]
'''

with open("enhanced-resume-agent-3.0/src/utils/__init__.py", "w") as f:
    f.write(init_content)

print("Created utility files: config.py, logger.py, validators.py and __init__.py")