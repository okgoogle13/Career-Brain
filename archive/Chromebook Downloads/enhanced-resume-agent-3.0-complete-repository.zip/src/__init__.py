"""
Enhanced Resume Agent 3.0
AI-powered career document generation system for personal use.
"""

__version__ = "3.0.0"
__author__ = "Enhanced Resume Agent Team"
__description__ = "AI-powered career document generation system"

from .utils.config import Config
from .utils.logger import get_logger

# Initialize logging
logger = get_logger(__name__)

def get_version() -> str:
    """Return the current version."""
    return __version__
