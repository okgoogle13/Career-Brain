# Enhanced Resume Agent 3.0 - Setup Instructions

## Quick Setup Guide

1. **Extract this repository:**
   - Extract all files to your desired location
   - Navigate to the extracted directory

2. **Set up Python environment:**
   ```bash
   # Check Python version (requires 3.11+)
   python --version

   # Install dependencies
   pip install -r requirements.txt
   ```

3. **Configure API keys:**
   ```bash
   # Copy environment template
   cp .env.example .env

   # Edit .env file with your API keys:
   # GOOGLE_GEMINI_API_KEY=your_gemini_api_key_here
   # PERPLEXITY_API_KEY=your_perplexity_api_key_here
   ```

4. **Initialize the system:**
   ```bash
   # Initialize your profile
   python -m src.cli init --email your@email.com --name "Your Name"

   # Check system status
   python -m src.cli status
   ```

5. **Start using the system:**
   ```bash
   # Web interface (recommended)
   python -m src.cli web
   # Opens http://localhost:8501

   # Or use CLI commands
   python -m src.cli --help
   ```

## API Key Setup

### Google Gemini API Key:
1. Go to https://makersuite.google.com/app/apikey
2. Create a new API key
3. Add it to your .env file

### Perplexity API Key:
1. Go to https://www.perplexity.ai/settings/api
2. Generate an API key
3. Add it to your .env file

## Troubleshooting

- **Import errors:** Make sure you're in the repository root directory
- **API errors:** Verify your API keys are correctly set in .env
- **Permission errors:** Ensure Python has write access to ~/.resume_agent/

## Next Steps

1. Add your work experiences via web interface or CLI
2. Research companies you're interested in
3. Generate optimized resumes and cover letters
4. Track your job applications

For detailed documentation, see README.md and the docs/ folder.

Happy job hunting! 🚀
