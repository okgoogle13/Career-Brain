"""
Web Interface Module
Streamlit-based web interface for the Enhanced Resume Agent.
"""
