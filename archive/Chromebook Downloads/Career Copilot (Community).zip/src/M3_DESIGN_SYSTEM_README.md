# Material 3 Expressive Design System

## 🎨 **Updated Design Language**

The FML Career Copilot design has been updated to follow **Material 3 Expressive** principles with a **muted, botanical-inspired aesthetic** based on style source imagery.

---

## 🌿 **Design Philosophy**

### **Inspiration**
The design draws inspiration from botanical plant-care applications, featuring:
- **Muted purple and pink tones** for a calm, professional feel
- **Soft botanical illustrations** (leaf shapes) as decorative elements
- **Solid, opaque cards** with NO glass morphism or heavy shadows
- **Clean typography** with expressive headings (Roboto Flex) and readable body text (Inter)

### **Key Principles**
1. ✅ **Simplicity** - Clean, uncluttered layouts
2. ✅ **Professionalism** - Muted colors, no flashy effects
3. ✅ **Accessibility** - High contrast text, clear hierarchy
4. ✅ **Material 3** - Following Google's M3 Expressive guidelines

---

## 🎨 **Design Tokens**

### **Color Palette**

```typescript
// Dark Mode Theme
mode: "dark"

// PRIMARY - Muted Purple (Accents, Active Tabs)
primary.main: "#BDB0D6"
primary.light: "#D4CBEA"
primary.dark: "#9A8BC4"
primary.contrastText: "#1E1E23"

// TERTIARY - Muted Pink (Filled Card Background)
tertiary.main: "#D8BFD0"
tertiary.light: "#E8D4E1"
tertiary.dark: "#C0A4B8"
tertiary.contrastText: "#F8FAFC" // ⚠️ Important: Text on filled cards

// BACKGROUND
background.default: "#131318" // Deep dark
background.paper: "#1E1E23"   // Surface

// SURFACE HIERARCHY
surface.container: "#1E1E23"        // Outlined card background
surface.containerHigh: "#262629"
surface.containerHighest: "#2E2E32"

// OUTLINE
outline.main: "#928F99"
outline.variant: "#48464F"  // Border color for cards

// TEXT
text.primary: "#F8FAFC"     // High contrast white
text.secondary: "#E2E8F0"   // Muted white
text.disabled: "#94A3B8"

// ACCENT COLORS (for status indicators)
success.main: "#86EFAC"  // Green (high scores)
warning.main: "#FDE047"  // Yellow (medium scores)
error.main: "#FFB4AB"    // Red (low scores, delete actions)
```

### **Typography**

```typescript
// HEADINGS - Roboto Flex (Expressive serif font)
h1, h2, h3, h4, h5, h6 {
  fontFamily: '"Roboto Flex", "Roboto", serif'
  fontWeight: 600-700
}

// BODY TEXT - Inter (Clean sans-serif)
body1, body2, caption {
  fontFamily: '"Inter", "Roboto", sans-serif'
  fontWeight: 400-500
}
```

### **Shape**
```typescript
borderRadius: 16px  // All cards use 16px radius
spacing: 8          // Base spacing unit (8px grid)
```

---

## 📦 **Card Components**

### **1. M3 Outlined Card** (Default)

**Usage**: Recent Activity, Quick Actions, general content cards

```typescript
<Card variant="outlined">
  {/* Content */}
</Card>
```

**Styling**:
```typescript
{
  backgroundColor: 'surface.container',  // #1E1E23
  borderRadius: 16,                      // 16px
  border: '1px solid',
  borderColor: 'outline.variant',        // #48464F
  boxShadow: 'none',                     // ⚠️ NO shadow
}
```

**Example**:
```tsx
<Card
  variant="outlined"
  sx={{
    backgroundColor: 'surface.container',
    borderRadius: 4, // 16px
    border: 1,
    borderColor: 'outline.variant',
    boxShadow: 'none',
  }}
>
  <CardContent sx={{ p: 3 }}>
    <Typography variant="h6">Recent Activity</Typography>
    <Typography variant="body2" color="text.secondary">
      Your resume was updated 2 hours ago.
    </Typography>
  </CardContent>
</Card>
```

---

### **2. M3 Filled Card**

**Usage**: Profile cards, featured content, highlighted sections

```typescript
<Card variant="filled">
  {/* Content */}
</Card>
```

**Styling**:
```typescript
{
  backgroundColor: 'tertiary.main',      // #D8BFD0 (muted pink)
  borderRadius: 16,
  border: 'none',                        // NO border
  boxShadow: 'none',                     // ⚠️ NO shadow
  color: 'tertiary.contrastText',        // #F8FAFC (important!)
}
```

**⚠️ Important**: All text inside filled cards **must** use `tertiary.contrastText` for proper contrast.

**Example**:
```tsx
<Card
  variant="filled"
  sx={{
    backgroundColor: 'tertiary.main',
    borderRadius: 4,
    border: 'none',
    boxShadow: 'none',
    color: 'tertiary.contrastText',
  }}
>
  <CardContent sx={{ p: 3 }}>
    <Typography 
      variant="h6"
      sx={{ color: 'tertiary.contrastText' }}
    >
      Featured Tip
    </Typography>
    <Typography 
      variant="body2"
      sx={{ color: alpha('#F8FAFC', 0.9) }}
    >
      Tailor your resume for each application.
    </Typography>
  </CardContent>
</Card>
```

---

### **3. M3 Profile Card** (Special Component)

**Usage**: User profile cards with botanical illustration

**Anatomy** (3 Layers):
1. **Base Container** (z-index: 0) - M3 Filled Card variant
2. **Media Layer** (z-index: 1) - Botanical leaf illustration
3. **Content Layer** (z-index: 2) - Profile information

```tsx
import { M3ProfileCard } from './mui-components';

<M3ProfileCard
  name="Nishant Dougall"
  role="Community Support Worker"
  activeApplications={8}
  atsScore={87}
  lastUpdated="2 days ago"
  avatarColor="#BDB0D6"
  onEdit={() => console.log('Edit')}
  onDelete={() => console.log('Delete')}
/>
```

**Features**:
- ✅ Filled card background (`tertiary.main`)
- ✅ Botanical leaf SVG illustration (muted green, 70% opacity, bottom-right)
- ✅ Avatar with initials
- ✅ Name (Roboto Flex), Role (Inter)
- ✅ ATS Score progress bar with color coding
- ✅ Stat boxes with semi-transparent backgrounds
- ✅ Edit/Delete action buttons

**Color-Coded ATS Scores**:
- **85%+**: Green (#86EFAC)
- **70-84%**: Yellow (#FDE047)
- **Below 70%**: Red (#FFB4AB)

---

## 🎯 **Component Patterns**

### **Icon Container**
```tsx
<Box
  sx={{
    p: 1.5,
    bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
    borderRadius: 2,
  }}
>
  <Icon size={20} color="#BDB0D6" />
</Box>
```

### **Stat Box (Inside Filled Cards)**
```tsx
<Box
  sx={{
    bgcolor: alpha('#131318', 0.3),  // Semi-transparent dark
    borderRadius: 2,
    p: 1.5,
    textAlign: 'center',
  }}
>
  <Typography variant="caption" color={alpha('#F8FAFC', 0.7)}>
    Label
  </Typography>
  <Typography 
    variant="h6"
    sx={{ color: 'tertiary.contrastText' }}
  >
    Value
  </Typography>
</Box>
```

### **Progress Bar**
```tsx
<LinearProgress
  variant="determinate"
  value={75}
  sx={{
    height: 8,
    borderRadius: 4,
    bgcolor: alpha('#BDB0D6', 0.2),
    '& .MuiLinearProgress-bar': {
      bgcolor: '#86EFAC', // Or color based on score
      borderRadius: 4,
    },
  }}
/>
```

---

## 🚫 **What NOT to Use**

### **Deprecated Styles**
```typescript
// ❌ NO Glass Morphism
backdropFilter: 'blur(24px)'
background: 'rgba(30, 30, 35, 0.7)'

// ❌ NO Heavy Shadows
boxShadow: '0 0 64px rgba(167, 139, 250, 0.2)'

// ❌ NO Bright Gradients
background: 'linear-gradient(135deg, #A78BFA, #F472B6)'

// ❌ NO Glowing Effects (except for hover states)
boxShadow: '0 0 16px rgba(244, 114, 182, 0.4)'

// ❌ OLD Color Values
primary.main: '#A78BFA'   // Use #BDB0D6 instead
tertiary.main: '#F472B6'  // Use #D8BFD0 instead
```

### **Always Use**
```typescript
// ✅ Solid backgrounds
backgroundColor: 'surface.container'
backgroundColor: 'tertiary.main'

// ✅ Subtle borders
border: '1px solid'
borderColor: 'outline.variant'

// ✅ No shadows (M3 spec)
boxShadow: 'none'

// ✅ 16px border radius
borderRadius: 4  // MUI units (4 * 4 = 16px)

// ✅ Muted color accents
color: 'primary.main'  // #BDB0D6
color: 'tertiary.main' // #D8BFD0
```

---

## 📐 **Layout Guidelines**

### **Page Structure**
```tsx
<Box sx={{ minHeight: '100vh', bgcolor: 'background.default', py: 6 }}>
  <Container maxWidth="xl">
    {/* Page Title */}
    <Typography 
      variant="h3"
      sx={{
        fontFamily: '"Roboto Flex", "Roboto", serif',
        fontWeight: 700,
        mb: 2,
      }}
    >
      Page Title
    </Typography>

    {/* Content Grid */}
    <Grid container spacing={3}>
      <Grid item xs={12} md={6} lg={4}>
        <Card variant="outlined">
          {/* Card content */}
        </Card>
      </Grid>
    </Grid>
  </Container>
</Box>
```

### **Spacing System**
```typescript
// MUI uses 8px base unit
sx={{ p: 1 }}    // 8px
sx={{ p: 2 }}    // 16px
sx={{ p: 3 }}    // 24px
sx={{ p: 4 }}    // 32px
sx={{ p: 6 }}    // 48px

// Common patterns
sx={{ mb: 2 }}   // Margin bottom 16px
sx={{ gap: 3 }}  // Gap 24px (Grid/Flex)
sx={{ py: 6 }}   // Vertical padding 48px
```

---

## 🎨 **Botanical Illustrations**

### **Media Layer (Profile Cards)**
Simple SVG leaf shapes in **muted soft green** tones:
- Color: `#A8C9A0`, `#B5D4AD` (soft greens)
- Opacity: `0.6` to `0.7`
- Position: Bottom-right corner, bleeding off edges
- Style: Organic, monstera-style leaf shapes
- Z-index: 1 (behind content, above background)

**Example SVG**:
```tsx
<svg width="180" height="180" viewBox="0 0 180 180">
  <path
    d="M90 20C110 20 130 35..."
    fill="#A8C9A0"
    opacity="0.6"
  />
  <path
    d="M95 45C105 50..."
    fill="#B5D4AD"
    opacity="0.5"
  />
</svg>
```

---

## 📚 **Component Examples**

### **Example 1: Recent Activity Card**
```tsx
<Card
  variant="outlined"
  sx={{
    backgroundColor: 'surface.container',
    borderRadius: 4,
    border: 1,
    borderColor: 'outline.variant',
    boxShadow: 'none',
  }}
>
  <CardContent sx={{ p: 3 }}>
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
      <Box
        sx={{
          p: 1.5,
          bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
          borderRadius: 2,
        }}
      >
        <FileText size={20} color="#BDB0D6" />
      </Box>
      <Box>
        <Typography
          variant="h6"
          sx={{
            fontFamily: '"Roboto Flex", "Roboto", serif',
            fontWeight: 600,
          }}
        >
          Resume Updated
        </Typography>
        <Typography variant="caption" color="text.secondary">
          2 hours ago
        </Typography>
      </Box>
    </Box>
    <Typography variant="body2" color="text.secondary">
      Your Community Support Worker resume has been optimized.
    </Typography>
  </CardContent>
</Card>
```

### **Example 2: Profile Card**
```tsx
import { M3ProfileCard } from './mui-components';

<M3ProfileCard
  name="Nishant Dougall"
  role="Community Support Worker"
  activeApplications={8}
  atsScore={87}
  lastUpdated="2 days ago"
  avatarColor="#BDB0D6"
  onEdit={() => handleEdit()}
  onDelete={() => handleDelete()}
/>
```

---

## ✅ **Migration Checklist**

When updating existing components:

- [ ] Change primary color from `#A78BFA` to `#BDB0D6`
- [ ] Change tertiary color from `#F472B6` to `#D8BFD0`
- [ ] Update all headings to use `fontFamily: '"Roboto Flex", "Roboto", serif'`
- [ ] Update body text to use `fontFamily: '"Inter", "Roboto", sans-serif'`
- [ ] Remove glass morphism effects (`backdropFilter`, transparent backgrounds)
- [ ] Remove box shadows (set to `'none'`)
- [ ] Use `Card variant="outlined"` for content cards
- [ ] Use `Card variant="filled"` for profile/featured cards
- [ ] Ensure filled card text uses `tertiary.contrastText`
- [ ] Set all card border radius to 16px (`borderRadius: 4`)
- [ ] Remove heavy gradient backgrounds
- [ ] Use color accents sparingly (icons, borders, small highlights)

---

## 🚀 **Quick Start**

### **1. Import Theme**
```tsx
import { ThemeProvider } from '@mui/material/styles';
import theme from './theme';

function App() {
  return (
    <ThemeProvider theme={theme}>
      {/* Your app */}
    </ThemeProvider>
  );
}
```

### **2. Use M3 Cards**
```tsx
import { Card, CardContent, Typography } from '@mui/material';

// Outlined card
<Card variant="outlined">
  <CardContent>
    <Typography variant="h6">Title</Typography>
  </CardContent>
</Card>

// Filled card
<Card variant="filled">
  <CardContent>
    <Typography variant="h6" sx={{ color: 'tertiary.contrastText' }}>
      Title
    </Typography>
  </CardContent>
</Card>
```

### **3. Use Profile Cards**
```tsx
import { M3ProfileCard } from './mui-components';

<M3ProfileCard
  name="Your Name"
  role="Your Role"
  activeApplications={5}
  atsScore={85}
  lastUpdated="1 day ago"
  onEdit={() => {}}
  onDelete={() => {}}
/>
```

---

## 📖 **Additional Resources**

- **Theme Configuration**: `/theme.ts`
- **Design Guidelines**: `/guidelines/Guidelines.md`
- **Component Examples**: `/mui-components/M3CardExamples.tsx`
- **Profile Card Component**: `/mui-components/M3ProfileCard.tsx`

---

## 🎉 **Summary**

The Material 3 Expressive design system provides a **muted, professional, botanical-inspired** aesthetic with:

✅ **Muted purple (#BDB0D6) and pink (#D8BFD0)** accent colors
✅ **Roboto Flex** for expressive headings
✅ **Inter** for clean body text
✅ **Solid cards** with NO glass morphism or shadows
✅ **Botanical illustrations** as subtle decorative elements
✅ **16px border radius** for all cards
✅ **Clear hierarchy** with M3 Outlined and Filled card variants
✅ **Accessibility-first** with high contrast text

**The design is calm, professional, and user-friendly!** 🌿✨
