import React from 'react';
import { Target, Plus } from 'lucide-react';
import { Button } from './ui/button';

interface ApplicationsViewProps {
  onAddApplication?: () => void;
}

export function ApplicationsView({ onAddApplication }: ApplicationsViewProps) {
  return (
    <div 
      className="flex-1 overflow-auto"
      style={{ background: 'var(--color-background)' }}
    >
      <div className="max-w-7xl mx-auto p-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-semibold mb-2" style={{ color: 'var(--on-surface)', fontSize: '2rem' }}>
              Applications
            </h1>
            <p style={{ color: 'var(--on-surface-variant)' }}>
              Track and manage your job applications
            </p>
          </div>
          <Button
            onClick={onAddApplication}
            className="transition-all duration-300"
            style={{
              background: 'var(--primary)',
              color: 'var(--on-primary)',
            }}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Application
          </Button>
        </div>

        {/* Placeholder content */}
        <div 
          className="flex flex-col items-center justify-center py-20 rounded-2xl border-2 border-dashed"
          style={{
            borderColor: 'rgba(167, 139, 250, 0.3)',
            background: 'rgba(30, 30, 35, 0.4)'
          }}
        >
          <div 
            className="p-6 rounded-full mb-4"
            style={{
              background: 'rgba(167, 139, 250, 0.1)',
            }}
          >
            <Target className="w-12 h-12" style={{ color: 'var(--primary)' }} />
          </div>
          <h3 className="font-semibold mb-2" style={{ color: 'var(--on-surface)' }}>
            Applications View
          </h3>
          <p style={{ color: 'var(--on-surface-variant)' }}>
            Application tracker will be housed here
          </p>
        </div>
      </div>
    </div>
  );
}
