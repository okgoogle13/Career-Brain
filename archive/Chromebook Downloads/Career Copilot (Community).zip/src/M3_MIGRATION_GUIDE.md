# Material 3 Expressive - Migration Guide

## 🔄 **Updating Existing Components to M3**

This guide helps you migrate existing components from the old Aurora theme to the new **Material 3 Expressive** design system.

---

## 🎨 **Color Palette Changes**

### **Before (Aurora Theme)**
```typescript
primary.main: '#A78BFA'     // Vibrant Purple
tertiary.main: '#F472B6'    // Bright Pink
```

### **After (M3 Expressive)**
```typescript
primary.main: '#BDB0D6'     // Muted Purple
tertiary.main: '#D8BFD0'    // Muted Pink
tertiary.contrastText: '#F8FAFC'  // ⚠️ Important for filled cards
```

### **Find and Replace**
1. Replace all instances of `#A78BFA` with `#BDB0D6`
2. Replace all instances of `#F472B6` with `#D8BFD0`
3. Search for `primary.main` and verify color is correct
4. Search for `tertiary.main` and add `contrastText` where needed

---

## 📝 **Typography Updates**

### **Before**
```tsx
<Typography variant="h4">
  Heading Text
</Typography>
```

### **After**
```tsx
<Typography 
  variant="h4"
  sx={{
    fontFamily: '"Roboto Flex", "Roboto", serif',
    fontWeight: 700,
  }}
>
  Heading Text
</Typography>
```

### **Migration Steps**
1. **All headings (h1-h6)** must specify `fontFamily: '"Roboto Flex", "Roboto", serif'`
2. **Body text** uses default Inter (already in theme)
3. Update `fontWeight` to 600-700 for headings

**Note**: Since theme.ts has been updated with Roboto Flex for headings, you may not need to specify it explicitly. However, for clarity, it's recommended to add it to important headings.

---

## 🃏 **Card Component Updates**

### **Old Card (Glass Morphism)**
```tsx
<Card
  sx={{
    background: 'rgba(30, 30, 35, 0.7)',
    backdropFilter: 'blur(24px)',
    border: '1px solid rgba(167, 139, 250, 0.2)',
    boxShadow: '0 4px 30px rgba(0, 0, 0, 0.1)',
  }}
>
  {/* Content */}
</Card>
```

### **New Card (M3 Outlined)**
```tsx
<Card
  variant="outlined"
  sx={{
    backgroundColor: 'surface.container',
    borderRadius: 4,  // 16px
    border: 1,
    borderColor: 'outline.variant',
    boxShadow: 'none',
  }}
>
  {/* Content */}
</Card>
```

### **New Card (M3 Filled)**
```tsx
<Card
  variant="filled"
  sx={{
    backgroundColor: 'tertiary.main',
    borderRadius: 4,
    border: 'none',
    boxShadow: 'none',
    color: 'tertiary.contrastText',
  }}
>
  <CardContent>
    <Typography 
      variant="h6"
      sx={{ color: 'tertiary.contrastText' }}
    >
      Title
    </Typography>
  </CardContent>
</Card>
```

### **Migration Checklist for Cards**
- [ ] Remove `backdropFilter` and `WebkitBackdropFilter`
- [ ] Remove transparent backgrounds (`rgba(...)`)
- [ ] Change to solid `backgroundColor: 'surface.container'`
- [ ] Remove or set `boxShadow: 'none'`
- [ ] Update `borderRadius` to 4 (16px)
- [ ] Update `borderColor` to `'outline.variant'`
- [ ] For filled cards, ensure text uses `tertiary.contrastText`

---

## 🎭 **Removing Glass Effects**

### **Before**
```tsx
sx={{
  background: 'rgba(30, 30, 35, 0.7)',
  backdropFilter: 'blur(24px)',
  WebkitBackdropFilter: 'blur(24px)',
  border: '1px solid rgba(167, 139, 250, 0.2)',
}}
```

### **After**
```tsx
sx={{
  backgroundColor: 'surface.container',  // Solid color
  border: 1,
  borderColor: 'outline.variant',
  // NO backdropFilter
  // NO transparency
}}
```

### **Search and Remove**
- Search for: `backdropFilter`
- Search for: `WebkitBackdropFilter`
- Search for: `rgba(30, 30, 35,`
- Search for: `rgba(167, 139, 250,`
- Replace all with solid colors from theme

---

## 🌈 **Gradient Updates**

### **Before (Heavy Gradients)**
```tsx
sx={{
  background: 'linear-gradient(135deg, #A78BFA, #F472B6)',
  backgroundSize: '200% 200%',
  animation: 'aurora-shimmer 3s ease infinite',
}}
```

### **After (Subtle Accents)**
```tsx
// Only use gradients for:
// 1. Progress bars
// 2. Small accent elements
// 3. Tab indicators

// Progress bar example
sx={{
  '& .MuiLinearProgress-bar': {
    background: 'linear-gradient(90deg, #BDB0D6, #D8BFD0)',
  },
}}
```

### **Migration Steps**
1. **Remove large background gradients**
2. **Keep gradients only for**:
   - Progress bars
   - Tab indicators
   - Small decorative elements
3. **Update gradient colors** to use new muted palette

---

## 🎨 **Icon Container Pattern**

### **Before**
```tsx
<Box
  sx={{
    p: 2,
    bgcolor: alpha('#A78BFA', 0.15),
    borderRadius: 2,
  }}
>
  <Icon size={24} color="#A78BFA" />
</Box>
```

### **After**
```tsx
<Box
  sx={{
    p: 1.5,
    bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
    borderRadius: 2,
  }}
>
  <Icon size={20} color="#BDB0D6" />
</Box>
```

### **Changes**
- Padding: `2` → `1.5`
- Icon size: `24` → `20`
- Alpha: `0.15` → `0.12`
- Color: `#A78BFA` → `#BDB0D6`

---

## 🔳 **Button Updates**

### **Before (Aurora Gradient Button)**
```tsx
<Button
  variant="contained"
  sx={{
    background: 'linear-gradient(135deg, #A78BFA, #F472B6)',
    boxShadow: '0 0 16px rgba(167, 139, 250, 0.4)',
  }}
>
  Action
</Button>
```

### **After (M3 Primary Button)**
```tsx
<Button
  variant="contained"
  sx={{
    bgcolor: 'primary.main',
    color: 'primary.contrastText',
    fontWeight: 600,
    boxShadow: 'none',
    '&:hover': {
      bgcolor: 'primary.dark',
    },
  }}
>
  Action
</Button>
```

### **Migration Steps**
- [ ] Remove gradient backgrounds
- [ ] Use solid `bgcolor: 'primary.main'`
- [ ] Set `boxShadow: 'none'`
- [ ] Ensure `color: 'primary.contrastText'`
- [ ] Add simple hover state

---

## 📊 **Progress Bar Updates**

### **Before**
```tsx
<LinearProgress
  variant="determinate"
  value={75}
  sx={{
    height: 8,
    borderRadius: 8,
    bgcolor: alpha('#A78BFA', 0.2),
    '& .MuiLinearProgress-bar': {
      background: 'linear-gradient(90deg, #A78BFA, #F472B6)',
    },
  }}
/>
```

### **After**
```tsx
<LinearProgress
  variant="determinate"
  value={75}
  sx={{
    height: 8,
    borderRadius: 4,
    bgcolor: alpha('#BDB0D6', 0.2),
    '& .MuiLinearProgress-bar': {
      bgcolor: scoreColor,  // Color-coded based on value
      borderRadius: 4,
    },
  }}
/>
```

### **Color Coding for Scores**
```typescript
const getScoreColor = (score: number) => {
  if (score >= 85) return '#86EFAC';  // Green
  if (score >= 70) return '#FDE047';  // Yellow
  return '#FFB4AB';                   // Red
};
```

---

## 🗂️ **Profile Card Migration**

### **Before (Custom Card)**
```tsx
<Card sx={{ bgcolor: 'surface.container', ... }}>
  <CardContent>
    <Avatar />
    <Typography variant="h6">{name}</Typography>
    <Typography variant="body2">{role}</Typography>
    <LinearProgress value={atsScore} />
    <Button>Edit</Button>
    <Button>Delete</Button>
  </CardContent>
</Card>
```

### **After (M3 Profile Card)**
```tsx
import { M3ProfileCard } from './mui-components';

<M3ProfileCard
  name="Nishant Dougall"
  role="Community Support Worker"
  activeApplications={8}
  atsScore={87}
  lastUpdated="2 days ago"
  avatarColor="#BDB0D6"
  onEdit={handleEdit}
  onDelete={handleDelete}
/>
```

### **Features**
- ✅ Filled card background (tertiary.main)
- ✅ Botanical leaf illustration
- ✅ Three-layer design (Base + Media + Content)
- ✅ Color-coded ATS score
- ✅ Stat boxes with semi-transparent backgrounds
- ✅ Professional typography

---

## 🎯 **Step-by-Step Migration Process**

### **1. Update Theme Colors**
```typescript
// In your component file, update any hardcoded colors
// Before
color: '#A78BFA'
// After
color: 'primary.main'  // or '#BDB0D6'
```

### **2. Update Card Components**
```typescript
// Replace glass cards
<Card variant="glass">  ❌
// With
<Card variant="outlined">  ✅

// Or for profiles
<Card variant="filled">  ✅
```

### **3. Update Typography**
```tsx
// Add Roboto Flex to headings
<Typography 
  variant="h4"
  sx={{
    fontFamily: '"Roboto Flex", "Roboto", serif',
    fontWeight: 700,
  }}
>
```

### **4. Remove Effects**
```typescript
// Remove:
backdropFilter: 'blur(24px)'  ❌
boxShadow: '0 0 64px...'      ❌
background: 'rgba(...)'       ❌

// Add:
boxShadow: 'none'             ✅
backgroundColor: 'surface.container'  ✅
```

### **5. Update Spacing**
```typescript
// Ensure consistent 8px grid
sx={{ p: 3 }}   // 24px padding
sx={{ gap: 3 }} // 24px gap
sx={{ mb: 2 }}  // 16px margin bottom
```

---

## 🔍 **Search and Replace Guide**

### **Global Find/Replace**
```bash
# Colors
Find: #A78BFA
Replace: #BDB0D6

Find: #F472B6
Replace: #D8BFD0

# Glass Effects
Find: backdropFilter
Delete or comment out

Find: WebkitBackdropFilter
Delete or comment out

Find: rgba(30, 30, 35, 0.7)
Replace: theme.palette.surface.container

# Shadows
Find: boxShadow: '0 0
Replace: boxShadow: 'none'  (or remove entirely)
```

### **Component-Specific**
```typescript
// Cards
Find: <Card sx={{ background: 'rgba
Replace: <Card variant="outlined" sx={{ backgroundColor: 'surface.container'

// Buttons
Find: variant="aurora"
Replace: variant="contained"

Find: background: 'linear-gradient
Replace: bgcolor: 'primary.main'
```

---

## ✅ **Verification Checklist**

After migration, verify:

- [ ] **No glass morphism** - No `backdropFilter` in code
- [ ] **No heavy shadows** - `boxShadow: 'none'` on cards
- [ ] **Muted colors** - Using `#BDB0D6` and `#D8BFD0`
- [ ] **Roboto Flex** - All headings use Roboto Flex
- [ ] **Inter body text** - Body text uses Inter
- [ ] **Solid cards** - All cards use `surface.container` or `tertiary.main`
- [ ] **16px radius** - All cards use `borderRadius: 4`
- [ ] **Filled card text** - Uses `tertiary.contrastText`
- [ ] **No gradients** - Except progress bars and small accents
- [ ] **Consistent spacing** - 8px grid system

---

## 🐛 **Common Issues**

### **Issue 1: Text Not Visible on Filled Cards**
**Problem**: Text appears dark on pink background
**Solution**: Use `tertiary.contrastText` for all text in filled cards
```tsx
<Typography sx={{ color: 'tertiary.contrastText' }}>
  Text
</Typography>
```

### **Issue 2: Cards Still Look Transparent**
**Problem**: Background still uses `rgba`
**Solution**: Replace with solid color
```tsx
// Before
bgcolor: 'rgba(30, 30, 35, 0.7)'
// After
bgcolor: 'surface.container'
```

### **Issue 3: Headings Not Using Roboto Flex**
**Problem**: Headings use default Inter font
**Solution**: Explicitly set font family (if theme doesn't apply)
```tsx
<Typography 
  variant="h4"
  sx={{ fontFamily: '"Roboto Flex", "Roboto", serif' }}
>
```

### **Issue 4: Colors Too Bright**
**Problem**: Still using old vibrant purple/pink
**Solution**: Update to muted palette
```tsx
// Before
color: '#A78BFA'
// After
color: '#BDB0D6'
```

---

## 📖 **Additional Resources**

- **Design System README**: `/M3_DESIGN_SYSTEM_README.md`
- **Theme Configuration**: `/theme.ts`
- **Design Guidelines**: `/guidelines/Guidelines.md`
- **Component Examples**: `/mui-components/M3CardExamples.tsx`

---

## 🎉 **Migration Complete!**

Once all components are updated:

1. ✅ Test all pages for visual consistency
2. ✅ Verify text contrast on filled cards
3. ✅ Check responsive layouts
4. ✅ Ensure accessibility (color contrast, focus states)
5. ✅ Remove old Aurora components
6. ✅ Update documentation

**Your app now follows Material 3 Expressive principles!** 🌿✨
