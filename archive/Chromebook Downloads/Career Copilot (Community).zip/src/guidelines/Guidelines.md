# FML Career Copilot Design System Guidelines

## Material 3 Expressive Design System

### Overview
Our design system follows **Material 3 Expressive** principles with a muted, professional aesthetic. The design uses solid cards, subtle color accents, and a clear typographic hierarchy inspired by botanical plant-care applications.

**Style Source**: Reference design from style guide images showing muted purple/pink palette with soft botanical illustrations.

### Design Tokens (Material 3 Expressive)

#### Color Palette
```typescript
mode: "dark"

// Primary - Muted Purple (Accents, Active Tabs)
primary.main: "#BDB0D6"
primary.light: "#D4CBEA"
primary.dark: "#9A8BC4"
primary.contrastText: "#1E1E23"

// Tertiary - Muted Pink (Filled Card Background)
tertiary.main: "#D8BFD0"
tertiary.light: "#E8D4E1"
tertiary.dark: "#C0A4B8"
tertiary.contrastText: "#F8FAFC" // Text on filled cards

// Background
background.default: "#131318" // Deep dark background
background.paper: "#1E1E23"   // Surface container

// Surface Hierarchy
surface.container: "#1E1E23"         // Outlined card background
surface.containerHigh: "#262629"
surface.containerHighest: "#2E2E32"

// Outline
outline.main: "#928F99"
outline.variant: "#48464F"  // Border color

// Text
text.primary: "#F8FAFC"     // High contrast white
text.secondary: "#E2E8F0"   // Muted white
text.disabled: "#94A3B8"
```

#### Typography System
**Heading Font**: Roboto Flex (Expressive serif)
**Body Font**: Inter (Clean sans-serif)

```typescript
// All headings use Roboto Flex
h1-h6: {
  fontFamily: '"Roboto Flex", "Roboto", serif'
  fontWeight: 600-700
}

// Body text uses Inter
body1, body2: {
  fontFamily: '"Inter", "Roboto", sans-serif'
}
```

#### Spacing Tokens
- **Spacing Scale**: `--spacing-xs` through `--spacing-3xl` (8px to 96px)

#### Enhanced Token Categories
- **Border Radius**: `--radius-sm` through `--radius-xl`
- **Shadows**: `--shadow-sm`, `--shadow-md`, `--shadow-lg`, `--shadow-glow-primary`, `--shadow-glow-purple`, `--shadow-glass`, `--shadow-glass-hover`
- **Animations**: `--animation-duration-fast` (150ms), `--animation-duration-normal` (300ms), `--animation-duration-slow` (500ms), `--animation-ease`
- **Glass Effects**: `--glass-bg`, `--glass-blur` (15px), `--glass-border`
- **Breakpoints**: `--breakpoint-mobile` (768px), `--breakpoint-tablet` (1024px), `--breakpoint-desktop` (1440px)

### Usage Guidelines

#### In CSS
```css
/* Use CSS custom properties */
.my-component {
  background-color: var(--color-background-card);
  padding: var(--spacing-lg);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-sm);
}
```

#### In React Components
```tsx
// Import the hook
import { useDesignTokens } from '../hooks/useDesignTokens';

function MyComponent() {
  const { tokens, styles } = useDesignTokens();
  
  return (
    <div style={styles.card}>
      {/* Content */}
    </div>
  );
}
```

#### With Token Mapper
```tsx
import { careerCopilotTokenMapper } from '../mappings/design-tokens.mapper';

// Maps Figma tokens to CSS variables
const bgColor = careerCopilotTokenMapper('background-card');
```

### Rules

1. **Always use design tokens** instead of hardcoded values
2. **Prefer utility classes** that use tokens (`.text-lg`, `.space-md`)
3. **Use the token mapper** when implementing designs from Figma
4. **Leverage pre-built styles** from `useDesignTokens` for common patterns
5. **Maintain token consistency** across all components

## Component Guidelines

### General Rules
- Only use absolute positioning when necessary. Opt for responsive layouts using flexbox and grid
- Refactor code to keep components clean and focused
- Keep file sizes small, extract helper functions and reusable components
- Use TypeScript for all new components with proper type definitions

### Enhanced Brand Guidelines
- **Primary Color**: Enhanced Blue (#60a5fa) for primary actions and brand elements
- **Secondary Color**: Accent Purple (#a78bfa) for secondary actions and highlights
- **Accent Colors**: Use enhanced brand colors (green, yellow, red) for status and feedback
- **Background**: Gradient background with glass morphism overlays
- **Typography**: Google Sans for headings, system fonts for body text
- **Glass Morphism**: 15px blur effects with semi-transparent overlays
- **Animations**: 300ms smooth transitions with cubic-bezier easing
- **Accessibility**: High contrast ratios, focus indicators, reduced motion support
- **Branding**: "FML Career Copilot" with skull logo, edgy professional aesthetic

### Button Component

#### Usage
Buttons trigger actions and provide clear user affordances. They should have action-oriented labels and appropriate visual hierarchy.

#### Variants
- **Primary Button**: Main actions, uses `btn-gradient` class or primary color tokens
- **Secondary Button**: Alternative actions, outlined style with `border-brand-blue`
- **Ghost Button**: Subtle actions, minimal styling
- **Destructive Button**: Dangerous actions, uses `--color-accent-red`

#### Design Token Usage
```tsx
// Use pre-built button styles
const { styles } = useDesignTokens();
<button style={styles.buttonPrimary}>Action</button>

// Or use CSS classes with tokens
<Button className="bg-brand-blue text-foreground">Action</Button>
```

### Card Components (Material 3)

#### **Card - M3 Outlined**
**Use**: Recent Activity, Quick Actions, general content cards
```typescript
{
  backgroundColor: 'surface.container',  // #1E1E23
  borderRadius: 16,
  border: '1px solid',
  borderColor: 'outline.variant',        // #48464F
  boxShadow: 'none',                     // NO shadow
}
```

#### **Card - M3 Filled**
**Use**: Profile cards, featured content
```typescript
{
  backgroundColor: 'tertiary.main',      // #D8BFD0
  borderRadius: 16,
  border: 'none',
  boxShadow: 'none',                     // NO shadow
  color: 'tertiary.contrastText',        // #F8FAFC
}
```

#### **Profile Card Anatomy** (Special M3 Component)
1. **Base Container** (z-index: 0)
   - Uses M3 Filled Card variant
   - `position: relative`, `overflow: hidden`

2. **Media Layer** (z-index: 1)
   - Decorative botanical illustration (soft green leaf shapes)
   - Positioned bottom-right, bleeding off edges
   - `opacity: 0.7`
   - Color: Muted soft green from style source

3. **Content Layer** (z-index: 2)
   - All text uses `tertiary.contrastText` (#F8FAFC)
   - Avatar, name (Roboto Flex), role (Inter)
   - LinearProgress bar with ATS score
   - Stat boxes with `alpha(background.default, 0.3)` background
   - Edit/Delete text buttons

### Typography

#### Hierarchy
- **H1**: `var(--font-size-2xl)`, `var(--font-weight-semibold)`
- **H2**: `var(--font-size-xl)`, `var(--font-weight-semibold)`
- **Body**: `var(--font-size-base)`, `var(--font-weight-regular)`
- **Caption**: `var(--font-size-sm)`, `var(--font-weight-regular)`

#### Color Usage
- Primary text: `var(--color-foreground)`
- Secondary text: `var(--color-foreground-secondary)`
- Muted text: `var(--color-foreground-muted)`

### Spacing System

#### Consistent Spacing
- **Small gaps**: `var(--spacing-xs)` to `var(--spacing-sm)`
- **Component padding**: `var(--spacing-md)` to `var(--spacing-lg)`
- **Section spacing**: `var(--spacing-xl)` to `var(--spacing-2xl)`
- **Page margins**: `var(--spacing-2xl)` to `var(--spacing-3xl)`

### Enhanced Animation Guidelines

#### Micro-interactions
- Use `transition-normal` (300ms) for smooth state changes
- Hover transforms: `translateY(-2px)` to `translateY(-4px)` with glass effects
- Button press: `scale(0.95)` with gradient shadows
- Glass morphism hover: Enhanced blur and border glow

#### Advanced Effects
- **Shimmer Effects**: Use `.shimmer` class for loading states and progress bars
- **Pulse Badges**: `.pulse-ai` and `.pulse-new` for dynamic notifications
- **Glow Hover**: `.glow-hover` for interactive elements
- **Glass Transitions**: Smooth backdrop-filter and opacity changes

#### Accessibility Support
- **Reduced Motion**: Automatic animation disable for `prefers-reduced-motion`
- **Focus States**: Enhanced focus indicators with glow effects
- **High Contrast**: Optional high contrast mode support

## Implementation Standards

### File Organization
- Components in `/components` directory
- UI primitives in `/components/ui`
- Design tokens in `/mappings`
- Hooks in `/hooks`
- Examples in `/components/examples`

### Code Quality
- Use React.forwardRef for components that need ref forwarding
- Implement proper TypeScript types
- Follow consistent naming conventions
- Add displayName to all components for debugging

### Accessibility
- Ensure proper focus management
- Use semantic HTML elements
- Provide appropriate ARIA labels
- Maintain sufficient color contrast

**Important**: Some of the base components may have styling (gap/typography) baked in as defaults. Make sure you explicitly set any styling information from these guidelines in the generated React to override the defaults.