# Material 3 Expressive - Quick Reference Card

## 🎨 **Color Palette**

```typescript
// PRIMARY - Muted Purple (Accents, Active States)
primary.main: '#BDB0D6'

// TERTIARY - Muted Pink (Filled Cards)
tertiary.main: '#D8BFD0'
tertiary.contrastText: '#F8FAFC'  // ⚠️ Important!

// SURFACE
surface.container: '#1E1E23'  // Card backgrounds
outline.variant: '#48464F'    // Borders

// BACKGROUND
background.default: '#131318'
```

---

## 📝 **Typography**

```typescript
// Headings - Roboto Flex (serif/expressive)
fontFamily: '"Roboto Flex", "Roboto", serif'
fontWeight: 600-700

// Body - Inter (sans-serif)
fontFamily: '"Inter", "Roboto", sans-serif'
fontWeight: 400-500
```

---

## 🃏 **Card Variants**

### **Outlined Card**
```tsx
<Card
  variant="outlined"
  sx={{
    backgroundColor: 'surface.container',
    borderRadius: 4,
    border: 1,
    borderColor: 'outline.variant',
    boxShadow: 'none',
  }}
>
```

### **Filled Card**
```tsx
<Card
  variant="filled"
  sx={{
    backgroundColor: 'tertiary.main',
    borderRadius: 4,
    boxShadow: 'none',
    color: 'tertiary.contrastText',
  }}
>
```

---

## 🎯 **Common Patterns**

### **Icon Container**
```tsx
<Box
  sx={{
    p: 1.5,
    bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
    borderRadius: 2,
  }}
>
  <Icon size={20} color="#BDB0D6" />
</Box>
```

### **Stat Box (in Filled Cards)**
```tsx
<Box
  sx={{
    bgcolor: alpha('#131318', 0.3),
    borderRadius: 2,
    p: 1.5,
  }}
>
```

### **Progress Bar**
```tsx
<LinearProgress
  value={score}
  sx={{
    height: 8,
    borderRadius: 4,
    bgcolor: alpha('#BDB0D6', 0.2),
    '& .MuiLinearProgress-bar': {
      bgcolor: scoreColor,
      borderRadius: 4,
    },
  }}
/>
```

---

## ✅ **Do's**
- ✅ Solid card backgrounds
- ✅ Muted accent colors
- ✅ Roboto Flex for headings
- ✅ 16px border radius
- ✅ `boxShadow: 'none'`
- ✅ `tertiary.contrastText` on filled cards

## ❌ **Don'ts**
- ❌ No glass morphism
- ❌ No `backdropFilter`
- ❌ No heavy shadows
- ❌ No bright gradients
- ❌ No `#A78BFA` or `#F472B6`

---

## 🔢 **Spacing (8px grid)**
```typescript
sx={{ p: 1 }}    // 8px
sx={{ p: 2 }}    // 16px
sx={{ p: 3 }}    // 24px
sx={{ p: 4 }}    // 32px
sx={{ gap: 3 }}  // 24px
```

---

## 📱 **Component Usage**

### **Profile Card**
```tsx
import { M3ProfileCard } from './mui-components';

<M3ProfileCard
  name="Name"
  role="Role"
  activeApplications={5}
  atsScore={85}
  lastUpdated="1 day ago"
  onEdit={() => {}}
  onDelete={() => {}}
/>
```

---

**Save this for quick reference!** 🌿✨
