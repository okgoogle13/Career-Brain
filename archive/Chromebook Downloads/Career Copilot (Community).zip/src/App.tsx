import React, { useState } from 'react';
import { ThemeProvider, CssBaseline, Box, Tabs, Tab, AppBar, Toolbar, Typography, IconButton } from '@mui/material';
import { Settings } from 'lucide-react';
import theme from './theme';

// Import MUI components
import { DashboardView } from './mui-components/DashboardView';
import { ATSAnalysisDashboard } from './mui-components/ATSAnalysisDashboard';
import { KanbanBoard } from './mui-components/KanbanBoard';

function App() {
  const [currentView, setCurrentView] = useState<'dashboard' | 'documents' | 'opportunities' | 'applications' | 'analysis'>('dashboard');

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          minHeight: '100vh',
          bgcolor: 'background.default',
        }}
      >
        {/* Top Bar */}
        <AppBar
          position="sticky"
          elevation={0}
          sx={{
            bgcolor: 'transparent',
            backdropFilter: 'blur(24px)',
            borderBottom: 1,
            borderColor: 'outline.variant',
          }}
        >
          <Toolbar sx={{ justifyContent: 'space-between' }}>
            <Typography
              variant="h6"
              sx={{
                fontWeight: 700,
                background: (theme) =>
                  `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.tertiary.main})`,
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              FML Career Copilot
            </Typography>
            <IconButton sx={{ color: 'text.primary' }}>
              <Settings size={20} />
            </IconButton>
          </Toolbar>
        </AppBar>

        {/* Navigation Tabs */}
        <Box
          sx={{
            borderBottom: 1,
            borderColor: 'outline.variant',
            bgcolor: (theme) => theme.palette.surface.container,
            position: 'sticky',
            top: 64,
            zIndex: 10,
          }}
        >
          <Tabs
            value={currentView}
            onChange={(e, newValue) => setCurrentView(newValue)}
            sx={{
              px: { xs: 2, md: 6 },
              '& .MuiTabs-indicator': {
                height: 3,
                borderRadius: '3px 3px 0 0',
              },
            }}
          >
            <Tab label="Dashboard" value="dashboard" sx={{ textTransform: 'none', fontWeight: 600 }} />
            <Tab label="Documents" value="documents" sx={{ textTransform: 'none', fontWeight: 600 }} />
            <Tab label="Opportunities" value="opportunities" sx={{ textTransform: 'none', fontWeight: 600 }} />
            <Tab label="Applications" value="applications" sx={{ textTransform: 'none', fontWeight: 600 }} />
            <Tab label="Analysis" value="analysis" sx={{ textTransform: 'none', fontWeight: 600 }} />
          </Tabs>
        </Box>

        {/* Main Content */}
        <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
          {currentView === 'dashboard' && (
            <DashboardView
              onCreateDocument={() => console.log('Create document')}
              onViewAnalytics={() => setCurrentView('analysis')}
              onNavigateToOpportunities={() => setCurrentView('opportunities')}
              onNavigateToApplications={() => setCurrentView('applications')}
            />
          )}
          
          {currentView === 'documents' && (
            <Box sx={{ p: 6 }}>
              <Typography variant="h4" sx={{ fontWeight: 700, mb: 2 }}>
                Documents View
              </Typography>
              <Typography variant="body2" color="text.secondary">
                This view will show your document library with filters and grid layout.
              </Typography>
            </Box>
          )}
          
          {currentView === 'opportunities' && (
            <Box sx={{ p: 6 }}>
              <Typography variant="h4" sx={{ fontWeight: 700, mb: 2 }}>
                Job Opportunities
              </Typography>
              <Typography variant="body2" color="text.secondary">
                This view will show AI-matched job opportunities using the JobCard component.
              </Typography>
            </Box>
          )}
          
          {currentView === 'applications' && <KanbanBoard />}
          
          {currentView === 'analysis' && (
            <ATSAnalysisDashboard onBack={() => setCurrentView('dashboard')} />
          )}
        </Box>
      </Box>
    </ThemeProvider>
  );
}

export default App;
