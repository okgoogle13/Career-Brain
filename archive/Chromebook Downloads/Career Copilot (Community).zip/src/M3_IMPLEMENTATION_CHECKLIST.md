# Material 3 Expressive - Implementation Checklist

## ✅ **Complete Implementation Checklist**

Use this checklist to ensure your components follow the Material 3 Expressive design system.

---

## 🎨 **Theme Setup**

- [ ] Theme file updated with M3 color palette
  - [ ] primary.main: `#BDB0D6` (muted purple)
  - [ ] tertiary.main: `#D8BFD0` (muted pink)
  - [ ] tertiary.contrastText: `#F8FAFC`
  - [ ] surface.container: `#1E1E23`
  - [ ] outline.variant: `#48464F`
- [ ] Typography updated
  - [ ] Headings use Roboto Flex
  - [ ] Body text uses Inter
- [ ] Card variants defined
  - [ ] `variant="outlined"` for content cards
  - [ ] `variant="filled"` for profile/featured cards
- [ ] ThemeProvider wraps app

---

## 📝 **Typography Checklist**

### **Headings**
- [ ] All `h1` components specify Roboto Flex
- [ ] All `h2` components specify Roboto Flex
- [ ] All `h3` components specify Roboto Flex
- [ ] All `h4` components specify Roboto Flex
- [ ] All `h5` components specify Roboto Flex
- [ ] All `h6` components specify Roboto Flex
- [ ] Font weights are 600-700 for headings

### **Body Text**
- [ ] Body text uses default Inter font
- [ ] Captions use Inter font
- [ ] Font weights are 400-500 for body text

### **Example**
```tsx
// ✅ Correct heading
<Typography 
  variant="h4"
  sx={{
    fontFamily: '"Roboto Flex", "Roboto", serif',
    fontWeight: 700,
  }}
>

// ✅ Correct body
<Typography variant="body1">
  {/* Uses Inter by default */}
</Typography>
```

---

## 🃏 **Card Components Checklist**

### **Outlined Cards** (Content, Activity, Actions)
- [ ] Uses `variant="outlined"`
- [ ] Background: `surface.container`
- [ ] Border: 1px solid `outline.variant`
- [ ] Border radius: 16px (4 MUI units)
- [ ] Box shadow: `'none'`
- [ ] No transparency
- [ ] No glass effects

```tsx
// ✅ Correct M3 Outlined Card
<Card
  variant="outlined"
  sx={{
    backgroundColor: 'surface.container',
    borderRadius: 4,
    border: 1,
    borderColor: 'outline.variant',
    boxShadow: 'none',
  }}
>
  <CardContent sx={{ p: 3 }}>
    {/* Content */}
  </CardContent>
</Card>
```

### **Filled Cards** (Profiles, Featured)
- [ ] Uses `variant="filled"`
- [ ] Background: `tertiary.main`
- [ ] NO border
- [ ] Border radius: 16px (4 MUI units)
- [ ] Box shadow: `'none'`
- [ ] Text color: `tertiary.contrastText`
- [ ] All child text uses contrast text

```tsx
// ✅ Correct M3 Filled Card
<Card
  variant="filled"
  sx={{
    backgroundColor: 'tertiary.main',
    borderRadius: 4,
    border: 'none',
    boxShadow: 'none',
    color: 'tertiary.contrastText',
  }}
>
  <CardContent sx={{ p: 3 }}>
    <Typography 
      variant="h6"
      sx={{ color: 'tertiary.contrastText' }}
    >
      Title
    </Typography>
  </CardContent>
</Card>
```

---

## 🎨 **Color Usage Checklist**

### **Primary Color** (#BDB0D6)
- [ ] Used for active tabs
- [ ] Used for accent icons
- [ ] Used for primary buttons
- [ ] Used for borders on hover
- [ ] NOT used for large backgrounds

### **Tertiary Color** (#D8BFD0)
- [ ] Used for filled card backgrounds
- [ ] Used for secondary accents
- [ ] NOT used for large gradients

### **Text Colors**
- [ ] High contrast text: `text.primary` (#F8FAFC)
- [ ] Muted text: `text.secondary` (#E2E8F0)
- [ ] Disabled text: `text.disabled` (#94A3B8)
- [ ] Filled card text: `tertiary.contrastText` (#F8FAFC)

### **Surface Colors**
- [ ] Card backgrounds: `surface.container` (#1E1E23)
- [ ] Elevated surfaces: `surface.containerHigh` (#262629)

### **Outline Colors**
- [ ] Card borders: `outline.variant` (#48464F)
- [ ] Dividers: `outline.variant`

---

## 🚫 **Things to Remove**

### **Glass Morphism**
- [ ] No `backdropFilter` properties
- [ ] No `WebkitBackdropFilter` properties
- [ ] No transparent backgrounds (`rgba(...)`)
- [ ] No blur effects

### **Heavy Effects**
- [ ] No large box shadows
- [ ] No glow effects (except subtle hover states)
- [ ] No shimmer animations (unless specific use case)
- [ ] No gradient backgrounds (except small accents)

### **Old Colors**
- [ ] No `#A78BFA` (old primary)
- [ ] No `#F472B6` (old tertiary)
- [ ] No bright/vibrant accent colors

---

## 🎯 **Component-Specific Checklists**

### **Profile Cards**
- [ ] Uses M3ProfileCard component
- [ ] Has botanical illustration (leaf shapes)
- [ ] Filled card background
- [ ] Three-layer design (Base + Media + Content)
- [ ] Color-coded ATS score
- [ ] Text uses `tertiary.contrastText`
- [ ] Stat boxes with semi-transparent backgrounds

```tsx
// ✅ Correct Profile Card Usage
<M3ProfileCard
  name="Name"
  role="Role"
  activeApplications={5}
  atsScore={85}
  lastUpdated="1 day ago"
  onEdit={() => {}}
  onDelete={() => {}}
/>
```

### **Icon Containers**
- [ ] Padding: 1.5 units (12px)
- [ ] Background: `alpha(color, 0.12)`
- [ ] Border radius: 2 units (16px)
- [ ] Icon size: 20px

```tsx
// ✅ Correct Icon Container
<Box
  sx={{
    p: 1.5,
    bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
    borderRadius: 2,
  }}
>
  <Icon size={20} color="#BDB0D6" />
</Box>
```

### **Progress Bars**
- [ ] Height: 8px
- [ ] Border radius: 4px
- [ ] Background: `alpha(color, 0.2)`
- [ ] Bar color: Based on value (green/yellow/red)

```tsx
// ✅ Correct Progress Bar
<LinearProgress
  variant="determinate"
  value={score}
  sx={{
    height: 8,
    borderRadius: 4,
    bgcolor: alpha('#BDB0D6', 0.2),
    '& .MuiLinearProgress-bar': {
      bgcolor: scoreColor,
      borderRadius: 4,
    },
  }}
/>
```

### **Buttons**
- [ ] Primary buttons use `bgcolor: 'primary.main'`
- [ ] Secondary buttons use outlined variant
- [ ] NO gradient backgrounds
- [ ] Box shadow: `'none'`
- [ ] Font weight: 600

```tsx
// ✅ Correct Primary Button
<Button
  variant="contained"
  sx={{
    bgcolor: 'primary.main',
    color: 'primary.contrastText',
    fontWeight: 600,
    boxShadow: 'none',
  }}
>
  Action
</Button>
```

---

## 📐 **Layout Checklist**

### **Page Structure**
- [ ] Container with `maxWidth="xl"`
- [ ] Background: `background.default`
- [ ] Padding: 6 units (48px) vertical
- [ ] Grid spacing: 3 units (24px)

```tsx
// ✅ Correct Page Layout
<Box sx={{ minHeight: '100vh', bgcolor: 'background.default', py: 6 }}>
  <Container maxWidth="xl">
    {/* Content */}
  </Container>
</Box>
```

### **Spacing**
- [ ] Uses 8px grid system
- [ ] Padding: 1-6 units
- [ ] Gaps: 1-4 units
- [ ] Margins: 1-8 units

---

## 🎨 **Botanical Elements Checklist**

### **Profile Card Media Layer**
- [ ] SVG leaf shapes
- [ ] Muted green colors (#A8C9A0, #B5D4AD)
- [ ] Opacity: 60-70%
- [ ] Position: Bottom-right
- [ ] Z-index: 1 (behind content)
- [ ] Pointer events: none

---

## 🧪 **Testing Checklist**

### **Visual Testing**
- [ ] No glass blur effects visible
- [ ] All cards have solid backgrounds
- [ ] Text is readable on filled cards
- [ ] Colors are muted (not vibrant)
- [ ] Headings use Roboto Flex
- [ ] Body text uses Inter
- [ ] Border radius is consistent (16px)
- [ ] No heavy shadows

### **Accessibility Testing**
- [ ] Text contrast ratio meets WCAG AA
- [ ] Filled card text uses high contrast color
- [ ] Focus states are visible
- [ ] Keyboard navigation works
- [ ] Screen reader labels present

### **Responsive Testing**
- [ ] Cards stack properly on mobile
- [ ] Typography scales appropriately
- [ ] Touch targets are 48x48px minimum
- [ ] Spacing adjusts for small screens

---

## 📚 **Documentation Checklist**

- [ ] Component has TypeScript Props interface
- [ ] Usage examples provided
- [ ] Design tokens documented
- [ ] Edge cases handled
- [ ] Accessibility notes included

---

## 🔍 **Code Review Checklist**

### **Search for These Anti-Patterns**
```bash
# ❌ Find and remove/replace:
backdropFilter
WebkitBackdropFilter
rgba(30, 30, 35
rgba(167, 139, 250
#A78BFA
#F472B6
variant="glass"
variant="aurora"
animation: shimmer
```

### **Verify These Patterns Exist**
```bash
# ✅ Should find:
variant="outlined"
variant="filled"
tertiary.contrastText
Roboto Flex
borderRadius: 4
boxShadow: 'none'
surface.container
```

---

## ✅ **Pre-Deployment Checklist**

### **Before Going Live**
- [ ] All components follow M3 guidelines
- [ ] Theme is properly configured
- [ ] No glass morphism effects
- [ ] All colors updated to muted palette
- [ ] Typography uses correct fonts
- [ ] Cards use M3 variants
- [ ] No console errors
- [ ] Accessibility verified
- [ ] Documentation updated
- [ ] Code reviewed

### **Files to Review**
- [ ] `/theme.ts` - M3 theme configuration
- [ ] `/mui-components/*.tsx` - All components
- [ ] `/guidelines/Guidelines.md` - Design docs
- [ ] Component imports use MUI components

---

## 📊 **Component Inventory**

### **Check Each Component**
Go through each component file and verify:

#### **Dashboard Components**
- [ ] Dashboard.tsx
- [ ] ProfileCard.tsx
- [ ] CreateProfileCard.tsx
- [ ] DashboardView.tsx

#### **View Components**
- [ ] DocumentsView.tsx
- [ ] ApplicationsView.tsx
- [ ] OpportunitiesView.tsx
- [ ] AnalysisView.tsx

#### **Feature Components**
- [ ] CareerGrowthHub.tsx
- [ ] JobMatching.tsx
- [ ] CareerIntelligence.tsx
- [ ] InterviewPrep.tsx
- [ ] ResumeBuilder.tsx

#### **Support Components**
- [ ] AppShell.tsx
- [ ] Settings.tsx
- [ ] Auth.tsx

---

## 🎉 **Completion Criteria**

### **You're Done When:**
- ✅ All checkboxes above are marked
- ✅ No glass morphism effects anywhere
- ✅ All colors match M3 palette
- ✅ All typography uses correct fonts
- ✅ All cards use M3 variants
- ✅ Visual tests pass
- ✅ Accessibility tests pass
- ✅ Code review complete
- ✅ Documentation updated

### **Success Indicators:**
- 🎨 Design looks clean and professional
- 📐 Consistent 16px border radius
- 🎯 Muted purple/pink accents
- 📝 Clear typographic hierarchy
- ♿ High accessibility scores
- 🚀 Ready for production

---

## 📖 **Reference Documents**

- **Design System**: `/M3_DESIGN_SYSTEM_README.md`
- **Migration Guide**: `/M3_MIGRATION_GUIDE.md`
- **Update Summary**: `/M3_UPDATE_SUMMARY.md`
- **Component Examples**: `/mui-components/M3CardExamples.tsx`
- **Theme Config**: `/theme.ts`
- **Guidelines**: `/guidelines/Guidelines.md`

---

**Use this checklist for every component to ensure M3 compliance!** ✅🌿
