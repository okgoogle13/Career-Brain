# Migration Guide: Tailwind → Material-UI (MUI)

## Overview
This guide shows you how to migrate from Tailwind CSS to Material-UI for the FML Career Copilot application, maintaining the Aurora theme aesthetic.

## Setup Steps

### 1. Install MUI Dependencies
```bash
npm install @mui/material @mui/icons-material @emotion/react @emotion/styled
```

### 2. Wrap App with ThemeProvider
See `/MuiApp.tsx` for the complete setup example.

## Migration Patterns

### Pattern 1: Converting Basic Card Components

#### Before (Tailwind):
```tsx
<div className="bg-surface-container rounded-lg p-6 border border-outline-variant hover:border-primary transition-all">
  <h3 className="text-xl font-semibold text-on-surface">Title</h3>
  <p className="text-sm text-on-surface-variant mt-2">Description</p>
</div>
```

#### After (MUI):
```tsx
<Card 
  variant="glass"
  sx={{
    p: 3,
    '&:hover': {
      borderColor: 'primary.main',
      boxShadow: (theme) => theme.customShadows.glowPrimary,
    }
  }}
>
  <Typography variant="h5" color="text.primary">
    Title
  </Typography>
  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
    Description
  </Typography>
</Card>
```

### Pattern 2: Converting Buttons

#### Before (Tailwind):
```tsx
<button className="bg-primary hover:bg-primary-dark text-white px-6 py-2 rounded-lg transition-all hover:shadow-glow-primary">
  Click Me
</button>
```

#### After (MUI):
```tsx
<Button 
  variant="aurora"
  sx={{
    px: 3,
    py: 1.25,
  }}
>
  Click Me
</Button>
```

### Pattern 3: Converting Grid Layouts

#### Before (Tailwind):
```tsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
  {items.map(item => <div key={item.id}>...</div>)}
</div>
```

#### After (MUI):
```tsx
<Grid container spacing={2}>
  {items.map(item => (
    <Grid item xs={12} md={6} lg={4} key={item.id}>
      ...
    </Grid>
  ))}
</Grid>
```

### Pattern 4: Converting Glass Morphism Effects

#### Before (Tailwind):
```tsx
<div className="glass-bg backdrop-blur-md border border-glass rounded-xl">
  Content
</div>
```

#### After (MUI):
```tsx
<Paper variant="glass" sx={{ borderRadius: 3, p: 2 }}>
  Content
</Paper>
```

### Pattern 5: Converting Aurora Gradient Borders

#### Before (Tailwind):
```tsx
<div className="aurora-border p-[2px] rounded-xl">
  <div className="bg-surface-container rounded-xl p-6">
    Content
  </div>
</div>
```

#### After (MUI):
```tsx
<Box
  sx={{
    p: '2px',
    borderRadius: 3,
    background: (theme) => `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.tertiary.main})`,
  }}
>
  <Card sx={{ borderRadius: '22px', p: 3 }}>
    Content
  </Card>
</Box>
```

### Pattern 6: Converting Form Inputs

#### Before (Tailwind):
```tsx
<input 
  type="text"
  className="w-full px-4 py-2 bg-surface-container-high border border-outline rounded-lg focus:border-primary focus:ring-2 focus:ring-primary/20"
  placeholder="Enter text"
/>
```

#### After (MUI):
```tsx
<TextField
  fullWidth
  placeholder="Enter text"
  variant="outlined"
/>
```

### Pattern 7: Converting Flexbox Layouts

#### Before (Tailwind):
```tsx
<div className="flex items-center justify-between gap-4">
  <div>Left</div>
  <div>Right</div>
</div>
```

#### After (MUI):
```tsx
<Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2 }}>
  <Box>Left</Box>
  <Box>Right</Box>
</Box>
```

## Theme Token Mapping

### Colors
| Tailwind Class | MUI Theme Path |
|---------------|----------------|
| `text-on-surface` | `text.primary` |
| `text-on-surface-variant` | `text.secondary` |
| `bg-background` | `background.default` |
| `bg-surface-container` | `surface.container` |
| `bg-primary` | `primary.main` |
| `bg-tertiary` | `tertiary.main` |
| `border-outline` | `outline.main` |
| `border-outline-variant` | `outline.variant` |

### Spacing
| Tailwind Class | MUI sx Prop |
|---------------|-------------|
| `p-2` | `p: 1` |
| `p-4` | `p: 2` |
| `p-6` | `p: 3` |
| `gap-2` | `gap: 1` |
| `gap-4` | `gap: 2` |
| `gap-6` | `gap: 3` |

Note: MUI uses 8px base spacing unit (theme.spacing(1) = 8px)

### Shadows
| Custom Tailwind | MUI Theme Path |
|-----------------|----------------|
| `shadow-glow-primary` | `customShadows.glowPrimary` |
| `shadow-glow-aurora` | `customShadows.glowAurora` |
| `shadow-glass` | `customShadows.glass` |

### Border Radius
| Tailwind Class | MUI sx Prop |
|---------------|-------------|
| `rounded` | `borderRadius: 1.5` (12px) |
| `rounded-lg` | `borderRadius: 2` (16px) |
| `rounded-xl` | `borderRadius: 3` (24px) |

## Component Variants

The theme defines custom variants you can use:

### Card/Paper Variants
- `variant="glass"` - Glass morphism effect
- `variant="interactive"` - Hover lift effect with glow

### Button Variants
- `variant="aurora"` - Aurora gradient with shimmer animation
- `variant="glass"` - Glass morphism button
- `variant="contained"` - Standard filled button
- `variant="outlined"` - Outlined button
- `variant="text"` - Text-only button

## Common Patterns

### Icon with Text
```tsx
<Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
  <SparklesIcon sx={{ fontSize: 20, color: 'primary.main' }} />
  <Typography variant="body2">AI-Powered</Typography>
</Box>
```

### Badge/Chip
```tsx
<Chip 
  label="New"
  size="small"
  sx={{
    background: (theme) => alpha(theme.palette.tertiary.main, 0.2),
    color: 'tertiary.main',
    border: (theme) => `1px solid ${alpha(theme.palette.tertiary.main, 0.3)}`,
  }}
/>
```

### Stat Display
```tsx
<Box>
  <Typography variant="h3" color="primary.main" sx={{ fontWeight: 700 }}>
    42
  </Typography>
  <Typography variant="body2" color="text.secondary">
    Applications
  </Typography>
</Box>
```

## Tips

1. **Use sx prop for one-off styling** - Avoid inline styles
2. **Use styled() for repeated patterns** - Create reusable styled components
3. **Access theme values** - Use callback: `sx={{ color: (theme) => theme.palette.primary.main }}`
4. **Responsive breakpoints** - Use `sx={{ display: { xs: 'none', md: 'block' } }}`
5. **Custom shadows** - Access via `(theme) => theme.customShadows.glowPrimary`
6. **Glass effects** - Use `variant="glass"` on Card/Paper components
7. **Aurora gradients** - Use `variant="aurora"` on Buttons

## Next Steps

1. Import your Figma design file
2. I'll convert each page/component to MUI
3. All components will use TypeScript with proper Props interfaces
4. All styling will come from theme.ts (no Tailwind)
