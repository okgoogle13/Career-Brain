import React from 'react';
import { ThemeProvider } from '@mui/material/styles';
import { CssBaseline } from '@mui/material';
import theme from './theme';
import { M3CardExamples } from './mui-components/M3CardExamples';

/**
 * M3ExampleApp - Demonstrates Material 3 Expressive Design System
 * 
 * This app showcases:
 * - Updated color palette (muted purple/pink)
 * - Roboto Flex headings + Inter body text
 * - M3 Outlined and Filled card variants
 * - Profile cards with botanical illustrations
 * - Clean, professional aesthetic
 * 
 * To use this example:
 * 1. Import in App.tsx or index.tsx
 * 2. Render <M3ExampleApp />
 * 3. View all M3 components in action
 */
function M3ExampleApp() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <M3CardExamples />
    </ThemeProvider>
  );
}

export default M3ExampleApp;
