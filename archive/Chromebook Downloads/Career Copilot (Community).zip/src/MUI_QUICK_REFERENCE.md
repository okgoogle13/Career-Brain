# Material 3 Expressive - Quick Reference Guide

## 🎨 **Design System Cheat Sheet**

### **Typography**

```typescript
// ✅ HEADINGS - Always use Roboto Flex
<Typography
  variant="h1" // or h2, h3, h4, h5, h6
  sx={{
    fontFamily: '"Roboto Flex", "Roboto", serif',
    fontWeight: 700, // or 600 for subheadings
  }}
>
  Your Heading Here
</Typography>

// ✅ BODY TEXT - Uses default Roboto
<Typography variant="body1" color="text.secondary">
  Your body text here
</Typography>
```

---

### **Cards**

```typescript
// ✅ SOLID CARDS (NO glass morphism)
<Card
  sx={{
    bgcolor: 'surface.container',    // #1E1E23
    border: 1,
    borderColor: 'outline.variant',  // #48464F
    transition: 'all 0.3s',
    '&:hover': {
      borderColor: 'primary.main',
      boxShadow: (theme) => `0 4px 16px ${alpha(theme.palette.primary.main, 0.08)}`,
    },
  }}
>
  <CardContent sx={{ p: 3 }}>
    {/* Content */}
  </CardContent>
</Card>
```

---

### **Buttons**

```typescript
// ✅ PRIMARY BUTTON
<Button
  variant="contained"
  sx={{
    bgcolor: 'primary.main',
    color: 'primary.contrastText',
    fontWeight: 600,
  }}
>
  Primary Action
</Button>

// ✅ SECONDARY/TERTIARY BUTTON
<Button
  variant="contained"
  sx={{
    bgcolor: 'tertiary.main',
    color: 'tertiary.contrastText',
    fontWeight: 600,
    '&:hover': {
      bgcolor: 'tertiary.dark',
    },
  }}
>
  Special Action
</Button>

// ✅ OUTLINED BUTTON
<Button
  variant="outlined"
  sx={{
    borderColor: 'outline.main',
    color: 'text.secondary',
  }}
>
  Secondary Action
</Button>
```

---

### **Icon Containers**

```typescript
// ✅ ACCENT ICON BACKGROUND
<Box
  sx={{
    p: 1.5,
    bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
    borderRadius: 2,
  }}
>
  <Icon size={20} color="#A78BFA" />
</Box>

// Different colors for different sections:
// Primary: alpha(theme.palette.primary.main, 0.12) + color="#A78BFA"
// Tertiary: alpha(theme.palette.tertiary.main, 0.12) + color="#F472B6"
// Success: alpha(theme.palette.success.main, 0.12) + color="#86EFAC"
```

---

### **Gradient Text**

```typescript
// ✅ PRIMARY TO TERTIARY GRADIENT
<Typography
  sx={{
    fontFamily: '"Roboto Flex", "Roboto", serif',
    fontWeight: 700,
    background: (theme) => `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.tertiary.main})`,
    backgroundClip: 'text',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
  }}
>
  Gradient Heading
</Typography>
```

---

### **Chips/Badges**

```typescript
// ✅ PRIMARY CHIP
<Chip
  label="Active"
  sx={{
    bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
    color: 'primary.main',
    fontWeight: 600,
  }}
/>

// ✅ WITH ICON
<Chip
  icon={<Sparkles size={14} />}
  label="AI Powered"
  size="small"
  sx={{
    bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
    color: 'primary.main',
    border: 1,
    borderColor: (theme) => alpha(theme.palette.primary.main, 0.3),
  }}
/>
```

---

### **Progress Bars**

```typescript
// ✅ LINEAR PROGRESS
<LinearProgress
  variant="determinate"
  value={75}
  sx={{
    height: 6,
    borderRadius: 3,
    bgcolor: (theme) => alpha(theme.palette.primary.main, 0.2),
    '& .MuiLinearProgress-bar': {
      bgcolor: 'primary.main',
      borderRadius: 3,
    },
  }}
/>
```

---

### **Layout Containers**

```typescript
// ✅ PAGE CONTAINER
<Box sx={{ minHeight: '100vh', bgcolor: 'background.default', py: 4 }}>
  <Container maxWidth="xl">
    {/* Content */}
  </Container>
</Box>

// ✅ SECTION SPACING
<Box sx={{ mb: 6 }}>  // 48px margin bottom
  {/* Section content */}
</Box>

// ✅ GRID LAYOUT
<Grid container spacing={3}>
  <Grid item xs={12} md={6} lg={4}>
    {/* Grid item */}
  </Grid>
</Grid>
```

---

## 🎯 **Color Reference**

### **Theme Colors**
```typescript
primary.main: '#A78BFA'          // Vibrant Purple
primary.light: '#C4B5FD'
primary.dark: '#8B5CF6'

tertiary.main: '#F472B6'         // Bright Pink
tertiary.light: '#FBCFE8'
tertiary.dark: '#DB2777'

success.main: '#86EFAC'          // Green
warning.main: '#FDE047'          // Yellow
error.main: '#FFB4AB'            // Red

background.default: '#131318'     // Deep Dark
background.paper: '#1E1E23'      // Surface

surface.container: '#1E1E23'     // Card backgrounds
outline.variant: '#48464F'       // Borders

text.primary: '#F8FAFC'          // High contrast white
text.secondary: '#E2E8F0'        // Muted white
```

### **Usage Guidelines**
```typescript
// ✅ Use colors as accents
bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12)  // Subtle background
color: 'primary.main'                                         // Accent color

// ❌ Don't use for large backgrounds
bgcolor: 'primary.main'  // Only for buttons/small elements
```

---

## 📏 **Spacing System**

```typescript
// Base unit: 8px
spacing: 8

// Common values:
sx={{ p: 1 }}    // 8px
sx={{ p: 2 }}    // 16px
sx={{ p: 3 }}    // 24px
sx={{ p: 4 }}    // 32px
sx={{ p: 6 }}    // 48px

// Directional:
sx={{ px: 3 }}   // horizontal padding
sx={{ py: 4 }}   // vertical padding
sx={{ mt: 2 }}   // margin top
sx={{ mb: 6 }}   // margin bottom
```

---

## 🎨 **Common Patterns**

### **Empty State**
```typescript
<Box
  sx={{
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    py: 15,
    borderRadius: 3,
    border: 2,
    borderStyle: 'dashed',
    borderColor: (theme) => alpha(theme.palette.primary.main, 0.3),
    bgcolor: (theme) => alpha(theme.palette.surface.container, 0.4),
    textAlign: 'center',
  }}
>
  <Box
    sx={{
      p: 3,
      borderRadius: '50%',
      bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
      mb: 3,
    }}
  >
    <Icon size={48} color="#A78BFA" />
  </Box>
  <Typography variant="h6">Empty State Title</Typography>
  <Typography variant="body2" color="text.secondary">
    Description text
  </Typography>
</Box>
```

### **Stat Card**
```typescript
<Card sx={{ bgcolor: 'surface.container', border: 1, borderColor: 'outline.variant' }}>
  <CardContent sx={{ p: 3 }}>
    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <Box>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
          Stat Label
        </Typography>
        <Typography
          variant="h4"
          sx={{
            fontFamily: '"Roboto Flex", "Roboto", serif',
            fontWeight: 700,
            color: 'primary.main',
          }}
        >
          123
        </Typography>
      </Box>
      <Box
        sx={{
          p: 1.5,
          bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12),
          borderRadius: 2,
        }}
      >
        <Icon size={24} color="#A78BFA" />
      </Box>
    </Box>
  </CardContent>
</Card>
```

### **Header Section**
```typescript
<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 6 }}>
  <Box>
    <Typography
      variant="h4"
      sx={{
        fontFamily: '"Roboto Flex", "Roboto", serif',
        fontWeight: 700,
        mb: 1,
      }}
    >
      Page Title
    </Typography>
    <Typography variant="body1" color="text.secondary">
      Page description
    </Typography>
  </Box>
  <Button
    variant="contained"
    startIcon={<Plus size={16} />}
    sx={{
      bgcolor: 'primary.main',
      fontWeight: 600,
    }}
  >
    Action
  </Button>
</Box>
```

---

## ❌ **What NOT to Do**

### **Don't Use:**
```typescript
// ❌ NO Glass Morphism
backdropFilter: 'blur(24px)'
background: 'rgba(30, 30, 35, 0.7)'

// ❌ NO Large Gradient Backgrounds
background: 'linear-gradient(to-br, from-primary/30 to-tertiary/30)'

// ❌ NO Font Size/Weight in Typography
<Typography className="text-2xl font-bold">  // Tailwind classes

// ❌ NO Transparent Cards
bgcolor: 'rgba(30, 30, 35, 0.5)'

// ❌ NO Shimmer/Pulse Effects (unless specifically needed)
animation: 'shimmer 2s infinite'
```

### **Always Use:**
```typescript
// ✅ Solid Cards
bgcolor: 'surface.container'

// ✅ MUI Theme Colors
color: 'primary.main'
bgcolor: (theme) => alpha(theme.palette.primary.main, 0.12)

// ✅ Theme Typography
fontFamily: '"Roboto Flex", "Roboto", serif'  // Only for headings

// ✅ Alpha for Subtle Backgrounds
alpha(theme.palette.primary.main, 0.12)  // 12% opacity
```

---

## 🚀 **Quick Component Template**

```typescript
import React from 'react';
import { Box, Typography, Button, Card, CardContent } from '@mui/material';
import { Icon } from 'lucide-react';

export interface MyComponentProps {
  title: string;
  onAction: () => void;
}

export const MyComponent: React.FC<MyComponentProps> = ({ title, onAction }) => {
  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default', py: 4 }}>
      <Container maxWidth="xl">
        {/* Header */}
        <Box sx={{ mb: 6 }}>
          <Typography
            variant="h4"
            sx={{
              fontFamily: '"Roboto Flex", "Roboto", serif',
              fontWeight: 700,
              mb: 1,
            }}
          >
            {title}
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Description
          </Typography>
        </Box>

        {/* Content */}
        <Card sx={{ bgcolor: 'surface.container', border: 1, borderColor: 'outline.variant' }}>
          <CardContent sx={{ p: 4 }}>
            {/* Your content here */}
          </CardContent>
        </Card>

        {/* Actions */}
        <Box sx={{ mt: 4 }}>
          <Button
            variant="contained"
            onClick={onAction}
            sx={{
              bgcolor: 'primary.main',
              fontWeight: 600,
            }}
          >
            Action
          </Button>
        </Box>
      </Container>
    </Box>
  );
};

export default MyComponent;
```

---

## 📚 **Import Patterns**

```typescript
// MUI Core
import { Box, Typography, Button, Container } from '@mui/material';
import { alpha } from '@mui/material/styles';

// Icons
import { Icon1, Icon2 } from 'lucide-react';

// Components
import { MyComponent } from './mui-components';

// Types
import type { MyComponentProps } from './mui-components';
```

---

## ✅ **Checklist for New Components**

- [ ] Roboto Flex for ALL headings (h1-h6)
- [ ] Roboto for body text (MUI default)
- [ ] Solid cards with `surface.container` background
- [ ] Borders with `outline.variant` color
- [ ] NO glass morphism or blur effects
- [ ] Colors as accents only (using `alpha()`)
- [ ] TypeScript Props interface
- [ ] Responsive layout (Grid/Container)
- [ ] Consistent spacing (8px base unit)
- [ ] Hover states with transitions
- [ ] Exported from index.ts

---

**This quick reference covers 90% of common design patterns in the Material 3 Expressive system!** 🎨

For complete examples, see the component files in `/mui-components/`. 🚀
