import plotly.graph_objects as go
import plotly.express as px
import pandas as pd

# Data for the comparison
categories = ["Templates", "Design", "Workflow", "Compliance", "User Experience"]
current_caps = [
    "Basic templates",
    "Standard format", 
    "Linear process",
    "General formats",
    "Single-mode"
]
enhanced_caps = [
    "Advanced multi-format",
    "5 pro themes + ATS",
    "Track→Optimize→Apply", 
    "Regional + KSC",
    "Multi-modal guide"
]

# Create positions for the bars
y_pos = list(range(len(categories)))
y_current = [i - 0.2 for i in y_pos]
y_enhanced = [i + 0.2 for i in y_pos]

# Create the figure
fig = go.Figure()

# Add current capabilities bars
fig.add_trace(go.Bar(
    name='Current',
    y=y_current,
    x=[1] * len(categories),
    orientation='h',
    marker_color='#5D878F',  # Cyan from brand colors
    hovertemplate='<b>%{customdata}</b><br>Current Capability<extra></extra>',
    customdata=current_caps,
    cliponaxis=False,
    width=0.35,
    text=current_caps,
    textposition='inside',
    textfont=dict(color='white', size=12)
))

# Add enhanced capabilities bars  
fig.add_trace(go.Bar(
    name='Enhanced',
    y=y_enhanced,
    x=[1.5] * len(categories),
    orientation='h',
    marker_color='#1FB8CD',  # Strong cyan (green-adjacent from brand colors)
    hovertemplate='<b>%{customdata}</b><br>Enhanced Capability<extra></extra>',
    customdata=enhanced_caps,
    cliponaxis=False,
    width=0.35,
    text=enhanced_caps,
    textposition='inside',
    textfont=dict(color='white', size=12)
))

# Update layout
fig.update_layout(
    title='Resume Agent 3.0: Current vs Enhanced',
    xaxis_title='Capability Level',
    yaxis_title='Categories',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    yaxis=dict(
        tickmode='array',
        tickvals=y_pos,
        ticktext=categories,
        range=[-0.5, len(categories) - 0.5]
    ),
    xaxis=dict(range=[0, 2], showticklabels=False)
)

# Update axes
fig.update_xaxes(showgrid=False)
fig.update_yaxes(showgrid=False)

# Save the chart
fig.write_image("resume_agent_comparison.png")