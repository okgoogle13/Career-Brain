import plotly.graph_objects as go
import plotly.express as px
import pandas as pd

# Data for the integration roadmap
data = [
    {
        "phase": "Phase 1: Found",
        "start": 1,
        "end": 2,
        "type": "Foundation/Tmp",
        "components": "Resume, Cover"
    },
    {
        "phase": "Phase 2: Design",
        "start": 3,
        "end": 4,
        "type": "Design/Visual",
        "components": "PDF, ATS, Indus"
    },
    {
        "phase": "Phase 3: Workflow",
        "start": 5,
        "end": 6,
        "type": "Workflow/Proc",
        "components": "Workflow, Loop"
    },
    {
        "phase": "Phase 4: Special",
        "start": 7,
        "end": 8,
        "type": "Compliance/Sp",
        "components": "Criteria, STAR"
    }
]

# Brand colors in order
colors = ['#1FB8CD', '#FFC185', '#ECEBD5', '#5D878F']

# Create the horizontal timeline chart
fig = go.Figure()

# Add bars for each phase
for i, phase_data in enumerate(data):
    duration = phase_data['end'] - phase_data['start'] + 1
    
    # Add the horizontal bar
    fig.add_trace(go.Bar(
        x=[duration],
        y=[phase_data['phase']],
        base=[phase_data['start'] - 0.5],  # Start position
        orientation='h',
        marker_color=colors[i],
        name=phase_data['type'],
        text=phase_data['components'],
        textposition='inside',
        hovertemplate='<b>%{y}</b><br>Months: %{base:.0f}-%{x}<br>Components: %{text}<extra></extra>',
        cliponaxis=False
    ))

# Update layout
fig.update_layout(
    title="ERA 3.0 Roadmap",
    xaxis_title="Month",
    yaxis_title="Phase",
    xaxis=dict(
        range=[0, 9],
        tickmode='linear',
        tick0=1,
        dtick=1
    ),
    showlegend=True,
    legend=dict(
        orientation='h',
        yanchor='bottom',
        y=1.05,
        xanchor='center',
        x=0.5
    )
)

# Save the chart
fig.write_image("integration_roadmap.png")
fig.show()