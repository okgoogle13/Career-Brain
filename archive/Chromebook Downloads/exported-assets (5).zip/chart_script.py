import plotly.graph_objects as go
import plotly.express as px
import pandas as pd

# Data for the integration roadmap
data = [
    {
        "phase": "Phase 1: Foundation Integration",
        "start_month": 1,
        "end_month": 2,
        "color": "#2563eb",
        "components": [
            "Resume Template Integration",
            "Cover Letter Template Integration", 
            "Basic Template System Enhancement"
        ]
    },
    {
        "phase": "Phase 2: Visual Design System", 
        "start_month": 3,
        "end_month": 4,
        "color": "#dc2626",
        "components": [
            "PDF Themes Design Implementation",
            "ATS vs Visual Impact Classification",
            "Industry-Specific Theme Selection"
        ]
    },
    {
        "phase": "Phase 3: Workflow Enhancement",
        "start_month": 5,
        "end_month": 6,
        "color": "#059669",
        "components": [
            "Hybrid Workflow Implementation",
            "User Journey Optimization",
            "Learning Loop Integration"
        ]
    },
    {
        "phase": "Phase 4: Specialized Documents",
        "start_month": 7,
        "end_month": 8,
        "color": "#7c3aed",
        "components": [
            "Key Selection Criteria Support",
            "Regional Compliance Features",
            "STAR Method Integration"
        ]
    }
]

# Use brand colors as specified in instructions
brand_colors = ["#1FB8CD", "#FFC185", "#ECEBD5", "#5D878F"]

# Create the Gantt-style chart
fig = go.Figure()

# Add bars for each phase
for i, phase_data in enumerate(data):
    # Abbreviate phase names to fit 15 character limit
    phase_names = {
        "Phase 1: Foundation Integration": "P1: Foundation",
        "Phase 2: Visual Design System": "P2: Visual Des",
        "Phase 3: Workflow Enhancement": "P3: Workflow",
        "Phase 4: Specialized Documents": "P4: Specialized"
    }
    
    phase_name = phase_names[phase_data["phase"]]
    duration = phase_data["end_month"] - phase_data["start_month"] + 1
    
    # Create hover text with components (abbreviated)
    components_text = "<br>".join([
        comp[:22] + "..." if len(comp) > 22 else comp 
        for comp in phase_data["components"]
    ])
    
    fig.add_trace(go.Bar(
        x=[duration],
        y=[phase_name],
        orientation='h',
        name=phase_name,
        marker_color=brand_colors[i],
        base=phase_data["start_month"] - 1,
        hovertemplate=f"<b>{phase_name}</b><br>Months: {phase_data['start_month']}-{phase_data['end_month']}<br>{components_text}<extra></extra>",
        showlegend=False,
        cliponaxis=False
    ))

# Update layout
fig.update_layout(
    title="Enhanced Resume Agent 3.0 Roadmap",
    xaxis_title="Month",
    yaxis_title="Phase",
    barmode='overlay'
)

# Update x-axis to show months 1-8
fig.update_xaxes(
    range=[0, 8],
    tickvals=list(range(1, 9)),
    ticktext=[f"M{i}" for i in range(1, 9)]
)

# Update y-axis to reverse order so Phase 1 is at top
fig.update_yaxes(autorange="reversed")

# Save the chart
fig.write_image("integration_roadmap.png")