# 16. Create the main README.md file
readme_content = '''# Enhanced Resume Agent 3.0

> **AI-powered career document generation system for personal use**

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

Enhanced Resume Agent 3.0 is a comprehensive, AI-powered career document generation system designed for personal use. It leverages Google Gemini 2.5 Pro and Perplexity API to automate the creation of ATS-optimized resumes, cover letters, and key selection criteria responses.

## ✨ Features

### 🎯 Core Capabilities
- **AI-Powered Resume Optimization** - Tailors resumes to specific job descriptions using Google Gemini
- **Company Research** - Automated company intelligence via Perplexity API
- **ATS Compatibility** - Ensures 90%+ ATS compatibility with optimized formatting
- **Multi-Format Document Generation** - Resumes, cover letters, and KSC responses
- **Professional Themes** - 5 carefully designed resume themes for different industries

### 🔧 Technical Features
- **Vector-Based Experience Matching** - ChromaDB integration for intelligent experience selection
- **Dual Interface** - Both CLI and Streamlit web interface
- **Personal Data Management** - SQLite database for single-user optimization
- **Cloud-Ready Deployment** - Docker and Google Cloud Run support
- **Comprehensive Testing** - Full test suite with CI/CD pipeline

### 🌏 Regional Compliance
- **Australian Government Jobs** - Specialized KSC response templates with STAR method
- **International Standards** - Adaptable templates for global job markets

## 🚀 Quick Start

### Prerequisites
- Python 3.11 or higher
- Google Gemini API key
- Perplexity API key

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd enhanced-resume-agent
   ```

2. **Set up environment**
   ```bash
   # Using Make (recommended)
   make dev-setup
   
   # Or manually
   pip install -r requirements.txt
   cp .env.example .env
   ```

3. **Configure API keys**
   Edit `.env` file with your API keys:
   ```bash
   GOOGLE_GEMINI_API_KEY=your_gemini_api_key_here
   PERPLEXITY_API_KEY=your_perplexity_api_key_here
   ```

4. **Initialize the system**
   ```bash
   # CLI initialization
   python -m src.cli init --email your@email.com --name "Your Name"
   
   # Or use the web interface
   make run-web
   ```

### First Run

**Web Interface (Recommended for beginners):**
```bash
make run-web
# Opens http://localhost:8501
```

**Command Line Interface:**
```bash
# Check system status
python -m src.cli status

# Add work experience
python -m src.cli experience add

# Research a company
python -m src.cli research "Google"
```

## 📖 Usage Guide

### Web Interface

The Streamlit web interface provides an intuitive way to:

1. **Manage Profile** - Set up personal information and contact details
2. **Add Experiences** - Input work history, education, skills, and projects  
3. **Research Companies** - Get AI-powered company insights
4. **Generate Documents** - Create optimized resumes and cover letters
5. **Track Applications** - Monitor job application progress

Navigate to different sections using the sidebar menu.

### CLI Interface

The command-line interface offers powerful automation capabilities:

```bash
# System management
python -m src.cli init          # Initialize user profile
python -m src.cli status        # Show system status
python -m src.cli profile       # Manage profile information

# Experience management  
python -m src.cli experience add    # Add work experience
python -m src.cli experience list   # List all experiences

# Research and analysis
python -m src.cli research "Company Name"  # Research company

# Launch web interface
python -m src.cli web           # Start Streamlit app
```

## 🏗️ Architecture

### System Components

```
Enhanced Resume Agent 3.0/
├── src/                    # Core application code
│   ├── agents/            # AI agents for different tasks
│   ├── integrations/      # External API integrations
│   ├── data/              # Database and vector store management
│   └── utils/             # Configuration and utilities
├── web/                   # Streamlit web interface
├── templates/             # Jinja2 document templates
├── config/                # Configuration files
└── tests/                 # Test suite
```

### Key Technologies

- **AI/ML**: Google Gemini 2.5 Pro, Perplexity API, Sentence-Transformers
- **Data**: SQLite, ChromaDB for vector storage
- **Web**: Streamlit for user interface
- **CLI**: Typer for command-line interface
- **Cloud**: Docker, Google Cloud Run
- **Testing**: pytest, GitHub Actions

## 🎨 Document Themes

### Resume Themes
1. **Professional Classic** - Traditional, ATS-friendly design
2. **Modern Minimalist** - Clean, contemporary layout
3. **Contemporary Professional** - Balanced modern design
4. **Bold Executive** - Executive-level presentation
5. **Vibrant Creative** - Creative industry focus

### Template Types
- **Resumes** - Multiple themes with intelligent content optimization
- **Cover Letters** - Professional templates with company research integration  
- **Key Selection Criteria** - Australian government compliance with STAR method

## 🔧 Development

### Setup Development Environment

```bash
# Install development dependencies
make install-dev

# Set up pre-commit hooks
pre-commit install

# Run tests
make test

# Format code
make format

# Run linting
make lint
```

### Code Quality

The project maintains high code quality standards:

- **Black** for code formatting
- **isort** for import sorting  
- **flake8** for linting
- **mypy** for type checking
- **bandit** for security scanning
- **pytest** for testing

### Testing

```bash
# Run full test suite
make test

# Run specific test categories
pytest tests/unit/          # Unit tests
pytest tests/integration/   # Integration tests

# Run with coverage
pytest --cov=src --cov-report=html
```

## 🐳 Docker Deployment

### Local Docker

```bash
# Build image
make docker-build

# Run container
make docker-run

# Or use docker-compose
docker-compose up -d
```

### Google Cloud Run

```bash
# Deploy to Cloud Run
make deploy-cloud-run

# Requires GOOGLE_CLOUD_PROJECT environment variable
export GOOGLE_CLOUD_PROJECT=your-project-id
```

## 📁 Configuration

### Environment Variables

Key configuration options in `.env`:

```bash
# Required API Keys
GOOGLE_GEMINI_API_KEY=your_gemini_api_key
PERPLEXITY_API_KEY=your_perplexity_api_key

# Application Settings  
DEBUG=false
LOG_LEVEL=INFO
DATABASE_URL=sqlite:///~/.resume_agent/data.sqlite

# Document Generation
MAX_RESUME_PAGES=2
DEFAULT_THEME=professional_classic
```

### YAML Configuration

Additional settings in `config/app.yaml`:

- Theme configurations
- API model parameters
- Security settings  
- Feature toggles

## 🔒 Security & Privacy

### Data Protection
- **Local Storage** - All personal data stored locally in SQLite
- **API Key Security** - Credentials managed via environment variables
- **No Data Sharing** - Personal information never shared with external services
- **Secure Communication** - HTTPS for all API communications

### Best Practices
- Regular security scanning with Bandit
- Dependency vulnerability checking with Safety
- Secure defaults in all configurations
- Minimal permission requirements

## 🆘 Troubleshooting

### Common Issues

**API Connection Errors:**
```bash
# Check API key configuration
python -m src.cli status

# Test API connections
python -c "from src.integrations.gemini_client import gemini_client; print('Gemini OK' if gemini_client else 'Gemini Error')"
```

**Database Issues:**
```bash
# Reset database
make reset-db

# Check database status
python -m src.cli status
```

**Installation Problems:**
```bash
# Clean install
make clean
make install

# Check Python version
python --version  # Should be 3.11+
```

### Log Files

Check logs for detailed error information:
- Development: Console output
- Production: `~/.resume_agent/logs/app.log`

## 🤝 Contributing

This is a personal-use project, but contributions are welcome:

1. Fork the repository
2. Create a feature branch
3. Make your changes with tests
4. Run the test suite
5. Submit a pull request

### Development Workflow

```bash
# Create feature branch
git checkout -b feature/new-feature

# Make changes and test
make ci-test

# Commit changes
git commit -m "Add new feature"

# Push and create PR
git push origin feature/new-feature
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Google Gemini** for advanced AI capabilities
- **Perplexity AI** for real-time web research
- **ChromaDB** for vector storage
- **Streamlit** for rapid web development
- **Open Source Community** for excellent Python tools

## 📞 Support

For issues and questions:
1. Check the [troubleshooting section](#-troubleshooting)
2. Review existing [issues](../../issues)
3. Create a new issue with detailed information

---

**Enhanced Resume Agent 3.0** - Empowering your career with AI-powered document generation.
'''

with open("README.md", "w") as f:
    f.write(readme_content)

print("✓ Created README.md")

# Create a gitignore file
gitignore_content = '''# Byte-compiled / optimized / DLL files
__pycache__/
*.py[cod]
*$py.class

# C extensions
*.so

# Distribution / packaging
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
pip-wheel-metadata/
share/python-wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# PyInstaller
*.manifest
*.spec

# Installer logs
pip-log.txt
pip-delete-this-directory.txt

# Unit test / coverage reports
htmlcov/
.tox/
.nox/
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover
*.py,cover
.hypothesis/
.pytest_cache/

# Translations
*.mo
*.pot

# Django stuff:
*.log
local_settings.py
db.sqlite3
db.sqlite3-journal

# Flask stuff:
instance/
.webassets-cache

# Scrapy stuff:
.scrapy

# Sphinx documentation
docs/_build/

# PyBuilder
target/

# Jupyter Notebook
.ipynb_checkpoints

# IPython
profile_default/
ipython_config.py

# pyenv
.python-version

# pipenv
Pipfile.lock

# PEP 582
__pypackages__/

# Celery stuff
celerybeat-schedule
celerybeat.pid

# SageMath parsed files
*.sage.py

# Environments
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# Spyder project settings
.spyderproject
.spyproject

# Rope project settings
.ropeproject

# mkdocs documentation
/site

# mypy
.mypy_cache/
.dmypy.json
dmypy.json

# Pyre type checker
.pyre/

# IDEs
.vscode/
.idea/
*.swp
*.swo
*~

# OS
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# Application specific
*.sqlite
*.sqlite3
data.db
*.db

# Resume Agent specific
.resume_agent/
vector_db/
exports/
research/
backups/

# Logs
*.log
logs/

# Temporary files
tmp/
temp/
.temp/

# Security
*.key
*.pem
*.p12

# Local configuration
local.yaml
local.yml

# Docker
.dockerignore

# Reports
bandit-report.json
safety-report.json
coverage-report/

# MLflow
mlruns/
mlartifacts/
'''

with open(".gitignore", "w") as f:
    f.write(gitignore_content)

print("✓ Created .gitignore")

# Create deployment script
deployment_script_content = '''#!/bin/bash

# Enhanced Resume Agent 3.0 - Cloud Run Deployment Script
# Usage: ./scripts/deploy_cloud_run.sh

set -e

echo "🚀 Enhanced Resume Agent 3.0 - Cloud Run Deployment"
echo "=================================================="

# Check requirements
if [ -z "$GOOGLE_CLOUD_PROJECT" ]; then
    echo "❌ GOOGLE_CLOUD_PROJECT environment variable not set"
    exit 1
fi

if ! command -v gcloud &> /dev/null; then
    echo "❌ Google Cloud SDK not installed"
    echo "Please install: https://cloud.google.com/sdk/docs/install"
    exit 1
fi

if ! command -v docker &> /dev/null; then
    echo "❌ Docker not installed"
    exit 1
fi

# Configuration
PROJECT_ID=$GOOGLE_CLOUD_PROJECT
SERVICE_NAME="enhanced-resume-agent"
REGION="us-central1"
IMAGE_NAME="gcr.io/$PROJECT_ID/$SERVICE_NAME"

echo "📋 Deployment Configuration:"
echo "   Project ID: $PROJECT_ID"
echo "   Service Name: $SERVICE_NAME"
echo "   Region: $REGION"
echo "   Image: $IMAGE_NAME"
echo ""

# Authenticate with Google Cloud
echo "🔐 Authenticating with Google Cloud..."
gcloud auth configure-docker --quiet

# Build and submit to Cloud Build
echo "🏗️  Building Docker image..."
gcloud builds submit --tag $IMAGE_NAME --timeout=600s

# Deploy to Cloud Run
echo "☁️  Deploying to Cloud Run..."
gcloud run deploy $SERVICE_NAME \\
    --image $IMAGE_NAME \\
    --platform managed \\
    --region $REGION \\
    --allow-unauthenticated \\
    --max-instances 1 \\
    --memory 1Gi \\
    --cpu 1 \\
    --timeout 3600 \\
    --set-env-vars="DATABASE_URL=sqlite:////tmp/data.sqlite,CHROMADB_PATH=/tmp/vector_db,LOG_LEVEL=INFO" \\
    --set-secrets="GOOGLE_GEMINI_API_KEY=gemini-api-key:latest,PERPLEXITY_API_KEY=perplexity-api-key:latest"

# Get service URL
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region=$REGION --format='value(status.url)')

echo ""
echo "✅ Deployment completed successfully!"
echo "🌐 Service URL: $SERVICE_URL"
echo ""
echo "📝 Next steps:"
echo "   1. Set up secrets in Google Secret Manager:"
echo "      gcloud secrets create gemini-api-key --data-file=<(echo 'YOUR_GEMINI_API_KEY')"
echo "      gcloud secrets create perplexity-api-key --data-file=<(echo 'YOUR_PERPLEXITY_API_KEY')"
echo "   2. Visit your application at: $SERVICE_URL"
echo "   3. Initialize your profile through the web interface"
echo ""
echo "🎉 Enhanced Resume Agent 3.0 is now live!"
'''

# Create scripts directory and add deployment script
import os
os.makedirs("scripts", exist_ok=True)
with open("scripts/deploy_cloud_run.sh", "w") as f:
    f.write(deployment_script_content)

# Make script executable
os.chmod("scripts/deploy_cloud_run.sh", 0o755)

print("✓ Created scripts/deploy_cloud_run.sh")

# Create a simple backup script
backup_script_content = '''#!/bin/bash

# Enhanced Resume Agent 3.0 - Backup Script
# Creates a backup of all user data

BACKUP_DIR="$HOME/.resume_agent_backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="resume_agent_backup_$TIMESTAMP.tar.gz"

echo "📦 Creating backup of Enhanced Resume Agent data..."

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Create backup
if [ -d "$HOME/.resume_agent" ]; then
    tar -czf "$BACKUP_DIR/$BACKUP_FILE" -C "$HOME" .resume_agent
    echo "✅ Backup created: $BACKUP_DIR/$BACKUP_FILE"
    
    # Show backup info
    BACKUP_SIZE=$(du -h "$BACKUP_DIR/$BACKUP_FILE" | cut -f1)
    echo "📊 Backup size: $BACKUP_SIZE"
    echo "📂 Location: $BACKUP_DIR/$BACKUP_FILE"
    
    # List contents
    echo ""
    echo "📋 Backup contents:"
    tar -tzf "$BACKUP_DIR/$BACKUP_FILE" | head -10
    if [ $(tar -tzf "$BACKUP_DIR/$BACKUP_FILE" | wc -l) -gt 10 ]; then
        echo "   ... and more"
    fi
    
else
    echo "❌ No Resume Agent data found at $HOME/.resume_agent"
    exit 1
fi
'''

with open("scripts/backup.sh", "w") as f:
    f.write(backup_script_content)

os.chmod("scripts/backup.sh", 0o755)

print("✓ Created scripts/backup.sh")