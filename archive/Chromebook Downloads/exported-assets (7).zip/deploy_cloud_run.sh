#!/bin/bash

# Enhanced Resume Agent 3.0 - Cloud Run Deployment Script
# Usage: ./scripts/deploy_cloud_run.sh

set -e

echo "🚀 Enhanced Resume Agent 3.0 - Cloud Run Deployment"
echo "=================================================="

# Check requirements
if [ -z "$GOOGLE_CLOUD_PROJECT" ]; then
    echo "❌ GOOGLE_CLOUD_PROJECT environment variable not set"
    exit 1
fi

if ! command -v gcloud &> /dev/null; then
    echo "❌ Google Cloud SDK not installed"
    echo "Please install: https://cloud.google.com/sdk/docs/install"
    exit 1
fi

if ! command -v docker &> /dev/null; then
    echo "❌ Docker not installed"
    exit 1
fi

# Configuration
PROJECT_ID=$GOOGLE_CLOUD_PROJECT
SERVICE_NAME="enhanced-resume-agent"
REGION="us-central1"
IMAGE_NAME="gcr.io/$PROJECT_ID/$SERVICE_NAME"

echo "📋 Deployment Configuration:"
echo "   Project ID: $PROJECT_ID"
echo "   Service Name: $SERVICE_NAME"
echo "   Region: $REGION"
echo "   Image: $IMAGE_NAME"
echo ""

# Authenticate with Google Cloud
echo "🔐 Authenticating with Google Cloud..."
gcloud auth configure-docker --quiet

# Build and submit to Cloud Build
echo "🏗️  Building Docker image..."
gcloud builds submit --tag $IMAGE_NAME --timeout=600s

# Deploy to Cloud Run
echo "☁️  Deploying to Cloud Run..."
gcloud run deploy $SERVICE_NAME \
    --image $IMAGE_NAME \
    --platform managed \
    --region $REGION \
    --allow-unauthenticated \
    --max-instances 1 \
    --memory 1Gi \
    --cpu 1 \
    --timeout 3600 \
    --set-env-vars="DATABASE_URL=sqlite:////tmp/data.sqlite,CHROMADB_PATH=/tmp/vector_db,LOG_LEVEL=INFO" \
    --set-secrets="GOOGLE_GEMINI_API_KEY=gemini-api-key:latest,PERPLEXITY_API_KEY=perplexity-api-key:latest"

# Get service URL
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region=$REGION --format='value(status.url)')

echo ""
echo "✅ Deployment completed successfully!"
echo "🌐 Service URL: $SERVICE_URL"
echo ""
echo "📝 Next steps:"
echo "   1. Set up secrets in Google Secret Manager:"
echo "      gcloud secrets create gemini-api-key --data-file=<(echo 'YOUR_GEMINI_API_KEY')"
echo "      gcloud secrets create perplexity-api-key --data-file=<(echo 'YOUR_PERPLEXITY_API_KEY')"
echo "   2. Visit your application at: $SERVICE_URL"
echo "   3. Initialize your profile through the web interface"
echo ""
echo "🎉 Enhanced Resume Agent 3.0 is now live!"
