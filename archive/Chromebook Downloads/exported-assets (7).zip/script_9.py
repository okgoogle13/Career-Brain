# 10. Create the main CLI interface
cli_content = '''"""
Command Line Interface for Enhanced Resume Agent 3.0.
"""

import os
import sys
from pathlib import Path
from typing import Optional, List
import typer
import subprocess
import json

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from utils.config import config
from utils.logger import get_logger, setup_logging
from data.database import db_manager
from data.models import get_or_create_user
from data.experience_manager import experience_manager
from integrations.gemini_client import gemini_client
from integrations.perplexity_client import perplexity_client

# Initialize CLI app
app = typer.Typer(
    name="Enhanced Resume Agent",
    help="AI-powered career document generation system for personal use",
    no_args_is_help=True
)

# Setup logging
logger = get_logger(__name__)

@app.command()
def init(
    email: str = typer.Option(..., "--email", "-e", help="Your email address"),
    name: str = typer.Option(..., "--name", "-n", help="Your full name"),
    force: bool = typer.Option(False, "--force", "-f", help="Force reinitialize")
) -> None:
    """Initialize your profile and set up the system."""
    try:
        typer.echo("🚀 Initializing Enhanced Resume Agent 3.0...")
        
        # Validate configuration
        if not config.validate():
            typer.echo("❌ Configuration validation failed. Please check your .env file.", err=True)
            raise typer.Exit(1)
        
        # Initialize database
        with db_manager.get_session() as session:
            user = get_or_create_user(session, email, name)
            typer.echo(f"✅ User profile created/updated: {user.full_name} ({user.email})")
        
        # Test API connections
        if gemini_client:
            test_response = gemini_client.generate_content("Hello", max_tokens=10)
            if test_response:
                typer.echo("✅ Google Gemini API connection successful")
            else:
                typer.echo("⚠️  Google Gemini API connection failed")
        else:
            typer.echo("⚠️  Google Gemini API client not available")
        
        if perplexity_client:
            test_response = perplexity_client.chat_completion(
                [{"role": "user", "content": "Hello"}],
                max_tokens=10
            )
            if test_response:
                typer.echo("✅ Perplexity API connection successful")
            else:
                typer.echo("⚠️  Perplexity API connection failed")
        else:
            typer.echo("⚠️  Perplexity API client not available")
        
        # Create necessary directories
        data_dir = Path.home() / ".resume_agent"
        data_dir.mkdir(exist_ok=True)
        (data_dir / "exports").mkdir(exist_ok=True)
        (data_dir / "templates").mkdir(exist_ok=True)
        
        typer.echo(f"✅ Data directory created: {data_dir}")
        typer.echo("🎉 Initialization complete! You can now use the resume agent.")
        
    except Exception as e:
        logger.error(f"Initialization failed: {e}")
        typer.echo(f"❌ Initialization failed: {e}", err=True)
        raise typer.Exit(1)

@app.command()
def profile(
    update: bool = typer.Option(False, "--update", "-u", help="Update profile information"),
    show: bool = typer.Option(True, "--show", "-s", help="Show current profile")
) -> None:
    """Manage your profile information."""
    try:
        with db_manager.get_session() as session:
            # For single-user system, get the first user
            from data.models import User
            user = session.query(User).first()
            
            if not user:
                typer.echo("❌ No user profile found. Please run 'resume-agent init' first.")
                raise typer.Exit(1)
            
            if show:
                typer.echo("\\n👤 Current Profile:")
                typer.echo(f"   Name: {user.full_name}")
                typer.echo(f"   Email: {user.email}")
                typer.echo(f"   Phone: {user.phone or 'Not set'}")
                typer.echo(f"   LinkedIn: {user.linkedin_url or 'Not set'}")
                typer.echo(f"   GitHub: {user.github_url or 'Not set'}")
                typer.echo(f"   Location: {user.location or 'Not set'}")
                
                # Show experience counts
                experiences = experience_manager.get_user_experiences(user.id)
                typer.echo("\\n📊 Experience Summary:")
                typer.echo(f"   Work Experiences: {len(experiences.get('work_experiences', []))}")
                typer.echo(f"   Education: {len(experiences.get('educations', []))}")
                typer.echo(f"   Skills: {len(experiences.get('skills', []))}")
                typer.echo(f"   Projects: {len(experiences.get('projects', []))}")
            
            if update:
                typer.echo("\\n✏️  Update Profile (press Enter to keep current value):")
                
                new_name = typer.prompt(f"Full name ({user.full_name})", default=user.full_name)
                new_phone = typer.prompt(f"Phone ({user.phone or 'Not set'})", default=user.phone or "")
                new_linkedin = typer.prompt(f"LinkedIn URL ({user.linkedin_url or 'Not set'})", default=user.linkedin_url or "")
                new_github = typer.prompt(f"GitHub URL ({user.github_url or 'Not set'})", default=user.github_url or "")
                new_location = typer.prompt(f"Location ({user.location or 'Not set'})", default=user.location or "")
                
                # Update user
                user.full_name = new_name
                user.phone = new_phone if new_phone else None
                user.linkedin_url = new_linkedin if new_linkedin else None
                user.github_url = new_github if new_github else None
                user.location = new_location if new_location else None
                
                session.commit()
                typer.echo("✅ Profile updated successfully!")
                
    except Exception as e:
        logger.error(f"Profile management failed: {e}")
        typer.echo(f"❌ Profile management failed: {e}", err=True)
        raise typer.Exit(1)

@app.command()
def experience(
    action: str = typer.Argument(..., help="Action: add, list, update, delete"),
    experience_id: Optional[int] = typer.Option(None, "--id", help="Experience ID for update/delete")
) -> None:
    """Manage work experiences."""
    try:
        with db_manager.get_session() as session:
            from data.models import User
            user = session.query(User).first()
            
            if not user:
                typer.echo("❌ No user profile found. Please run 'resume-agent init' first.")
                raise typer.Exit(1)
            
            if action == "list":
                experiences = experience_manager.get_user_experiences(user.id)
                work_exps = experiences.get('work_experiences', [])
                
                if not work_exps:
                    typer.echo("📝 No work experiences found.")
                    return
                
                typer.echo("\\n💼 Work Experiences:")
                for exp in work_exps:
                    end_date = exp['end_date'] or 'Present'
                    typer.echo(f"   [{exp['id']}] {exp['job_title']} at {exp['company_name']}")
                    typer.echo(f"       {exp['start_date']} - {end_date}")
                    if exp['location']:
                        typer.echo(f"       📍 {exp['location']}")
                    typer.echo()
            
            elif action == "add":
                typer.echo("\\n➕ Add New Work Experience:")
                
                job_title = typer.prompt("Job title")
                company_name = typer.prompt("Company name")
                start_date = typer.prompt("Start date (YYYY-MM or YYYY)")
                end_date = typer.prompt("End date (YYYY-MM, YYYY, or 'Present')", default="Present")
                location = typer.prompt("Location", default="")
                description = typer.prompt("Job description/responsibilities", default="")
                
                is_current = end_date.lower() == "present"
                
                exp_id = experience_manager.add_work_experience(
                    user_id=user.id,
                    company_name=company_name,
                    job_title=job_title,
                    start_date=start_date,
                    end_date=None if is_current else end_date,
                    location=location if location else None,
                    description=description if description else None,
                    is_current=is_current
                )
                
                if exp_id:
                    typer.echo(f"✅ Work experience added successfully! (ID: {exp_id})")
                else:
                    typer.echo("❌ Failed to add work experience.")
            
            else:
                typer.echo(f"❌ Unknown action: {action}. Use: add, list, update, delete")
                
    except Exception as e:
        logger.error(f"Experience management failed: {e}")
        typer.echo(f"❌ Experience management failed: {e}", err=True)
        raise typer.Exit(1)

@app.command()
def research(
    company: str = typer.Argument(..., help="Company name to research"),
    save: bool = typer.Option(True, "--save", help="Save research results"),
    show: bool = typer.Option(True, "--show", help="Display research results")
) -> None:
    """Research a company using Perplexity API."""
    try:
        if not perplexity_client:
            typer.echo("❌ Perplexity API client not available. Check your API key.")
            raise typer.Exit(1)
        
        typer.echo(f"🔍 Researching {company}...")
        
        research_data = perplexity_client.research_company(company)
        
        if not research_data:
            typer.echo("❌ Failed to research company.")
            raise typer.Exit(1)
        
        if show:
            typer.echo(f"\\n🏢 Research Results for {company}:")
            typer.echo("=" * 50)
            typer.echo(research_data['research_content'])
            typer.echo("=" * 50)
        
        if save:
            # Save to file
            data_dir = Path.home() / ".resume_agent" / "research"
            data_dir.mkdir(exist_ok=True)
            
            filename = f"{company.replace(' ', '_').lower()}_research.json"
            filepath = data_dir / filename
            
            with open(filepath, 'w') as f:
                json.dump(research_data, f, indent=2)
            
            typer.echo(f"✅ Research saved to: {filepath}")
        
    except Exception as e:
        logger.error(f"Company research failed: {e}")
        typer.echo(f"❌ Company research failed: {e}", err=True)
        raise typer.Exit(1)

@app.command()
def web() -> None:
    """Launch the Streamlit web interface."""
    try:
        typer.echo("🌐 Launching web interface...")
        
        # Get the web app path
        web_app_path = Path(__file__).parent.parent / "web" / "streamlit_app.py"
        
        if not web_app_path.exists():
            typer.echo(f"❌ Web app not found at: {web_app_path}")
            raise typer.Exit(1)
        
        # Launch Streamlit
        cmd = [
            sys.executable, "-m", "streamlit", "run",
            str(web_app_path),
            "--server.port", str(config.streamlit.port),
            "--server.address", config.streamlit.host,
            "--browser.gatherUsageStats", "false"
        ]
        
        typer.echo(f"🚀 Starting web interface at http://{config.streamlit.host}:{config.streamlit.port}")
        subprocess.run(cmd)
        
    except KeyboardInterrupt:
        typer.echo("\\n👋 Web interface stopped.")
    except Exception as e:
        logger.error(f"Failed to launch web interface: {e}")
        typer.echo(f"❌ Failed to launch web interface: {e}", err=True)
        raise typer.Exit(1)

@app.command()
def status() -> None:
    """Show system status and configuration."""
    try:
        typer.echo("📊 Enhanced Resume Agent 3.0 Status:")
        typer.echo("=" * 40)
        
        # Configuration status
        typer.echo("🔧 Configuration:")
        typer.echo(f"   Debug mode: {config.app.debug}")
        typer.echo(f"   Log level: {config.app.log_level}")
        typer.echo(f"   Database: {config.database.url[:50]}...")
        
        # API status
        typer.echo("\\n🔌 API Connections:")
        typer.echo(f"   Gemini API: {'✅ Ready' if gemini_client else '❌ Not configured'}")
        typer.echo(f"   Perplexity API: {'✅ Ready' if perplexity_client else '❌ Not configured'}")
        
        # Database status
        try:
            with db_manager.get_session() as session:
                from data.models import User
                user_count = session.query(User).count()
                typer.echo(f"\\n💾 Database Status:")
                typer.echo(f"   Users: {user_count}")
                typer.echo("   Connection: ✅ Active")
        except Exception as e:
            typer.echo(f"\\n💾 Database Status:")
            typer.echo(f"   Connection: ❌ Failed ({e})")
        
        # Vector store status
        try:
            from data.vector_store import vector_store
            stats = vector_store.get_collection_stats()
            typer.echo(f"\\n🔍 Vector Store:")
            typer.echo(f"   Experiences: {stats['experiences']}")
            typer.echo(f"   Job descriptions: {stats['job_descriptions']}")
            typer.echo(f"   Total entries: {stats['total']}")
        except Exception as e:
            typer.echo(f"\\n🔍 Vector Store:")
            typer.echo(f"   Status: ❌ Failed ({e})")
        
    except Exception as e:
        logger.error(f"Status check failed: {e}")
        typer.echo(f"❌ Status check failed: {e}", err=True)
        raise typer.Exit(1)

@app.command()
def version() -> None:
    """Show version information."""
    typer.echo(f"Enhanced Resume Agent {config.app.version}")
    typer.echo("AI-powered career document generation system")

if __name__ == "__main__":
    app()
'''

with open("src/cli.py", "w") as f:
    f.write(cli_content)

print("✓ Created src/cli.py")