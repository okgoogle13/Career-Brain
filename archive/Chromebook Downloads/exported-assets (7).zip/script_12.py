# 13. Create Makefile for automation
makefile_content = '''# Enhanced Resume Agent 3.0 - Makefile
# Automation commands for development and deployment

.PHONY: help install install-dev clean test lint format type-check security run-cli run-web docker-build docker-run deploy-cloud-run ci-test

# Default target
help:
\t@echo "Enhanced Resume Agent 3.0 - Available Commands:"
\t@echo "  install        Install production dependencies"
\t@echo "  install-dev    Install development dependencies"
\t@echo "  clean          Clean cache and temporary files"
\t@echo "  test           Run test suite"
\t@echo "  lint           Run linting checks"
\t@echo "  format         Format code with black and isort"
\t@echo "  type-check     Run mypy type checking"
\t@echo "  security       Run security checks"
\t@echo "  run-cli        Run CLI interface"
\t@echo "  run-web        Run Streamlit web interface"
\t@echo "  docker-build   Build Docker image"
\t@echo "  docker-run     Run application in Docker"
\t@echo "  deploy-cloud-run Deploy to Google Cloud Run"
\t@echo "  ci-test        Run full CI test suite"

# Installation
install:
\t@echo "📦 Installing production dependencies..."
\tpip install -r requirements.txt

install-dev:
\t@echo "📦 Installing development dependencies..."
\tpip install -r requirements.txt
\tpip install pytest pytest-cov black isort flake8 mypy bandit safety pre-commit
\tpre-commit install

# Cleanup
clean:
\t@echo "🧹 Cleaning cache and temporary files..."
\tfind . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
\tfind . -type f -name "*.pyc" -delete
\tfind . -type f -name "*.pyo" -delete
\tfind . -type f -name "*.pyd" -delete
\tfind . -type f -name ".coverage" -delete
\tfind . -type d -name "*.egg-info" -exec rm -rf {} + 2>/dev/null || true
\tfind . -type d -name ".pytest_cache" -exec rm -rf {} + 2>/dev/null || true
\tfind . -type d -name ".mypy_cache" -exec rm -rf {} + 2>/dev/null || true

# Testing
test:
\t@echo "🧪 Running test suite..."
\tpytest tests/ -v --cov=src --cov-report=term-missing

# Code Quality
lint:
\t@echo "🔍 Running linting checks..."
\tflake8 src/ web/ tests/ --max-line-length=88 --exclude=__pycache__
\t@echo "✅ Linting passed"

format:
\t@echo "🎨 Formatting code..."
\tblack src/ web/ tests/ --line-length=88
\tisort src/ web/ tests/ --profile=black
\t@echo "✅ Code formatted"

type-check:
\t@echo "🔍 Running type checks..."
\tmypy src/ --ignore-missing-imports
\t@echo "✅ Type checking passed"

security:
\t@echo "🔒 Running security checks..."
\tbandit -r src/ -f json -o bandit-report.json || true
\tsafety check --json --output=safety-report.json || true
\t@echo "✅ Security checks completed"

# Running
run-cli:
\t@echo "🖥️  Starting CLI interface..."
\tpython -m src.cli

run-web:
\t@echo "🌐 Starting web interface..."
\tstreamlit run web/streamlit_app.py --server.port=8501 --server.address=localhost --browser.gatherUsageStats=false

# Docker
docker-build:
\t@echo "🐳 Building Docker image..."
\tdocker build -t enhanced-resume-agent:latest .

docker-run:
\t@echo "🐳 Running Docker container..."
\tdocker run -p 8501:8501 --env-file .env enhanced-resume-agent:latest

docker-compose-up:
\t@echo "🐳 Starting services with docker-compose..."
\tdocker-compose up -d

docker-compose-down:
\t@echo "🐳 Stopping services..."
\tdocker-compose down

# Cloud Deployment
deploy-cloud-run:
\t@echo "☁️  Deploying to Google Cloud Run..."
\t@if [ -z "$$GOOGLE_CLOUD_PROJECT" ]; then echo "❌ GOOGLE_CLOUD_PROJECT not set"; exit 1; fi
\tgcloud builds submit --tag gcr.io/$$GOOGLE_CLOUD_PROJECT/enhanced-resume-agent
\tgcloud run deploy enhanced-resume-agent \\
\t\t--image gcr.io/$$GOOGLE_CLOUD_PROJECT/enhanced-resume-agent \\
\t\t--platform managed \\
\t\t--region us-central1 \\
\t\t--allow-unauthenticated \\
\t\t--max-instances 1 \\
\t\t--memory 1Gi \\
\t\t--cpu 1 \\
\t\t--timeout 3600 \\
\t\t--set-env-vars="DATABASE_URL=sqlite:////tmp/data.sqlite,CHROMADB_PATH=/tmp/vector_db"

# CI/CD
ci-test:
\t@echo "🚀 Running full CI test suite..."
\tmake lint
\tmake type-check
\tmake test
\tmake security
\t@echo "✅ All CI checks passed"

# Development helpers
dev-setup:
\t@echo "🛠️  Setting up development environment..."
\tmake install-dev
\tcp .env.example .env
\t@echo "📝 Please edit .env file with your API keys"
\t@echo "✅ Development environment ready"

reset-db:
\t@echo "🗄️  Resetting database..."
\trm -f ~/.resume_agent/data.sqlite
\t@echo "✅ Database reset"

reset-vector-store:
\t@echo "🔍 Resetting vector store..."
\trm -rf ~/.resume_agent/vector_db
\t@echo "✅ Vector store reset"

# Backup and restore
backup:
\t@echo "💾 Creating backup..."
\tmkdir -p backups
\ttar -czf backups/resume-agent-backup-$(shell date +%Y%m%d_%H%M%S).tar.gz ~/.resume_agent/
\t@echo "✅ Backup created in backups/"

# Show system status
status:
\t@echo "📊 System Status:"
\tpython -c "import sys; print(f'Python: {sys.version}')"
\t@command -v docker >/dev/null 2>&1 && echo "Docker: ✅ Available" || echo "Docker: ❌ Not found"
\t@command -v gcloud >/dev/null 2>&1 && echo "Google Cloud SDK: ✅ Available" || echo "Google Cloud SDK: ❌ Not found"
\t@test -f .env && echo ".env file: ✅ Found" || echo ".env file: ❌ Not found"
'''

with open("Makefile", "w") as f:
    f.write(makefile_content)

print("✓ Created Makefile")

# Create pre-commit configuration
precommit_content = '''# Pre-commit hooks configuration
repos:
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.5.0
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
      - id: check-yaml
      - id: check-added-large-files
      - id: check-merge-conflict
      - id: debug-statements
      - id: check-docstring-first

  - repo: https://github.com/psf/black
    rev: 23.11.0
    hooks:
      - id: black
        language_version: python3.11
        args: [--line-length=88]

  - repo: https://github.com/pycqa/isort
    rev: 5.12.0
    hooks:
      - id: isort
        args: [--profile=black, --line-length=88]

  - repo: https://github.com/pycqa/flake8
    rev: 6.1.0
    hooks:
      - id: flake8
        args: [--max-line-length=88, --extend-ignore=E203,W503]

  - repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.7.1
    hooks:
      - id: mypy
        additional_dependencies: [types-all]
        args: [--ignore-missing-imports]

  - repo: https://github.com/PyCQA/bandit
    rev: 1.7.5
    hooks:
      - id: bandit
        args: [-x, tests/]
'''

with open(".pre-commit-config.yaml", "w") as f:
    f.write(precommit_content)

print("✓ Created .pre-commit-config.yaml")