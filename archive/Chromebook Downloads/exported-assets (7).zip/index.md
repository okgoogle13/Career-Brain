# Enhanced Resume Agent 3.0 Documentation

Welcome to the comprehensive documentation for Enhanced Resume Agent 3.0, an AI-powered career document generation system.

## 📚 Documentation Sections

### Getting Started
- [Installation Guide](installation.md)
- [Quick Start Tutorial](quickstart.md)
- [Configuration Setup](configuration.md)

### User Guides
- [Web Interface Guide](web-interface.md)
- [CLI Reference](cli-reference.md)
- [Template Customization](templates.md)

### Technical Documentation
- [Architecture Overview](architecture.md)
- [API Integration](api-integration.md)
- [Database Schema](database.md)
- [Vector Store Management](vector-store.md)

### Development
- [Development Setup](development.md)
- [Contributing Guidelines](contributing.md)
- [Testing Guide](testing.md)
- [Deployment Guide](deployment.md)

### Advanced Topics
- [ATS Optimization](ats-optimization.md)
- [Regional Compliance](regional-compliance.md)
- [Security & Privacy](security.md)
- [Performance Tuning](performance.md)

## 🚀 Quick Links

- **[📖 User Manual](user-manual.md)** - Complete user guide
- **[🔧 API Reference](api-reference.md)** - Technical API documentation
- **[❓ FAQ](faq.md)** - Frequently asked questions
- **[🐛 Troubleshooting](troubleshooting.md)** - Common issues and solutions

## 📞 Support

Need help? Check out our support resources:

1. **Documentation** - Start with this documentation
2. **Issues** - Check existing GitHub issues
3. **Community** - Join our community discussions

## 🎯 Key Features

Enhanced Resume Agent 3.0 provides:

- **AI-Powered Optimization** using Google Gemini 2.5 Pro
- **Company Research** via Perplexity API  
- **ATS-Compatible Templates** for maximum compatibility
- **Multi-Format Generation** (Resume, Cover Letter, KSC)
- **Personal Data Management** with local storage
- **Professional Themes** for different industries

---

*Enhanced Resume Agent 3.0 - Empowering your career with AI*
