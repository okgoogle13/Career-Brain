"""
Vector store management for Enhanced Resume Agent 3.0.
"""

import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
import numpy as np

from ..utils.config import config

logger = logging.getLogger(__name__)

class VectorStoreManager:
    """Manage vector storage for resume experience and job matching."""

    def __init__(self, persist_directory: str = None):
        """Initialize vector store manager."""
        self.persist_directory = persist_directory or Path(config.vector_store.chromadb_path).expanduser()
        self.persist_directory = Path(self.persist_directory)
        self.persist_directory.mkdir(parents=True, exist_ok=True)

        # Initialize ChromaDB client
        self.client = chromadb.PersistentClient(
            path=str(self.persist_directory),
            settings=Settings(
                anonymized_telemetry=False,
                allow_reset=True
            )
        )

        # Initialize embedding model
        self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

        # Get or create collections
        self.experience_collection = self._get_or_create_collection("user_experiences")
        self.job_collection = self._get_or_create_collection("job_descriptions")

        logger.info(f"Vector store initialized at {self.persist_directory}")

    def _get_or_create_collection(self, name: str):
        """Get or create a ChromaDB collection."""
        try:
            return self.client.get_collection(name)
        except Exception:
            return self.client.create_collection(
                name=name,
                metadata={"hnsw:space": "cosine"}
            )

    def add_experience(
        self,
        experience_id: str,
        text: str,
        metadata: Dict[str, Any] = None
    ) -> bool:
        """Add user experience to vector store."""
        try:
            # Generate embedding
            embedding = self.embedding_model.encode(text).tolist()

            # Add to collection
            self.experience_collection.add(
                embeddings=[embedding],
                documents=[text],
                metadatas=[metadata or {}],
                ids=[experience_id]
            )

            logger.debug(f"Added experience {experience_id} to vector store")
            return True

        except Exception as e:
            logger.error(f"Error adding experience to vector store: {e}")
            return False

    def add_job_description(
        self,
        job_id: str,
        job_description: str,
        metadata: Dict[str, Any] = None
    ) -> bool:
        """Add job description to vector store."""
        try:
            # Generate embedding
            embedding = self.embedding_model.encode(job_description).tolist()

            # Add to collection
            self.job_collection.add(
                embeddings=[embedding],
                documents=[job_description],
                metadatas=[metadata or {}],
                ids=[job_id]
            )

            logger.debug(f"Added job description {job_id} to vector store")
            return True

        except Exception as e:
            logger.error(f"Error adding job description to vector store: {e}")
            return False

    def find_relevant_experiences(
        self,
        job_description: str,
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        """Find relevant experiences for a job description."""
        try:
            # Generate embedding for job description
            query_embedding = self.embedding_model.encode(job_description).tolist()

            # Search for similar experiences
            results = self.experience_collection.query(
                query_embeddings=[query_embedding],
                n_results=top_k,
                include=["documents", "metadatas", "distances"]
            )

            # Format results
            relevant_experiences = []
            if results['ids'] and results['ids'][0]:
                for i, exp_id in enumerate(results['ids'][0]):
                    relevant_experiences.append({
                        'id': exp_id,
                        'text': results['documents'][0][i],
                        'metadata': results['metadatas'][0][i],
                        'similarity_score': 1 - results['distances'][0][i]  # Convert distance to similarity
                    })

            return relevant_experiences

        except Exception as e:
            logger.error(f"Error finding relevant experiences: {e}")
            return []

    def find_similar_jobs(
        self,
        target_job: str,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """Find similar job descriptions."""
        try:
            # Generate embedding for target job
            query_embedding = self.embedding_model.encode(target_job).tolist()

            # Search for similar jobs
            results = self.job_collection.query(
                query_embeddings=[query_embedding],
                n_results=top_k,
                include=["documents", "metadatas", "distances"]
            )

            # Format results
            similar_jobs = []
            if results['ids'] and results['ids'][0]:
                for i, job_id in enumerate(results['ids'][0]):
                    similar_jobs.append({
                        'id': job_id,
                        'text': results['documents'][0][i],
                        'metadata': results['metadatas'][0][i],
                        'similarity_score': 1 - results['distances'][0][i]
                    })

            return similar_jobs

        except Exception as e:
            logger.error(f"Error finding similar jobs: {e}")
            return []

    def update_experience(
        self,
        experience_id: str,
        text: str,
        metadata: Dict[str, Any] = None
    ) -> bool:
        """Update an existing experience in the vector store."""
        try:
            # Delete existing
            self.experience_collection.delete(ids=[experience_id])

            # Add updated version
            return self.add_experience(experience_id, text, metadata)

        except Exception as e:
            logger.error(f"Error updating experience: {e}")
            return False

    def delete_experience(self, experience_id: str) -> bool:
        """Delete an experience from the vector store."""
        try:
            self.experience_collection.delete(ids=[experience_id])
            logger.debug(f"Deleted experience {experience_id} from vector store")
            return True

        except Exception as e:
            logger.error(f"Error deleting experience: {e}")
            return False

    def get_collection_stats(self) -> Dict[str, int]:
        """Get statistics about the vector store collections."""
        try:
            exp_count = self.experience_collection.count()
            job_count = self.job_collection.count()

            return {
                'experiences': exp_count,
                'job_descriptions': job_count,
                'total': exp_count + job_count
            }

        except Exception as e:
            logger.error(f"Error getting collection stats: {e}")
            return {'experiences': 0, 'job_descriptions': 0, 'total': 0}

    def reset_collections(self) -> bool:
        """Reset all collections (delete all data)."""
        try:
            self.client.delete_collection("user_experiences")
            self.client.delete_collection("job_descriptions")

            # Recreate collections
            self.experience_collection = self._get_or_create_collection("user_experiences")
            self.job_collection = self._get_or_create_collection("job_descriptions")

            logger.info("Vector store collections reset")
            return True

        except Exception as e:
            logger.error(f"Error resetting collections: {e}")
            return False

# Global vector store manager instance
vector_store = VectorStoreManager()
