"""
Validation utilities for Enhanced Resume Agent 3.0.
"""

import re
from typing import Optional
from urllib.parse import urlparse

def validate_email(email: str) -> bool:
    """Validate email address format."""
    if not email or not isinstance(email, str):
        return False

    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_phone(phone: str) -> bool:
    """Validate phone number format."""
    if not phone or not isinstance(phone, str):
        return False

    # Remove common separators
    cleaned = re.sub(r'[\s\-\(\)\+]', '', phone)

    # Check if it's all digits and reasonable length
    return cleaned.isdigit() and 7 <= len(cleaned) <= 15

def validate_url(url: str) -> bool:
    """Validate URL format."""
    if not url or not isinstance(url, str):
        return False

    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except Exception:
        return False

def validate_linkedin_url(url: str) -> bool:
    """Validate LinkedIn URL format."""
    if not validate_url(url):
        return False

    return 'linkedin.com' in url.lower()

def validate_github_url(url: str) -> bool:
    """Validate GitHub URL format."""
    if not validate_url(url):
        return False

    return 'github.com' in url.lower()

def validate_name(name: str) -> bool:
    """Validate name format."""
    if not name or not isinstance(name, str):
        return False

    # Name should contain only letters, spaces, hyphens, and apostrophes
    pattern = r"^[a-zA-Z\s\-\']+$"
    return re.match(pattern, name.strip()) is not None and len(name.strip()) >= 2

def validate_job_title(title: str) -> bool:
    """Validate job title format."""
    if not title or not isinstance(title, str):
        return False

    # Job title should be reasonable length and contain valid characters
    cleaned = title.strip()
    return 2 <= len(cleaned) <= 100 and not cleaned.isdigit()

def validate_company_name(company: str) -> bool:
    """Validate company name format."""
    if not company or not isinstance(company, str):
        return False

    # Company name should be reasonable length
    cleaned = company.strip()
    return 1 <= len(cleaned) <= 100

def validate_date_range(start_date: str, end_date: Optional[str] = None) -> bool:
    """Validate date range format (YYYY-MM or YYYY)."""
    date_pattern = r'^\d{4}(-\d{2})?$'

    if not re.match(date_pattern, start_date):
        return False

    if end_date and end_date.lower() != 'present':
        if not re.match(date_pattern, end_date):
            return False

        # Basic date comparison (simplified)
        start_year = int(start_date[:4])
        end_year = int(end_date[:4])

        if end_year < start_year:
            return False

    return True
