"""
Experience management for Enhanced Resume Agent 3.0.
"""

import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime

from .database import db_manager
from .models import User, WorkExperience, Education, Skill, Project
from .vector_store import vector_store
from ..utils.file_handlers import DocumentProcessor

logger = logging.getLogger(__name__)

class ExperienceManager:
    """Manage user experiences and integrate with vector store."""

    def __init__(self):
        """Initialize experience manager."""
        self.db = db_manager
        self.vector_store = vector_store
        self.doc_processor = DocumentProcessor()

    def add_work_experience(
        self,
        user_id: int,
        company_name: str,
        job_title: str,
        start_date: str,
        end_date: str = None,
        location: str = None,
        description: str = None,
        achievements: List[str] = None,
        technologies: List[str] = None,
        is_current: bool = False
    ) -> Optional[int]:
        """Add work experience and update vector store."""
        try:
            with self.db.get_session() as session:
                # Create work experience record
                work_exp = WorkExperience(
                    user_id=user_id,
                    company_name=company_name,
                    job_title=job_title,
                    start_date=start_date,
                    end_date=end_date or "Present" if is_current else end_date,
                    location=location,
                    description=description,
                    achievements=achievements or [],
                    technologies=technologies or [],
                    is_current=is_current
                )

                session.add(work_exp)
                session.commit()
                session.refresh(work_exp)

                # Add to vector store
                self._add_experience_to_vector_store(work_exp)

                logger.info(f"Added work experience: {job_title} at {company_name}")
                return work_exp.id

        except Exception as e:
            logger.error(f"Error adding work experience: {e}")
            return None

    def update_work_experience(
        self,
        experience_id: int,
        **kwargs
    ) -> bool:
        """Update work experience and vector store."""
        try:
            with self.db.get_session() as session:
                work_exp = session.query(WorkExperience).filter(
                    WorkExperience.id == experience_id
                ).first()

                if not work_exp:
                    logger.error(f"Work experience {experience_id} not found")
                    return False

                # Update fields
                for key, value in kwargs.items():
                    if hasattr(work_exp, key):
                        setattr(work_exp, key, value)

                session.commit()
                session.refresh(work_exp)

                # Update vector store
                self._update_experience_in_vector_store(work_exp)

                logger.info(f"Updated work experience {experience_id}")
                return True

        except Exception as e:
            logger.error(f"Error updating work experience: {e}")
            return False

    def delete_work_experience(self, experience_id: int) -> bool:
        """Delete work experience and remove from vector store."""
        try:
            with self.db.get_session() as session:
                work_exp = session.query(WorkExperience).filter(
                    WorkExperience.id == experience_id
                ).first()

                if not work_exp:
                    logger.error(f"Work experience {experience_id} not found")
                    return False

                # Remove from vector store
                self.vector_store.delete_experience(f"work_{experience_id}")

                # Delete from database
                session.delete(work_exp)
                session.commit()

                logger.info(f"Deleted work experience {experience_id}")
                return True

        except Exception as e:
            logger.error(f"Error deleting work experience: {e}")
            return False

    def get_user_experiences(self, user_id: int) -> Dict[str, List[Dict]]:
        """Get all user experiences."""
        try:
            with self.db.get_session() as session:
                user = session.query(User).filter(User.id == user_id).first()

                if not user:
                    return {}

                experiences = {
                    'work_experiences': [self._work_exp_to_dict(exp) for exp in user.work_experiences],
                    'educations': [self._education_to_dict(exp) for exp in user.educations],
                    'skills': [self._skill_to_dict(exp) for exp in user.skills],
                    'projects': [self._project_to_dict(exp) for exp in user.projects]
                }

                return experiences

        except Exception as e:
            logger.error(f"Error getting user experiences: {e}")
            return {}

    def find_relevant_experiences_for_job(
        self,
        user_id: int,
        job_description: str,
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        """Find user experiences relevant to a job description."""
        try:
            # Get relevant experiences from vector store
            relevant_experiences = self.vector_store.find_relevant_experiences(
                job_description, top_k
            )

            # Filter to user's experiences and add database details
            user_relevant = []
            with self.db.get_session() as session:
                for exp in relevant_experiences:
                    if exp['id'].startswith(f'work_{user_id}_'):
                        # Extract work experience ID
                        work_id = int(exp['id'].split('_')[-1])
                        work_exp = session.query(WorkExperience).filter(
                            WorkExperience.id == work_id
                        ).first()

                        if work_exp:
                            exp_dict = self._work_exp_to_dict(work_exp)
                            exp_dict['similarity_score'] = exp['similarity_score']
                            user_relevant.append(exp_dict)

            return user_relevant

        except Exception as e:
            logger.error(f"Error finding relevant experiences: {e}")
            return []

    def _add_experience_to_vector_store(self, work_exp: WorkExperience):
        """Add work experience to vector store."""
        try:
            # Create text representation
            text_parts = [
                f"Job Title: {work_exp.job_title}",
                f"Company: {work_exp.company_name}",
            ]

            if work_exp.description:
                text_parts.append(f"Description: {work_exp.description}")

            if work_exp.achievements:
                text_parts.append(f"Achievements: {'; '.join(work_exp.achievements)}")

            if work_exp.technologies:
                text_parts.append(f"Technologies: {', '.join(work_exp.technologies)}")

            experience_text = "\n".join(text_parts)

            # Create metadata
            metadata = {
                'type': 'work_experience',
                'user_id': work_exp.user_id,
                'company': work_exp.company_name,
                'job_title': work_exp.job_title,
                'start_date': work_exp.start_date,
                'end_date': work_exp.end_date,
                'is_current': work_exp.is_current
            }

            # Add to vector store
            experience_id = f"work_{work_exp.user_id}_{work_exp.id}"
            self.vector_store.add_experience(experience_id, experience_text, metadata)

        except Exception as e:
            logger.error(f"Error adding experience to vector store: {e}")

    def _update_experience_in_vector_store(self, work_exp: WorkExperience):
        """Update work experience in vector store."""
        try:
            experience_id = f"work_{work_exp.user_id}_{work_exp.id}"

            # Create updated text representation
            text_parts = [
                f"Job Title: {work_exp.job_title}",
                f"Company: {work_exp.company_name}",
            ]

            if work_exp.description:
                text_parts.append(f"Description: {work_exp.description}")

            if work_exp.achievements:
                text_parts.append(f"Achievements: {'; '.join(work_exp.achievements)}")

            if work_exp.technologies:
                text_parts.append(f"Technologies: {', '.join(work_exp.technologies)}")

            experience_text = "\n".join(text_parts)

            # Create metadata
            metadata = {
                'type': 'work_experience',
                'user_id': work_exp.user_id,
                'company': work_exp.company_name,
                'job_title': work_exp.job_title,
                'start_date': work_exp.start_date,
                'end_date': work_exp.end_date,
                'is_current': work_exp.is_current
            }

            # Update in vector store
            self.vector_store.update_experience(experience_id, experience_text, metadata)

        except Exception as e:
            logger.error(f"Error updating experience in vector store: {e}")

    def _work_exp_to_dict(self, work_exp: WorkExperience) -> Dict[str, Any]:
        """Convert work experience to dictionary."""
        return {
            'id': work_exp.id,
            'company_name': work_exp.company_name,
            'job_title': work_exp.job_title,
            'start_date': work_exp.start_date,
            'end_date': work_exp.end_date,
            'location': work_exp.location,
            'description': work_exp.description,
            'achievements': work_exp.achievements or [],
            'technologies': work_exp.technologies or [],
            'is_current': work_exp.is_current
        }

    def _education_to_dict(self, education: Education) -> Dict[str, Any]:
        """Convert education to dictionary."""
        return {
            'id': education.id,
            'institution': education.institution,
            'degree': education.degree,
            'field_of_study': education.field_of_study,
            'start_date': education.start_date,
            'end_date': education.end_date,
            'gpa': education.gpa,
            'location': education.location,
            'description': education.description,
            'achievements': education.achievements or []
        }

    def _skill_to_dict(self, skill: Skill) -> Dict[str, Any]:
        """Convert skill to dictionary."""
        return {
            'id': skill.id,
            'name': skill.name,
            'category': skill.category,
            'proficiency_level': skill.proficiency_level,
            'years_experience': skill.years_experience
        }

    def _project_to_dict(self, project: Project) -> Dict[str, Any]:
        """Convert project to dictionary."""
        return {
            'id': project.id,
            'name': project.name,
            'description': project.description,
            'start_date': project.start_date,
            'end_date': project.end_date,
            'project_url': project.project_url,
            'github_url': project.github_url,
            'technologies': project.technologies or [],
            'achievements': project.achievements or []
        }

# Global experience manager instance
experience_manager = ExperienceManager()
