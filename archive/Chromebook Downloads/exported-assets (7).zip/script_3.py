# 4. Create the main __init__.py files and core configuration
src_init_content = '''"""
Enhanced Resume Agent 3.0
AI-powered career document generation system for personal use.
"""

__version__ = "3.0.0"
__author__ = "Enhanced Resume Agent Team"
__description__ = "AI-powered career document generation system"

from .utils.config import Config
from .utils.logger import get_logger

# Initialize logging
logger = get_logger(__name__)

def get_version() -> str:
    """Return the current version."""
    return __version__
'''

with open("src/__init__.py", "w") as f:
    f.write(src_init_content)

# Create agents __init__.py
agents_init_content = '''"""
AI Agents Module
Contains the core AI agents for resume processing and optimization.
"""

from .company_research import CompanyResearchAgent
from .resume_optimizer import ResumeOptimizerAgent
from .cover_letter_generator import CoverLetterGeneratorAgent
from .ksc_responder import KSCResponderAgent
from .nlp_engine import AdvancedNLPEngine
from .orchestrator import AgentOrchestrator

__all__ = [
    "CompanyResearchAgent",
    "ResumeOptimizerAgent", 
    "CoverLetterGeneratorAgent",
    "KSCResponderAgent",
    "AdvancedNLPEngine",
    "AgentOrchestrator"
]
'''

with open("src/agents/__init__.py", "w") as f:
    f.write(agents_init_content)

# Create integrations __init__.py
integrations_init_content = '''"""
External API Integrations Module
Contains integrations with external services like Google Gemini and Perplexity.
"""

from .gemini_client import GeminiClient
from .perplexity_client import PerplexityClient

__all__ = [
    "GeminiClient",
    "PerplexityClient"
]
'''

with open("src/integrations/__init__.py", "w") as f:
    f.write(integrations_init_content)

# Create data __init__.py
data_init_content = '''"""
Data Management Module
Contains database models, vector store management, and data processing utilities.
"""

from .models import User, Resume, CoverLetter, JobApplication
from .vector_store import VectorStoreManager
from .experience_manager import ExperienceManager

__all__ = [
    "User",
    "Resume", 
    "CoverLetter",
    "JobApplication",
    "VectorStoreManager",
    "ExperienceManager"
]
'''

with open("src/data/__init__.py", "w") as f:
    f.write(data_init_content)

# Create utils __init__.py  
utils_init_content = '''"""
Utilities Module
Contains configuration management, logging, validators, and other utility functions.
"""

from .config import Config
from .logger import get_logger, setup_logging
from .validators import validate_email, validate_phone, validate_url
from .file_handlers import PDFHandler, DocumentProcessor

__all__ = [
    "Config",
    "get_logger",
    "setup_logging", 
    "validate_email",
    "validate_phone",
    "validate_url",
    "PDFHandler",
    "DocumentProcessor"
]
'''

with open("src/utils/__init__.py", "w") as f:
    f.write(utils_init_content)

print("✓ Created __init__.py files for all modules")

# Create web component __init__.py files
web_init_content = '''"""
Web Interface Module
Streamlit-based web interface for the Enhanced Resume Agent.
"""
'''

with open("web/__init__.py", "w") as f:
    f.write(web_init_content)

with open("web/components/__init__.py", "w") as f:
    f.write("# Web Components\n")

with open("web/pages/__init__.py", "w") as f:
    f.write("# Web Pages\n")

print("✓ Created web module __init__.py files")