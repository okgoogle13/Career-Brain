"""
Sample tests for Enhanced Resume Agent 3.0
"""

import pytest
from unittest.mock import Mock, patch
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from utils.config import Config
from utils.validators import validate_email, validate_phone, validate_url

class TestValidators:
    """Test validation functions."""

    def test_validate_email_valid(self):
        """Test valid email validation."""
        assert validate_email("test@example.com") == True
        assert validate_email("user.name+tag@domain.co.uk") == True

    def test_validate_email_invalid(self):
        """Test invalid email validation."""
        assert validate_email("invalid-email") == False
        assert validate_email("@domain.com") == False
        assert validate_email("user@") == False
        assert validate_email("") == False
        assert validate_email(None) == False

    def test_validate_phone_valid(self):
        """Test valid phone validation."""
        assert validate_phone("1234567890") == True
        assert validate_phone("+1 (555) 123-4567") == True
        assert validate_phone("555-123-4567") == True

    def test_validate_phone_invalid(self):
        """Test invalid phone validation."""
        assert validate_phone("123") == False
        assert validate_phone("abc-def-ghij") == False
        assert validate_phone("") == False
        assert validate_phone(None) == False

    def test_validate_url_valid(self):
        """Test valid URL validation."""
        assert validate_url("https://example.com") == True
        assert validate_url("http://test.org") == True
        assert validate_url("https://sub.domain.com/path") == True

    def test_validate_url_invalid(self):
        """Test invalid URL validation."""
        assert validate_url("not-a-url") == False
        assert validate_url("ftp://example.com") == False  # We only accept http/https
        assert validate_url("") == False
        assert validate_url(None) == False

class TestConfig:
    """Test configuration management."""

    def test_config_initialization(self):
        """Test config can be initialized."""
        config = Config()
        assert config.app.name is not None
        assert config.app.version is not None

    @patch.dict('os.environ', {'APP_DEBUG': 'true'})
    def test_config_environment_override(self):
        """Test config respects environment variables."""
        config = Config()
        # Note: This test might need adjustment based on actual implementation
        assert config.app.debug in [True, False]  # Should be a boolean

class TestIntegration:
    """Integration tests."""

    @pytest.mark.integration
    def test_database_connection(self):
        """Test database connection works."""
        try:
            from data.database import db_manager
            with db_manager.get_session() as session:
                # Simple connection test
                assert session is not None
        except Exception as e:
            pytest.skip(f"Database not available: {e}")

    @pytest.mark.integration
    def test_vector_store_initialization(self):
        """Test vector store can be initialized."""
        try:
            from data.vector_store import VectorStoreManager
            vector_store = VectorStoreManager()
            stats = vector_store.get_collection_stats()
            assert isinstance(stats, dict)
            assert 'experiences' in stats
            assert 'job_descriptions' in stats
        except Exception as e:
            pytest.skip(f"Vector store not available: {e}")

@pytest.fixture
def mock_user_data():
    """Fixture for mock user data."""
    return {
        'id': 1,
        'email': 'test@example.com',
        'full_name': 'Test User',
        'phone': '555-123-4567',
        'linkedin_url': 'https://linkedin.com/in/testuser',
        'github_url': 'https://github.com/testuser',
        'location': 'Test City, TC'
    }

@pytest.fixture
def mock_work_experience():
    """Fixture for mock work experience data."""
    return {
        'id': 1,
        'company_name': 'Test Company',
        'job_title': 'Software Engineer',
        'start_date': '2023-01',
        'end_date': '2024-01',
        'location': 'Test City, TC',
        'description': 'Developed software applications',
        'achievements': ['Improved performance by 50%', 'Led team of 3 developers'],
        'technologies': ['Python', 'JavaScript', 'React'],
        'is_current': False
    }

# Parameterized tests
@pytest.mark.parametrize("email,expected", [
    ("valid@email.com", True),
    ("invalid-email", False),
    ("another.valid+email@domain.co.uk", True),
    ("", False),
])
def test_email_validation_parameterized(email, expected):
    """Parameterized test for email validation."""
    assert validate_email(email) == expected

if __name__ == "__main__":
    pytest.main([__file__])
