# Enhanced Resume Agent 3.0

> **AI-powered career document generation system for personal use**

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

Enhanced Resume Agent 3.0 is a comprehensive, AI-powered career document generation system designed for personal use. It leverages Google Gemini 2.5 Pro and Perplexity API to automate the creation of ATS-optimized resumes, cover letters, and key selection criteria responses.

## ✨ Features

### 🎯 Core Capabilities
- **AI-Powered Resume Optimization** - Tailors resumes to specific job descriptions using Google Gemini
- **Company Research** - Automated company intelligence via Perplexity API
- **ATS Compatibility** - Ensures 90%+ ATS compatibility with optimized formatting
- **Multi-Format Document Generation** - Resumes, cover letters, and KSC responses
- **Professional Themes** - 5 carefully designed resume themes for different industries

### 🔧 Technical Features
- **Vector-Based Experience Matching** - ChromaDB integration for intelligent experience selection
- **Dual Interface** - Both CLI and Streamlit web interface
- **Personal Data Management** - SQLite database for single-user optimization
- **Cloud-Ready Deployment** - Docker and Google Cloud Run support
- **Comprehensive Testing** - Full test suite with CI/CD pipeline

### 🌏 Regional Compliance
- **Australian Government Jobs** - Specialized KSC response templates with STAR method
- **International Standards** - Adaptable templates for global job markets

## 🚀 Quick Start

### Prerequisites
- Python 3.11 or higher
- Google Gemini API key
- Perplexity API key

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd enhanced-resume-agent
   ```

2. **Set up environment**
   ```bash
   # Using Make (recommended)
   make dev-setup

   # Or manually
   pip install -r requirements.txt
   cp .env.example .env
   ```

3. **Configure API keys**
   Edit `.env` file with your API keys:
   ```bash
   GOOGLE_GEMINI_API_KEY=your_gemini_api_key_here
   PERPLEXITY_API_KEY=your_perplexity_api_key_here
   ```

4. **Initialize the system**
   ```bash
   # CLI initialization
   python -m src.cli init --email your@email.com --name "Your Name"

   # Or use the web interface
   make run-web
   ```

### First Run

**Web Interface (Recommended for beginners):**
```bash
make run-web
# Opens http://localhost:8501
```

**Command Line Interface:**
```bash
# Check system status
python -m src.cli status

# Add work experience
python -m src.cli experience add

# Research a company
python -m src.cli research "Google"
```

## 📖 Usage Guide

### Web Interface

The Streamlit web interface provides an intuitive way to:

1. **Manage Profile** - Set up personal information and contact details
2. **Add Experiences** - Input work history, education, skills, and projects  
3. **Research Companies** - Get AI-powered company insights
4. **Generate Documents** - Create optimized resumes and cover letters
5. **Track Applications** - Monitor job application progress

Navigate to different sections using the sidebar menu.

### CLI Interface

The command-line interface offers powerful automation capabilities:

```bash
# System management
python -m src.cli init          # Initialize user profile
python -m src.cli status        # Show system status
python -m src.cli profile       # Manage profile information

# Experience management  
python -m src.cli experience add    # Add work experience
python -m src.cli experience list   # List all experiences

# Research and analysis
python -m src.cli research "Company Name"  # Research company

# Launch web interface
python -m src.cli web           # Start Streamlit app
```

## 🏗️ Architecture

### System Components

```
Enhanced Resume Agent 3.0/
├── src/                    # Core application code
│   ├── agents/            # AI agents for different tasks
│   ├── integrations/      # External API integrations
│   ├── data/              # Database and vector store management
│   └── utils/             # Configuration and utilities
├── web/                   # Streamlit web interface
├── templates/             # Jinja2 document templates
├── config/                # Configuration files
└── tests/                 # Test suite
```

### Key Technologies

- **AI/ML**: Google Gemini 2.5 Pro, Perplexity API, Sentence-Transformers
- **Data**: SQLite, ChromaDB for vector storage
- **Web**: Streamlit for user interface
- **CLI**: Typer for command-line interface
- **Cloud**: Docker, Google Cloud Run
- **Testing**: pytest, GitHub Actions

## 🎨 Document Themes

### Resume Themes
1. **Professional Classic** - Traditional, ATS-friendly design
2. **Modern Minimalist** - Clean, contemporary layout
3. **Contemporary Professional** - Balanced modern design
4. **Bold Executive** - Executive-level presentation
5. **Vibrant Creative** - Creative industry focus

### Template Types
- **Resumes** - Multiple themes with intelligent content optimization
- **Cover Letters** - Professional templates with company research integration  
- **Key Selection Criteria** - Australian government compliance with STAR method

## 🔧 Development

### Setup Development Environment

```bash
# Install development dependencies
make install-dev

# Set up pre-commit hooks
pre-commit install

# Run tests
make test

# Format code
make format

# Run linting
make lint
```

### Code Quality

The project maintains high code quality standards:

- **Black** for code formatting
- **isort** for import sorting  
- **flake8** for linting
- **mypy** for type checking
- **bandit** for security scanning
- **pytest** for testing

### Testing

```bash
# Run full test suite
make test

# Run specific test categories
pytest tests/unit/          # Unit tests
pytest tests/integration/   # Integration tests

# Run with coverage
pytest --cov=src --cov-report=html
```

## 🐳 Docker Deployment

### Local Docker

```bash
# Build image
make docker-build

# Run container
make docker-run

# Or use docker-compose
docker-compose up -d
```

### Google Cloud Run

```bash
# Deploy to Cloud Run
make deploy-cloud-run

# Requires GOOGLE_CLOUD_PROJECT environment variable
export GOOGLE_CLOUD_PROJECT=your-project-id
```

## 📁 Configuration

### Environment Variables

Key configuration options in `.env`:

```bash
# Required API Keys
GOOGLE_GEMINI_API_KEY=your_gemini_api_key
PERPLEXITY_API_KEY=your_perplexity_api_key

# Application Settings  
DEBUG=false
LOG_LEVEL=INFO
DATABASE_URL=sqlite:///~/.resume_agent/data.sqlite

# Document Generation
MAX_RESUME_PAGES=2
DEFAULT_THEME=professional_classic
```

### YAML Configuration

Additional settings in `config/app.yaml`:

- Theme configurations
- API model parameters
- Security settings  
- Feature toggles

## 🔒 Security & Privacy

### Data Protection
- **Local Storage** - All personal data stored locally in SQLite
- **API Key Security** - Credentials managed via environment variables
- **No Data Sharing** - Personal information never shared with external services
- **Secure Communication** - HTTPS for all API communications

### Best Practices
- Regular security scanning with Bandit
- Dependency vulnerability checking with Safety
- Secure defaults in all configurations
- Minimal permission requirements

## 🆘 Troubleshooting

### Common Issues

**API Connection Errors:**
```bash
# Check API key configuration
python -m src.cli status

# Test API connections
python -c "from src.integrations.gemini_client import gemini_client; print('Gemini OK' if gemini_client else 'Gemini Error')"
```

**Database Issues:**
```bash
# Reset database
make reset-db

# Check database status
python -m src.cli status
```

**Installation Problems:**
```bash
# Clean install
make clean
make install

# Check Python version
python --version  # Should be 3.11+
```

### Log Files

Check logs for detailed error information:
- Development: Console output
- Production: `~/.resume_agent/logs/app.log`

## 🤝 Contributing

This is a personal-use project, but contributions are welcome:

1. Fork the repository
2. Create a feature branch
3. Make your changes with tests
4. Run the test suite
5. Submit a pull request

### Development Workflow

```bash
# Create feature branch
git checkout -b feature/new-feature

# Make changes and test
make ci-test

# Commit changes
git commit -m "Add new feature"

# Push and create PR
git push origin feature/new-feature
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Google Gemini** for advanced AI capabilities
- **Perplexity AI** for real-time web research
- **ChromaDB** for vector storage
- **Streamlit** for rapid web development
- **Open Source Community** for excellent Python tools

## 📞 Support

For issues and questions:
1. Check the [troubleshooting section](#-troubleshooting)
2. Review existing [issues](../../issues)
3. Create a new issue with detailed information

---

**Enhanced Resume Agent 3.0** - Empowering your career with AI-powered document generation.
