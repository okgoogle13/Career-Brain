"""
Enhanced Resume Agent 3.0 - Streamlit Web Interface
"""

import streamlit as st
import sys
from pathlib import Path

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from utils.config import config
from utils.logger import get_logger
from data.database import db_manager
from data.models import User, get_or_create_user
from data.experience_manager import experience_manager
from integrations.gemini_client import gemini_client
from integrations.perplexity_client import perplexity_client

# Page configuration
st.set_page_config(
    page_title="Enhanced Resume Agent 3.0",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Setup logging
logger = get_logger(__name__)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: 700;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }

    .section-header {
        font-size: 1.5rem;
        font-weight: 600;
        color: #2c3e50;
        border-bottom: 2px solid #3498db;
        padding-bottom: 0.5rem;
        margin: 1.5rem 0 1rem 0;
    }

    .info-card {
        background-color: #f8f9fa;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #17a2b8;
        margin: 1rem 0;
    }

    .success-message {
        background-color: #d4edda;
        color: #155724;
        padding: 1rem;
        border-radius: 0.5rem;
        border: 1px solid #c3e6cb;
        margin: 1rem 0;
    }

    .error-message {
        background-color: #f8d7da;
        color: #721c24;
        padding: 1rem;
        border-radius: 0.5rem;
        border: 1px solid #f5c6cb;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

def initialize_session_state():
    """Initialize session state variables."""
    if 'user' not in st.session_state:
        st.session_state.user = None
    if 'current_page' not in st.session_state:
        st.session_state.current_page = 'Profile'

def get_current_user():
    """Get or create the current user."""
    try:
        with db_manager.get_session() as session:
            user = session.query(User).first()
            if user:
                st.session_state.user = {
                    'id': user.id,
                    'email': user.email,
                    'full_name': user.full_name,
                    'phone': user.phone,
                    'linkedin_url': user.linkedin_url,
                    'github_url': user.github_url,
                    'location': user.location
                }
                return user
            else:
                return None
    except Exception as e:
        st.error(f"Database error: {e}")
        return None

def sidebar_navigation():
    """Render sidebar navigation."""
    st.sidebar.markdown("## 🧭 Navigation")

    pages = [
        "👤 Profile",
        "💼 Experience", 
        "🔍 Job Research",
        "📄 Generate Resume",
        "✉️ Cover Letter",
        "📊 Analytics",
        "⚙️ Settings"
    ]

    # Remove emojis for the key
    page_keys = [page.split(' ', 1)[1] for page in pages]

    selected_page = st.sidebar.radio(
        "Select a page:",
        pages,
        index=page_keys.index(st.session_state.current_page) if st.session_state.current_page in page_keys else 0
    )

    # Update current page (remove emoji)
    st.session_state.current_page = selected_page.split(' ', 1)[1]

    # System status in sidebar
    st.sidebar.markdown("---")
    st.sidebar.markdown("## 🔌 System Status")

    # API status
    gemini_status = "🟢 Connected" if gemini_client else "🔴 Disconnected"
    perplexity_status = "🟢 Connected" if perplexity_client else "🔴 Disconnected"

    st.sidebar.markdown(f"**Gemini API:** {gemini_status}")
    st.sidebar.markdown(f"**Perplexity API:** {perplexity_status}")

    # Database status
    try:
        with db_manager.get_session() as session:
            user_count = session.query(User).count()
            st.sidebar.markdown(f"**Database:** 🟢 Active ({user_count} users)")
    except:
        st.sidebar.markdown("**Database:** 🔴 Error")

def profile_page():
    """Render the profile management page."""
    st.markdown('<h1 class="main-header">👤 User Profile</h1>', unsafe_allow_html=True)

    user = get_current_user()

    if not user:
        st.markdown('<div class="info-card">ℹ️ No user profile found. Please create one below.</div>', unsafe_allow_html=True)

        with st.form("create_profile"):
            st.markdown('<h3 class="section-header">Create Profile</h3>', unsafe_allow_html=True)

            col1, col2 = st.columns(2)

            with col1:
                full_name = st.text_input("Full Name *", placeholder="John Doe")
                email = st.text_input("Email Address *", placeholder="john.doe@example.com")
                phone = st.text_input("Phone Number", placeholder="+1 (555) 123-4567")

            with col2:
                linkedin_url = st.text_input("LinkedIn URL", placeholder="https://linkedin.com/in/johndoe")
                github_url = st.text_input("GitHub URL", placeholder="https://github.com/johndoe")
                location = st.text_input("Location", placeholder="New York, NY")

            submitted = st.form_submit_button("Create Profile", type="primary")

            if submitted:
                if full_name and email:
                    try:
                        with db_manager.get_session() as session:
                            user = get_or_create_user(session, email, full_name)
                            user.phone = phone if phone else None
                            user.linkedin_url = linkedin_url if linkedin_url else None
                            user.github_url = github_url if github_url else None
                            user.location = location if location else None
                            session.commit()

                            st.success("✅ Profile created successfully!")
                            st.rerun()
                    except Exception as e:
                        st.error(f"❌ Error creating profile: {e}")
                else:
                    st.error("❌ Please fill in the required fields (Name and Email)")

    else:
        # Show existing profile
        st.markdown('<h3 class="section-header">Current Profile</h3>', unsafe_allow_html=True)

        col1, col2 = st.columns(2)

        with col1:
            st.markdown(f"**Name:** {user.full_name}")
            st.markdown(f"**Email:** {user.email}")
            st.markdown(f"**Phone:** {user.phone or 'Not set'}")

        with col2:
            st.markdown(f"**LinkedIn:** {user.linkedin_url or 'Not set'}")
            st.markdown(f"**GitHub:** {user.github_url or 'Not set'}")
            st.markdown(f"**Location:** {user.location or 'Not set'}")

        # Update profile form
        with st.expander("✏️ Update Profile"):
            with st.form("update_profile"):
                col1, col2 = st.columns(2)

                with col1:
                    new_name = st.text_input("Full Name", value=user.full_name)
                    new_phone = st.text_input("Phone", value=user.phone or "")
                    new_location = st.text_input("Location", value=user.location or "")

                with col2:
                    new_linkedin = st.text_input("LinkedIn URL", value=user.linkedin_url or "")
                    new_github = st.text_input("GitHub URL", value=user.github_url or "")

                updated = st.form_submit_button("Update Profile", type="primary")

                if updated:
                    try:
                        with db_manager.get_session() as session:
                            db_user = session.query(User).filter(User.id == user.id).first()
                            db_user.full_name = new_name
                            db_user.phone = new_phone if new_phone else None
                            db_user.linkedin_url = new_linkedin if new_linkedin else None
                            db_user.github_url = new_github if new_github else None
                            db_user.location = new_location if new_location else None
                            session.commit()

                            st.success("✅ Profile updated successfully!")
                            st.rerun()
                    except Exception as e:
                        st.error(f"❌ Error updating profile: {e}")

def experience_page():
    """Render the experience management page."""
    st.markdown('<h1 class="main-header">💼 Work Experience</h1>', unsafe_allow_html=True)

    user = get_current_user()
    if not user:
        st.error("❌ Please create a profile first.")
        return

    # Get user experiences
    experiences = experience_manager.get_user_experiences(user.id)
    work_exps = experiences.get('work_experiences', [])

    # Display existing experiences
    if work_exps:
        st.markdown('<h3 class="section-header">Your Work Experiences</h3>', unsafe_allow_html=True)

        for exp in work_exps:
            with st.expander(f"{exp['job_title']} at {exp['company_name']} ({exp['start_date']} - {exp['end_date'] or 'Present'})"):
                col1, col2 = st.columns([3, 1])

                with col1:
                    if exp['location']:
                        st.markdown(f"**Location:** {exp['location']}")
                    if exp['description']:
                        st.markdown(f"**Description:** {exp['description']}")
                    if exp['achievements']:
                        st.markdown("**Achievements:**")
                        for achievement in exp['achievements']:
                            st.markdown(f"• {achievement}")
                    if exp['technologies']:
                        st.markdown(f"**Technologies:** {', '.join(exp['technologies'])}")

                with col2:
                    if st.button(f"Delete", key=f"delete_{exp['id']}", type="secondary"):
                        if experience_manager.delete_work_experience(exp['id']):
                            st.success("✅ Experience deleted!")
                            st.rerun()
                        else:
                            st.error("❌ Failed to delete experience")

    else:
        st.info("📝 No work experiences found. Add your first experience below.")

    # Add new experience form
    with st.expander("➕ Add New Work Experience", expanded=len(work_exps) == 0):
        with st.form("add_experience"):
            col1, col2 = st.columns(2)

            with col1:
                job_title = st.text_input("Job Title *")
                company_name = st.text_input("Company Name *")
                location = st.text_input("Location")
                start_date = st.text_input("Start Date (YYYY-MM) *", placeholder="2023-01")

            with col2:
                is_current = st.checkbox("Currently working here")
                end_date = st.text_input("End Date (YYYY-MM)", 
                                       disabled=is_current,
                                       value="Present" if is_current else "",
                                       placeholder="2024-06")

            description = st.text_area("Job Description", height=100)

            # Achievements
            st.markdown("**Key Achievements** (one per line)")
            achievements_text = st.text_area("Achievements", height=80, 
                                           placeholder="Increased sales by 25%\nManaged team of 5 developers")

            # Technologies
            technologies_text = st.text_input("Technologies/Skills Used", 
                                            placeholder="Python, AWS, Docker, etc.")

            submitted = st.form_submit_button("Add Experience", type="primary")

            if submitted:
                if job_title and company_name and start_date:
                    # Parse achievements and technologies
                    achievements = [a.strip() for a in achievements_text.split('\n') if a.strip()] if achievements_text else []
                    technologies = [t.strip() for t in technologies_text.split(',') if t.strip()] if technologies_text else []

                    exp_id = experience_manager.add_work_experience(
                        user_id=user.id,
                        company_name=company_name,
                        job_title=job_title,
                        start_date=start_date,
                        end_date=None if is_current else end_date,
                        location=location if location else None,
                        description=description if description else None,
                        achievements=achievements,
                        technologies=technologies,
                        is_current=is_current
                    )

                    if exp_id:
                        st.success("✅ Work experience added successfully!")
                        st.rerun()
                    else:
                        st.error("❌ Failed to add work experience")
                else:
                    st.error("❌ Please fill in the required fields")

def job_research_page():
    """Render the job research page."""
    st.markdown('<h1 class="main-header">🔍 Job & Company Research</h1>', unsafe_allow_html=True)

    if not perplexity_client:
        st.error("❌ Perplexity API not configured. Please check your API key in settings.")
        return

    tab1, tab2 = st.tabs(["🏢 Company Research", "📈 Job Market Analysis"])

    with tab1:
        st.markdown('<h3 class="section-header">Company Research</h3>', unsafe_allow_html=True)

        with st.form("company_research"):
            company_name = st.text_input("Company Name", placeholder="Google, Apple, Microsoft...")
            include_news = st.checkbox("Include recent news and developments", value=True)

            research_btn = st.form_submit_button("🔍 Research Company", type="primary")

            if research_btn and company_name:
                with st.spinner(f"Researching {company_name}..."):
                    research_data = perplexity_client.research_company(
                        company_name, 
                        include_recent_news=include_news
                    )

                    if research_data:
                        st.markdown('<h4 class="section-header">Research Results</h4>', unsafe_allow_html=True)
                        st.markdown(research_data['research_content'])

                        # Save research option
                        if st.button("💾 Save Research Results"):
                            # Implementation for saving research
                            st.success("✅ Research saved successfully!")
                    else:
                        st.error("❌ Failed to research company. Please try again.")

    with tab2:
        st.markdown('<h3 class="section-header">Job Market Analysis</h3>', unsafe_allow_html=True)

        with st.form("job_market_analysis"):
            col1, col2 = st.columns(2)

            with col1:
                job_title = st.text_input("Job Title", placeholder="Software Engineer, Data Scientist...")
                location = st.text_input("Location (optional)", placeholder="San Francisco, Remote...")

            with col2:
                industry = st.selectbox("Industry (optional)", 
                                      ["", "Technology", "Healthcare", "Finance", "Education", 
                                       "Government", "Retail", "Manufacturing", "Other"])

            analyze_btn = st.form_submit_button("📊 Analyze Job Market", type="primary")

            if analyze_btn and job_title:
                with st.spinner(f"Analyzing job market for {job_title}..."):
                    market_data = perplexity_client.analyze_job_market(
                        job_title=job_title,
                        location=location if location else None,
                        industry=industry if industry else None
                    )

                    if market_data:
                        st.markdown('<h4 class="section-header">Market Analysis Results</h4>', unsafe_allow_html=True)
                        st.markdown(market_data['market_analysis'])
                    else:
                        st.error("❌ Failed to analyze job market. Please try again.")

def settings_page():
    """Render the settings page."""
    st.markdown('<h1 class="main-header">⚙️ Settings</h1>', unsafe_allow_html=True)

    tab1, tab2, tab3 = st.tabs(["🔑 API Configuration", "🎨 Preferences", "ℹ️ System Info"])

    with tab1:
        st.markdown('<h3 class="section-header">API Configuration</h3>', unsafe_allow_html=True)
        st.info("ℹ️ API keys are configured via environment variables. See .env.example for details.")

        # Show API status
        col1, col2 = st.columns(2)

        with col1:
            st.markdown("**Google Gemini API**")
            if gemini_client:
                st.success("✅ Connected and ready")
            else:
                st.error("❌ Not configured")
                st.markdown("Set `GOOGLE_GEMINI_API_KEY` in your .env file")

        with col2:
            st.markdown("**Perplexity API**")
            if perplexity_client:
                st.success("✅ Connected and ready")
            else:
                st.error("❌ Not configured")
                st.markdown("Set `PERPLEXITY_API_KEY` in your .env file")

    with tab2:
        st.markdown('<h3 class="section-header">Application Preferences</h3>', unsafe_allow_html=True)

        # Theme selection
        default_theme = st.selectbox(
            "Default Resume Theme",
            ["professional_classic", "modern_minimalist", "contemporary_professional", 
             "bold_executive", "vibrant_creative"],
            index=0
        )

        # Output preferences
        max_pages = st.slider("Maximum Resume Pages", 1, 3, 2)

        if st.button("💾 Save Preferences"):
            st.success("✅ Preferences saved!")

    with tab3:
        st.markdown('<h3 class="section-header">System Information</h3>', unsafe_allow_html=True)

        col1, col2 = st.columns(2)

        with col1:
            st.markdown("**Application**")
            st.markdown(f"Version: {config.app.version}")
            st.markdown(f"Debug Mode: {config.app.debug}")
            st.markdown(f"Log Level: {config.app.log_level}")

        with col2:
            st.markdown("**Database**")
            try:
                with db_manager.get_session() as session:
                    user_count = session.query(User).count()
                    st.markdown(f"Users: {user_count}")
                    st.markdown("Status: ✅ Connected")
            except Exception as e:
                st.markdown("Status: ❌ Error")

        # Vector store stats
        try:
            from data.vector_store import vector_store
            stats = vector_store.get_collection_stats()
            st.markdown("**Vector Store**")
            st.markdown(f"Experiences: {stats['experiences']}")
            st.markdown(f"Job Descriptions: {stats['job_descriptions']}")
        except Exception as e:
            st.markdown("**Vector Store**")
            st.markdown("Status: ❌ Error")

def main():
    """Main application function."""
    # Initialize session state
    initialize_session_state()

    # Render sidebar navigation
    sidebar_navigation()

    # Route to appropriate page
    if st.session_state.current_page == 'Profile':
        profile_page()
    elif st.session_state.current_page == 'Experience':
        experience_page()
    elif st.session_state.current_page == 'Job Research':
        job_research_page()
    elif st.session_state.current_page == 'Generate Resume':
        st.markdown('<h1 class="main-header">📄 Generate Resume</h1>', unsafe_allow_html=True)
        st.info("🚧 Resume generation feature coming soon!")
    elif st.session_state.current_page == 'Cover Letter':
        st.markdown('<h1 class="main-header">✉️ Cover Letter Generator</h1>', unsafe_allow_html=True)
        st.info("🚧 Cover letter generation feature coming soon!")
    elif st.session_state.current_page == 'Analytics':
        st.markdown('<h1 class="main-header">📊 Analytics</h1>', unsafe_allow_html=True)
        st.info("🚧 Analytics feature coming soon!")
    elif st.session_state.current_page == 'Settings':
        settings_page()

    # Footer
    st.markdown("---")
    st.markdown(
        '<div style="text-align: center; color: #666; padding: 1rem;">'
        f'Enhanced Resume Agent {config.app.version} | '
        'AI-powered career document generation'
        '</div>',
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()
