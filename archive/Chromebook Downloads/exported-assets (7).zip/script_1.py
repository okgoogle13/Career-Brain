# 1. Create pyproject.toml for modern Python packaging
pyproject_content = '''[build-system]
requires = ["poetry-core>=1.0.0"]
build-backend = "poetry.core.masonry.api"

[tool.poetry]
name = "enhanced-resume-agent"
version = "3.0.0"
description = "AI-powered career document generation system for personal use"
authors = ["Your Name <your.email@example.com>"]
license = "MIT"
readme = "README.md"
packages = [{include = "src"}]

[tool.poetry.dependencies]
python = "^3.11"
streamlit = "^1.29.0"
click = "^8.1.7"
typer = "^0.9.0"
langchain = "^0.1.0"
langchain-google-genai = "^1.0.0"
sentence-transformers = "^2.2.2"
spacy = "^3.7.0"
chromadb = "^0.4.0"
faiss-cpu = "^1.7.4"
sqlalchemy = "^2.0.0"
pydantic = "^2.5.0"
jinja2 = "^3.1.2"
pyyaml = "^6.0.1"
python-dotenv = "^1.0.0"
requests = "^2.31.0"
pandas = "^2.1.0"
pypdf2 = "^3.0.1"
reportlab = "^4.0.0"
python-multipart = "^0.0.6"
plotly = "^5.17.0"

[tool.poetry.group.dev.dependencies]
pytest = "^7.4.0"
pytest-cov = "^4.1.0"
black = "^23.11.0"
isort = "^5.12.0"
flake8 = "^6.1.0"
mypy = "^1.7.0"
bandit = "^1.7.5"
safety = "^2.3.5"
pre-commit = "^3.6.0"

[tool.poetry.scripts]
resume-agent = "src.cli:app"

[tool.black]
line-length = 88
target-version = ['py311']
include = '\\.pyi?$'
extend-exclude = '''
/(
  # directories
  \\.eggs
  | \\.git
  | \\.hg
  | \\.mypy_cache
  | \\.tox
  | \\.venv
  | build
  | dist
)/
'''

[tool.isort]
profile = "black"
multi_line_output = 3
line_length = 88
include_trailing_comma = true
sections = ["FUTURE", "STDLIB", "THIRDPARTY", "FIRSTPARTY", "LOCALFOLDER"]

[tool.mypy]
python_version = "3.11"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
check_untyped_defs = true
no_implicit_optional = true
warn_redundant_casts = true
warn_unused_ignores = true
show_error_codes = true

[tool.pytest.ini_options]
minversion = "6.0"
addopts = "-ra -q --strict-markers --cov=src --cov-report=term-missing"
testpaths = ["tests"]
markers = [
    "slow: marks tests as slow (deselect with '-m \"not slow\"')",
    "integration: marks tests as integration tests",
]

[tool.bandit]
exclude_dirs = ["tests", "venv", ".venv"]
skips = ["B101", "B601"]

[tool.coverage.run]
source = ["src"]
omit = ["*/tests/*", "*/test_*"]

[tool.coverage.report]
exclude_lines = [
    "pragma: no cover",
    "def __repr__",
    "if self.debug:",
    "if settings.DEBUG",
    "raise AssertionError",
    "raise NotImplementedError",
    "if 0:",
    "if __name__ == .__main__.:",
]
'''

with open("pyproject.toml", "w") as f:
    f.write(pyproject_content)

print("✓ Created pyproject.toml")

# 2. Create requirements.txt for pip users
requirements_content = '''# Core AI/ML Dependencies
langchain==0.1.0
langchain-google-genai==1.0.0
sentence-transformers==2.2.2
spacy==3.7.0
chromadb==0.4.0
faiss-cpu==1.7.4

# Web Framework
streamlit==1.29.0

# CLI Framework
click==8.1.7
typer==0.9.0

# Data Processing
pandas==2.1.0
sqlalchemy==2.0.0
pydantic==2.5.0

# Document Processing
jinja2==3.1.2
pypdf2==3.0.1
reportlab==4.0.0
python-multipart==0.0.6

# Configuration & Environment
pyyaml==6.0.1
python-dotenv==1.0.0

# HTTP & API
requests==2.31.0

# Visualization
plotly==5.17.0

# Development Dependencies
pytest==7.4.0
pytest-cov==4.1.0
black==23.11.0
isort==5.12.0
flake8==6.1.0
mypy==1.7.0
bandit==1.7.5
safety==2.3.5
pre-commit==3.6.0
'''

with open("requirements.txt", "w") as f:
    f.write(requirements_content)

print("✓ Created requirements.txt")

# 3. Create .env.example
env_example_content = '''# Enhanced Resume Agent 3.0 - Environment Configuration
# Copy this file to .env and fill in your actual values

# API Keys (Required)
GOOGLE_GEMINI_API_KEY=your_gemini_api_key_here
PERPLEXITY_API_KEY=your_perplexity_api_key_here

# Application Configuration
APP_NAME="Enhanced Resume Agent 3.0"
APP_VERSION="3.0.0"
DEBUG=false
LOG_LEVEL=INFO

# Database Configuration (SQLite for personal use)
DATABASE_URL=sqlite:///~/.resume_agent/data.sqlite

# Vector Store Configuration
VECTOR_STORE_TYPE=chromadb
CHROMADB_PATH=~/.resume_agent/vector_db

# Document Generation
MAX_RESUME_PAGES=2
DEFAULT_THEME=professional_classic
OUTPUT_FORMAT=pdf

# Security
SECRET_KEY=your_secret_key_here_change_this_in_production

# Streamlit Configuration
STREAMLIT_PORT=8501
STREAMLIT_HOST=localhost

# Cloud Configuration (Optional)
GOOGLE_CLOUD_PROJECT=your-project-id
GOOGLE_CLOUD_REGION=us-central1

# Performance Settings
MAX_CONCURRENT_REQUESTS=1
CACHE_TTL_SECONDS=3600
'''

with open(".env.example", "w") as f:
    f.write(env_example_content)

print("✓ Created .env.example")