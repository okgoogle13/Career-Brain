# 15. Create configuration files and templates
config_app_content = '''# Enhanced Resume Agent 3.0 - Application Configuration

app:
  name: "Enhanced Resume Agent 3.0"
  version: "3.0.0"
  description: "AI-powered career document generation system for personal use"
  debug: false
  log_level: "INFO"
  secret_key: "change-this-in-production"

database:
  url: "sqlite:///~/.resume_agent/data.sqlite"
  echo: false
  pool_size: 5
  max_overflow: 10

api:
  gemini_model: "gemini-pro"
  gemini_temperature: 0.7
  gemini_max_tokens: 2000
  perplexity_model: "llama-3.1-sonar-large-128k-online"
  perplexity_temperature: 0.2
  request_timeout: 30
  retry_attempts: 3

vector_store:
  type: "chromadb"
  chromadb_path: "~/.resume_agent/vector_db"
  embedding_model: "all-MiniLM-L6-v2"
  similarity_threshold: 0.7

document:
  max_resume_pages: 2
  default_theme: "professional_classic"
  output_format: "pdf"
  themes:
    - "professional_classic"
    - "modern_minimalist" 
    - "contemporary_professional"
    - "bold_executive"
    - "vibrant_creative"

streamlit:
  port: 8501
  host: "localhost"
  theme:
    primaryColor: "#1f77b4"
    backgroundColor: "#ffffff"
    secondaryBackgroundColor: "#f0f2f6"
    textColor: "#262730"

logging:
  level: "INFO"
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  file: "~/.resume_agent/logs/app.log"
  max_bytes: 10485760  # 10MB
  backup_count: 5

security:
  allowed_file_types:
    - ".pdf"
    - ".doc"
    - ".docx"
    - ".txt"
  max_file_size: 10485760  # 10MB
  rate_limit:
    requests_per_minute: 60
    burst_size: 10

features:
  company_research: true
  job_market_analysis: true
  ats_optimization: true
  cover_letter_generation: true
  ksc_generation: true
  analytics: true
'''

with open("config/app.yaml", "w") as f:
    f.write(config_app_content)

print("✓ Created config/app.yaml")

# Create resume template
resume_template_content = '''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{{ personal_info.full_name }} - Resume</title>
    <style>
        /* Professional Classic Theme CSS */
        body {
            font-family: 'Georgia', serif;
            font-size: 11pt;
            line-height: 1.4;
            margin: 0;
            padding: 40px;
            color: #333;
            background: white;
        }
        
        .header {
            text-align: center;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .name {
            font-size: 24pt;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .contact-info {
            font-size: 10pt;
            color: #666;
        }
        
        .contact-info span {
            margin: 0 10px;
        }
        
        .section {
            margin-bottom: 25px;
        }
        
        .section-title {
            font-size: 14pt;
            font-weight: bold;
            color: #2c3e50;
            border-bottom: 1px solid #3498db;
            padding-bottom: 5px;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .professional-summary {
            font-style: italic;
            text-align: justify;
            margin-bottom: 20px;
            line-height: 1.5;
        }
        
        .experience-item {
            margin-bottom: 20px;
            page-break-inside: avoid;
        }
        
        .job-header {
            display: flex;
            justify-content: space-between;
            align-items: baseline;
            margin-bottom: 5px;
        }
        
        .job-title {
            font-weight: bold;
            font-size: 12pt;
        }
        
        .company-name {
            font-style: italic;
            color: #2c3e50;
        }
        
        .job-dates {
            font-size: 10pt;
            color: #666;
        }
        
        .job-location {
            font-size: 10pt;
            color: #666;
            margin-bottom: 8px;
        }
        
        .achievements {
            list-style: none;
            padding-left: 0;
        }
        
        .achievements li {
            margin-bottom: 5px;
            padding-left: 15px;
            position: relative;
        }
        
        .achievements li:before {
            content: "▸";
            color: #3498db;
            font-weight: bold;
            position: absolute;
            left: 0;
        }
        
        .education-item {
            margin-bottom: 15px;
        }
        
        .degree {
            font-weight: bold;
        }
        
        .institution {
            font-style: italic;
            color: #2c3e50;
        }
        
        .education-dates {
            font-size: 10pt;
            color: #666;
        }
        
        .skills-container {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .skill-category {
            flex: 1;
            min-width: 200px;
        }
        
        .skill-category-title {
            font-weight: bold;
            margin-bottom: 8px;
            color: #2c3e50;
        }
        
        .skill-list {
            font-size: 10pt;
            line-height: 1.4;
        }
        
        .projects-item {
            margin-bottom: 15px;
        }
        
        .project-name {
            font-weight: bold;
            color: #2c3e50;
        }
        
        .project-technologies {
            font-size: 10pt;
            color: #666;
            font-style: italic;
        }
        
        .project-description {
            margin-top: 5px;
            font-size: 10pt;
        }
        
        @media print {
            body {
                padding: 20px;
            }
            
            .page-break {
                page-break-before: always;
            }
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <div class="header">
        <div class="name">{{ personal_info.full_name }}</div>
        <div class="contact-info">
            {% if personal_info.email %}<span>📧 {{ personal_info.email }}</span>{% endif %}
            {% if personal_info.phone %}<span>📞 {{ personal_info.phone }}</span>{% endif %}
            {% if personal_info.location %}<span>📍 {{ personal_info.location }}</span>{% endif %}
            {% if personal_info.linkedin_url %}<span>💼 {{ personal_info.linkedin_url }}</span>{% endif %}
            {% if personal_info.github_url %}<span>🔗 {{ personal_info.github_url }}</span>{% endif %}
        </div>
    </div>

    <!-- Professional Summary -->
    {% if professional_summary %}
    <div class="section">
        <div class="section-title">Professional Summary</div>
        <div class="professional-summary">{{ professional_summary }}</div>
    </div>
    {% endif %}

    <!-- Work Experience -->
    {% if work_experiences %}
    <div class="section">
        <div class="section-title">Professional Experience</div>
        {% for experience in work_experiences %}
        <div class="experience-item">
            <div class="job-header">
                <div>
                    <span class="job-title">{{ experience.job_title }}</span>
                    <span class="company-name"> - {{ experience.company_name }}</span>
                </div>
                <div class="job-dates">{{ experience.start_date }} - {{ experience.end_date or 'Present' }}</div>
            </div>
            {% if experience.location %}
            <div class="job-location">📍 {{ experience.location }}</div>
            {% endif %}
            
            {% if experience.description %}
            <div style="margin-bottom: 8px; font-size: 10pt;">{{ experience.description }}</div>
            {% endif %}
            
            {% if experience.achievements %}
            <ul class="achievements">
                {% for achievement in experience.achievements %}
                <li>{{ achievement }}</li>
                {% endfor %}
            </ul>
            {% endif %}
            
            {% if experience.technologies %}
            <div style="margin-top: 8px; font-size: 10pt; color: #666;">
                <strong>Technologies:</strong> {{ experience.technologies | join(', ') }}
            </div>
            {% endif %}
        </div>
        {% endfor %}
    </div>
    {% endif %}

    <!-- Education -->
    {% if educations %}
    <div class="section">
        <div class="section-title">Education</div>
        {% for education in educations %}
        <div class="education-item">
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
                <div>
                    <span class="degree">{{ education.degree }}</span>
                    {% if education.field_of_study %} in {{ education.field_of_study }}{% endif %}
                    <div class="institution">{{ education.institution }}</div>
                </div>
                <div class="education-dates">{{ education.start_date }} - {{ education.end_date or 'Present' }}</div>
            </div>
            {% if education.gpa %}
            <div style="font-size: 10pt; color: #666; margin-top: 5px;">GPA: {{ education.gpa }}</div>
            {% endif %}
            {% if education.achievements %}
            <ul class="achievements" style="margin-top: 8px;">
                {% for achievement in education.achievements %}
                <li>{{ achievement }}</li>
                {% endfor %}
            </ul>
            {% endif %}
        </div>
        {% endfor %}
    </div>
    {% endif %}

    <!-- Skills -->
    {% if skills %}
    <div class="section">
        <div class="section-title">Technical Skills</div>
        <div class="skills-container">
            {% set skill_categories = skills | groupby('category') %}
            {% for category, category_skills in skill_categories %}
            <div class="skill-category">
                <div class="skill-category-title">{{ category or 'General' }}</div>
                <div class="skill-list">
                    {% for skill in category_skills %}
                    {{ skill.name }}{% if skill.proficiency_level %} ({{ skill.proficiency_level }}){% endif %}{% if not loop.last %}, {% endif %}
                    {% endfor %}
                </div>
            </div>
            {% endfor %}
        </div>
    </div>
    {% endif %}

    <!-- Projects -->
    {% if projects %}
    <div class="section">
        <div class="section-title">Key Projects</div>
        {% for project in projects %}
        <div class="projects-item">
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
                <span class="project-name">{{ project.name }}</span>
                {% if project.start_date %}
                <span style="font-size: 10pt; color: #666;">{{ project.start_date }}{% if project.end_date %} - {{ project.end_date }}{% endif %}</span>
                {% endif %}
            </div>
            {% if project.technologies %}
            <div class="project-technologies">{{ project.technologies | join(', ') }}</div>
            {% endif %}
            {% if project.description %}
            <div class="project-description">{{ project.description }}</div>
            {% endif %}
            {% if project.achievements %}
            <ul class="achievements" style="margin-top: 5px;">
                {% for achievement in project.achievements %}
                <li>{{ achievement }}</li>
                {% endfor %}
            </ul>
            {% endif %}
            {% if project.project_url or project.github_url %}
            <div style="font-size: 10pt; margin-top: 5px;">
                {% if project.project_url %}<strong>Project:</strong> {{ project.project_url }}{% endif %}
                {% if project.github_url %}{% if project.project_url %} | {% endif %}<strong>GitHub:</strong> {{ project.github_url }}{% endif %}
            </div>
            {% endif %}
        </div>
        {% endfor %}
    </div>
    {% endif %}
</body>
</html>
'''

with open("templates/resume/professional_classic.html", "w") as f:
    f.write(resume_template_content)

print("✓ Created templates/resume/professional_classic.html")

# Create cover letter template
cover_letter_template_content = '''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cover Letter - {{ personal_info.full_name }}</title>
    <style>
        body {
            font-family: 'Georgia', serif;
            font-size: 12pt;
            line-height: 1.6;
            margin: 0;
            padding: 40px;
            color: #333;
            background: white;
        }
        
        .header {
            margin-bottom: 40px;
        }
        
        .sender-info {
            text-align: right;
            margin-bottom: 30px;
        }
        
        .sender-name {
            font-weight: bold;
            font-size: 14pt;
            margin-bottom: 5px;
        }
        
        .sender-contact {
            font-size: 11pt;
            color: #666;
            line-height: 1.4;
        }
        
        .date {
            text-align: right;
            margin-bottom: 30px;
            font-size: 11pt;
        }
        
        .recipient-info {
            margin-bottom: 30px;
        }
        
        .recipient-info div {
            margin-bottom: 5px;
        }
        
        .salutation {
            margin-bottom: 20px;
            font-weight: bold;
        }
        
        .body-content {
            text-align: justify;
            margin-bottom: 30px;
        }
        
        .body-content p {
            margin-bottom: 15px;
        }
        
        .closing {
            margin-bottom: 60px;
        }
        
        .signature {
            font-weight: bold;
        }
        
        @media print {
            body {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header with sender information -->
    <div class="header">
        <div class="sender-info">
            <div class="sender-name">{{ personal_info.full_name }}</div>
            <div class="sender-contact">
                {% if personal_info.phone %}{{ personal_info.phone }}<br>{% endif %}
                {% if personal_info.email %}{{ personal_info.email }}<br>{% endif %}
                {% if personal_info.location %}{{ personal_info.location }}<br>{% endif %}
                {% if personal_info.linkedin_url %}{{ personal_info.linkedin_url }}{% endif %}
            </div>
        </div>
        
        <div class="date">{{ current_date }}</div>
        
        <div class="recipient-info">
            {% if hiring_manager_name %}
            <div>{{ hiring_manager_name }}</div>
            {% endif %}
            {% if company_name %}
            <div>{{ company_name }}</div>
            {% endif %}
            {% if company_address %}
            <div>{{ company_address }}</div>
            {% endif %}
        </div>
    </div>

    <!-- Salutation -->
    <div class="salutation">
        {% if hiring_manager_name %}
        Dear {{ hiring_manager_name }},
        {% else %}
        Dear Hiring Manager,
        {% endif %}
    </div>

    <!-- Body content -->
    <div class="body-content">
        <!-- Opening paragraph -->
        <p>
            I am writing to express my strong interest in the {{ job_title }} position at {{ company_name }}. 
            {% if referral_source %}I learned about this opportunity through {{ referral_source }}, and {% else %}After researching your company and {% endif %}
            I am excited about the possibility of contributing to {{ company_name }}'s continued success with my 
            {{ years_of_experience }} years of experience in {{ industry_or_field }}.
        </p>

        <!-- Second paragraph - Qualifications and achievements -->
        <p>
            {{ qualification_paragraph | default("In my previous roles, I have developed a strong foundation in the skills and competencies required for this position. My experience includes significant achievements in areas directly relevant to your needs, including measurable results that demonstrate my ability to drive success and add value to your team.") }}
        </p>

        <!-- Third paragraph - Company research and fit -->
        <p>
            {% if company_research %}
            What particularly attracts me to {{ company_name }} is {{ company_research }}. 
            {% else %}
            I am particularly drawn to {{ company_name }}'s commitment to excellence and innovation in the {{ industry_or_field }} sector. 
            {% endif %}
            I believe my background in {{ relevant_skills | join(', ') }} aligns well with your team's objectives, and I am eager to contribute to {{ company_name }}'s mission of {{ company_mission | default("delivering exceptional results") }}.
        </p>

        <!-- Closing paragraph -->
        <p>
            I would welcome the opportunity to discuss how my experience and enthusiasm can contribute to {{ company_name }}'s continued growth. 
            I have attached my resume for your review and look forward to hearing from you soon. Thank you for considering my application.
        </p>
    </div>

    <!-- Closing and signature -->
    <div class="closing">
        <div style="margin-bottom: 10px;">Sincerely,</div>
        <div class="signature">{{ personal_info.full_name }}</div>
    </div>
</body>
</html>
'''

with open("templates/cover_letter/professional_standard.html", "w") as f:
    f.write(cover_letter_template_content)

print("✓ Created templates/cover_letter/professional_standard.html")

# Create KSC template for Australian government applications
ksc_template_content = '''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Key Selection Criteria Response - {{ personal_info.full_name }}</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            font-size: 11pt;
            line-height: 1.5;
            margin: 0;
            padding: 40px;
            color: #333;
            background: white;
        }
        
        .header {
            text-align: center;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .applicant-name {
            font-size: 18pt;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .position-info {
            font-size: 12pt;
            color: #666;
            margin-bottom: 20px;
        }
        
        .ksc-item {
            margin-bottom: 40px;
            page-break-inside: avoid;
        }
        
        .ksc-criterion {
            font-weight: bold;
            font-size: 12pt;
            color: #2c3e50;
            margin-bottom: 15px;
            padding: 10px;
            background-color: #f8f9fa;
            border-left: 4px solid #3498db;
        }
        
        .star-section {
            margin-bottom: 20px;
        }
        
        .star-header {
            font-weight: bold;
            color: #34495e;
            margin-bottom: 8px;
            text-transform: uppercase;
            font-size: 10pt;
            letter-spacing: 1px;
        }
        
        .star-content {
            text-align: justify;
            margin-bottom: 12px;
            padding-left: 15px;
            border-left: 2px solid #ecf0f1;
        }
        
        .evidence-section {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            margin-top: 15px;
        }
        
        .evidence-header {
            font-weight: bold;
            color: #27ae60;
            margin-bottom: 8px;
        }
        
        .word-count {
            font-size: 9pt;
            color: #666;
            text-align: right;
            font-style: italic;
            margin-top: 10px;
        }
        
        @media print {
            body {
                padding: 20px;
            }
            
            .page-break {
                page-break-before: always;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="applicant-name">{{ personal_info.full_name }}</div>
        <div class="position-info">
            {% if position_title %}Position: {{ position_title }}<br>{% endif %}
            {% if reference_number %}Reference: {{ reference_number }}<br>{% endif %}
            {% if agency_name %}Agency: {{ agency_name }}{% endif %}
        </div>
        <div style="font-size: 14pt; font-weight: bold; margin-top: 15px;">
            KEY SELECTION CRITERIA RESPONSE
        </div>
    </div>

    <!-- KSC Responses -->
    {% for ksc in key_selection_criteria %}
    <div class="ksc-item">
        <div class="ksc-criterion">
            {{ loop.index }}. {{ ksc.criterion_text }}
        </div>

        <!-- STAR Method Response -->
        {% if ksc.star_response %}
        
        <!-- Situation -->
        {% if ksc.star_response.situation %}
        <div class="star-section">
            <div class="star-header">Situation</div>
            <div class="star-content">{{ ksc.star_response.situation }}</div>
        </div>
        {% endif %}

        <!-- Task -->
        {% if ksc.star_response.task %}
        <div class="star-section">
            <div class="star-header">Task</div>
            <div class="star-content">{{ ksc.star_response.task }}</div>
        </div>
        {% endif %}

        <!-- Action -->
        {% if ksc.star_response.action %}
        <div class="star-section">
            <div class="star-header">Action</div>
            <div class="star-content">{{ ksc.star_response.action }}</div>
        </div>
        {% endif %}

        <!-- Result -->
        {% if ksc.star_response.result %}
        <div class="star-section">
            <div class="star-header">Result</div>
            <div class="star-content">{{ ksc.star_response.result }}</div>
        </div>
        {% endif %}

        {% else %}
        <!-- Free-form response if STAR method not used -->
        <div class="star-content">
            {{ ksc.response_text | default("Response to be completed...") }}
        </div>
        {% endif %}

        <!-- Supporting Evidence -->
        {% if ksc.supporting_evidence %}
        <div class="evidence-section">
            <div class="evidence-header">Supporting Evidence:</div>
            {% for evidence in ksc.supporting_evidence %}
            <div style="margin-bottom: 8px;">• {{ evidence }}</div>
            {% endfor %}
        </div>
        {% endif %}

        <!-- Word count -->
        {% if ksc.word_count %}
        <div class="word-count">Word count: {{ ksc.word_count }}</div>
        {% endif %}
    </div>
    {% endfor %}

    <!-- Footer with contact information -->
    <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ccc;">
        <div style="text-align: center; font-size: 10pt; color: #666;">
            {{ personal_info.full_name }} | 
            {% if personal_info.phone %}{{ personal_info.phone }} | {% endif %}
            {% if personal_info.email %}{{ personal_info.email }}{% endif %}
        </div>
    </div>
</body>
</html>
'''

with open("templates/ksc/australian_government.html", "w") as f:
    f.write(ksc_template_content)

print("✓ Created templates/ksc/australian_government.html")