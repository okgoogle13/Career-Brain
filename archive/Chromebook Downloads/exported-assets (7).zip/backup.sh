#!/bin/bash

# Enhanced Resume Agent 3.0 - Backup Script
# Creates a backup of all user data

BACKUP_DIR="$HOME/.resume_agent_backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="resume_agent_backup_$TIMESTAMP.tar.gz"

echo "📦 Creating backup of Enhanced Resume Agent data..."

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Create backup
if [ -d "$HOME/.resume_agent" ]; then
    tar -czf "$BACKUP_DIR/$BACKUP_FILE" -C "$HOME" .resume_agent
    echo "✅ Backup created: $BACKUP_DIR/$BACKUP_FILE"

    # Show backup info
    BACKUP_SIZE=$(du -h "$BACKUP_DIR/$BACKUP_FILE" | cut -f1)
    echo "📊 Backup size: $BACKUP_SIZE"
    echo "📂 Location: $BACKUP_DIR/$BACKUP_FILE"

    # List contents
    echo ""
    echo "📋 Backup contents:"
    tar -tzf "$BACKUP_DIR/$BACKUP_FILE" | head -10
    if [ $(tar -tzf "$BACKUP_DIR/$BACKUP_FILE" | wc -l) -gt 10 ]; then
        echo "   ... and more"
    fi

else
    echo "❌ No Resume Agent data found at $HOME/.resume_agent"
    exit 1
fi
