"""
Database connection and session management.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
from contextlib import contextmanager
from pathlib import Path
import logging

from .models import Base, create_tables
from ..utils.config import config

logger = logging.getLogger(__name__)

class DatabaseManager:
    """Manage database connections and sessions."""

    def __init__(self, database_url: str = None):
        """Initialize database manager."""
        self.database_url = database_url or config.database.url
        self.engine = None
        self.SessionLocal = None
        self._initialize_engine()

    def _initialize_engine(self):
        """Initialize database engine."""
        try:
            # Expand user path for SQLite
            if self.database_url.startswith("sqlite:///"):
                db_path = self.database_url.replace("sqlite:///", "")
                db_path = Path(db_path).expanduser()
                db_path.parent.mkdir(parents=True, exist_ok=True)
                self.database_url = f"sqlite:///{db_path}"

            # Create engine with appropriate configuration
            if "sqlite" in self.database_url:
                self.engine = create_engine(
                    self.database_url,
                    connect_args={"check_same_thread": False},
                    poolclass=StaticPool,
                    echo=config.database.echo
                )
            else:
                self.engine = create_engine(
                    self.database_url,
                    echo=config.database.echo
                )

            # Create session factory
            self.SessionLocal = sessionmaker(
                autocommit=False,
                autoflush=False,
                bind=self.engine
            )

            # Create tables
            create_tables(self.engine)
            logger.info("Database initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize database: {e}")
            raise

    @contextmanager
    def get_session(self):
        """Get database session with context manager."""
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Database session error: {e}")
            raise
        finally:
            session.close()

    def get_session_direct(self) -> Session:
        """Get database session directly (remember to close)."""
        return self.SessionLocal()

    def close(self):
        """Close database connections."""
        if self.engine:
            self.engine.dispose()

# Global database manager instance
db_manager = DatabaseManager()

# Convenience function for getting database sessions
def get_db_session():
    """Get database session (for dependency injection)."""
    return db_manager.get_session_direct()
