# 6. Create validators and file handlers utilities
validators_content = '''"""
Validation utilities for Enhanced Resume Agent 3.0.
"""

import re
from typing import Optional
from urllib.parse import urlparse

def validate_email(email: str) -> bool:
    """Validate email address format."""
    if not email or not isinstance(email, str):
        return False
    
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_phone(phone: str) -> bool:
    """Validate phone number format."""
    if not phone or not isinstance(phone, str):
        return False
    
    # Remove common separators
    cleaned = re.sub(r'[\\s\\-\\(\\)\\+]', '', phone)
    
    # Check if it's all digits and reasonable length
    return cleaned.isdigit() and 7 <= len(cleaned) <= 15

def validate_url(url: str) -> bool:
    """Validate URL format."""
    if not url or not isinstance(url, str):
        return False
    
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except Exception:
        return False

def validate_linkedin_url(url: str) -> bool:
    """Validate LinkedIn URL format."""
    if not validate_url(url):
        return False
    
    return 'linkedin.com' in url.lower()

def validate_github_url(url: str) -> bool:
    """Validate GitHub URL format."""
    if not validate_url(url):
        return False
    
    return 'github.com' in url.lower()

def validate_name(name: str) -> bool:
    """Validate name format."""
    if not name or not isinstance(name, str):
        return False
    
    # Name should contain only letters, spaces, hyphens, and apostrophes
    pattern = r"^[a-zA-Z\\s\\-\\']+$"
    return re.match(pattern, name.strip()) is not None and len(name.strip()) >= 2

def validate_job_title(title: str) -> bool:
    """Validate job title format."""
    if not title or not isinstance(title, str):
        return False
    
    # Job title should be reasonable length and contain valid characters
    cleaned = title.strip()
    return 2 <= len(cleaned) <= 100 and not cleaned.isdigit()

def validate_company_name(company: str) -> bool:
    """Validate company name format."""
    if not company or not isinstance(company, str):
        return False
    
    # Company name should be reasonable length
    cleaned = company.strip()
    return 1 <= len(cleaned) <= 100

def validate_date_range(start_date: str, end_date: Optional[str] = None) -> bool:
    """Validate date range format (YYYY-MM or YYYY)."""
    date_pattern = r'^\\d{4}(-\\d{2})?$'
    
    if not re.match(date_pattern, start_date):
        return False
    
    if end_date and end_date.lower() != 'present':
        if not re.match(date_pattern, end_date):
            return False
        
        # Basic date comparison (simplified)
        start_year = int(start_date[:4])
        end_year = int(end_date[:4])
        
        if end_year < start_year:
            return False
    
    return True
'''

with open("src/utils/validators.py", "w") as f:
    f.write(validators_content)

print("✓ Created src/utils/validators.py")

# Create file handlers utility
file_handlers_content = '''"""
File handling utilities for Enhanced Resume Agent 3.0.
"""

import os
import json
import yaml
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from PyPDF2 import PdfReader
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
import logging

logger = logging.getLogger(__name__)

class PDFHandler:
    """Handle PDF operations for resume processing."""
    
    @staticmethod
    def extract_text_from_pdf(file_path: Union[str, Path]) -> str:
        """Extract text content from PDF file."""
        try:
            with open(file_path, 'rb') as file:
                pdf_reader = PdfReader(file)
                text = ""
                
                for page in pdf_reader.pages:
                    text += page.extract_text() + "\\n"
                
                return text.strip()
                
        except Exception as e:
            logger.error(f"Error extracting text from PDF {file_path}: {e}")
            return ""
    
    @staticmethod
    def create_simple_pdf(content: str, output_path: Union[str, Path]) -> bool:
        """Create a simple PDF from text content."""
        try:
            doc = SimpleDocTemplate(str(output_path), pagesize=letter)
            styles = getSampleStyleSheet()
            story = []
            
            # Split content into paragraphs
            paragraphs = content.split('\\n\\n')
            
            for para in paragraphs:
                if para.strip():
                    p = Paragraph(para.strip(), styles['Normal'])
                    story.append(p)
                    story.append(Spacer(1, 12))
            
            doc.build(story)
            return True
            
        except Exception as e:
            logger.error(f"Error creating PDF {output_path}: {e}")
            return False

class DocumentProcessor:
    """Process various document formats."""
    
    @staticmethod
    def load_json(file_path: Union[str, Path]) -> Optional[Dict[str, Any]]:
        """Load JSON file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading JSON {file_path}: {e}")
            return None
    
    @staticmethod
    def save_json(data: Dict[str, Any], file_path: Union[str, Path]) -> bool:
        """Save data to JSON file."""
        try:
            # Ensure directory exists
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            logger.error(f"Error saving JSON {file_path}: {e}")
            return False
    
    @staticmethod
    def load_yaml(file_path: Union[str, Path]) -> Optional[Dict[str, Any]]:
        """Load YAML file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Error loading YAML {file_path}: {e}")
            return None
    
    @staticmethod
    def save_yaml(data: Dict[str, Any], file_path: Union[str, Path]) -> bool:
        """Save data to YAML file."""
        try:
            # Ensure directory exists
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, default_flow_style=False, allow_unicode=True)
            return True
        except Exception as e:
            logger.error(f"Error saving YAML {file_path}: {e}")
            return False
    
    @staticmethod
    def read_text_file(file_path: Union[str, Path]) -> Optional[str]:
        """Read text file content."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            logger.error(f"Error reading text file {file_path}: {e}")
            return None
    
    @staticmethod
    def write_text_file(content: str, file_path: Union[str, Path]) -> bool:
        """Write content to text file."""
        try:
            # Ensure directory exists
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception as e:
            logger.error(f"Error writing text file {file_path}: {e}")
            return False

def ensure_directory(path: Union[str, Path]) -> Path:
    """Ensure directory exists and return Path object."""
    path_obj = Path(path)
    path_obj.mkdir(parents=True, exist_ok=True)
    return path_obj

def get_file_extension(file_path: Union[str, Path]) -> str:
    """Get file extension from file path."""
    return Path(file_path).suffix.lower()

def is_valid_file_type(file_path: Union[str, Path], allowed_extensions: List[str]) -> bool:
    """Check if file has valid extension."""
    extension = get_file_extension(file_path)
    return extension in [ext.lower() for ext in allowed_extensions]
'''

with open("src/utils/file_handlers.py", "w") as f:
    f.write(file_handlers_content)

print("✓ Created src/utils/file_handlers.py")