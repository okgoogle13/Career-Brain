# 7. Create data models using SQLAlchemy
models_content = '''"""
Database models for Enhanced Resume Agent 3.0.
"""

from datetime import datetime
from typing import Optional, List
from sqlalchemy import (
    Column, Integer, String, Text, DateTime, Boolean, ForeignKey, JSON
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, Session
from sqlalchemy.sql import func

Base = declarative_base()

class User(Base):
    """User model for personal use (single user system)."""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True)
    full_name = Column(String(255), nullable=False)
    phone = Column(String(50))
    linkedin_url = Column(String(500))
    github_url = Column(String(500))
    portfolio_url = Column(String(500))
    location = Column(String(255))
    professional_summary = Column(Text)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    resumes = relationship("Resume", back_populates="user", cascade="all, delete-orphan")
    cover_letters = relationship("CoverLetter", back_populates="user", cascade="all, delete-orphan")
    job_applications = relationship("JobApplication", back_populates="user", cascade="all, delete-orphan")
    work_experiences = relationship("WorkExperience", back_populates="user", cascade="all, delete-orphan")
    educations = relationship("Education", back_populates="user", cascade="all, delete-orphan")
    skills = relationship("Skill", back_populates="user", cascade="all, delete-orphan")
    projects = relationship("Project", back_populates="user", cascade="all, delete-orphan")

class WorkExperience(Base):
    """Work experience model."""
    __tablename__ = "work_experiences"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    company_name = Column(String(255), nullable=False)
    job_title = Column(String(255), nullable=False)
    start_date = Column(String(50), nullable=False)  # Format: YYYY-MM or YYYY
    end_date = Column(String(50))  # Format: YYYY-MM, YYYY, or "Present"
    location = Column(String(255))
    description = Column(Text)
    achievements = Column(JSON)  # List of achievement strings
    technologies = Column(JSON)  # List of technologies used
    is_current = Column(Boolean, default=False)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="work_experiences")

class Education(Base):
    """Education model."""
    __tablename__ = "educations"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    institution = Column(String(255), nullable=False)
    degree = Column(String(255), nullable=False)
    field_of_study = Column(String(255))
    start_date = Column(String(50))
    end_date = Column(String(50))
    gpa = Column(String(10))
    location = Column(String(255))
    description = Column(Text)
    achievements = Column(JSON)  # List of academic achievements
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="educations")

class Skill(Base):
    """Skills model."""
    __tablename__ = "skills"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(255), nullable=False)
    category = Column(String(100))  # e.g., "Technical", "Soft Skills", "Languages"
    proficiency_level = Column(String(50))  # e.g., "Beginner", "Intermediate", "Advanced", "Expert"
    years_experience = Column(Integer)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="skills")

class Project(Base):
    """Projects model."""
    __tablename__ = "projects"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    start_date = Column(String(50))
    end_date = Column(String(50))
    project_url = Column(String(500))
    github_url = Column(String(500))
    technologies = Column(JSON)  # List of technologies used
    achievements = Column(JSON)  # List of project achievements
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="projects")

class Resume(Base):
    """Resume model."""
    __tablename__ = "resumes"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    title = Column(String(255), nullable=False)
    theme = Column(String(100), default="professional_classic")
    content = Column(JSON)  # Structured resume content
    pdf_path = Column(String(500))
    ats_score = Column(Integer)
    target_job_title = Column(String(255))
    target_company = Column(String(255))
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="resumes")

class CoverLetter(Base):
    """Cover letter model."""
    __tablename__ = "cover_letters"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    job_application_id = Column(Integer, ForeignKey("job_applications.id"))
    title = Column(String(255), nullable=False)
    content = Column(Text, nullable=False)
    pdf_path = Column(String(500))
    target_job_title = Column(String(255))
    target_company = Column(String(255))
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="cover_letters")
    job_application = relationship("JobApplication", back_populates="cover_letter")

class JobApplication(Base):
    """Job application tracking model."""
    __tablename__ = "job_applications"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    company_name = Column(String(255), nullable=False)
    job_title = Column(String(255), nullable=False)
    job_url = Column(String(500))
    job_description = Column(Text)
    status = Column(String(50), default="draft")  # draft, applied, interview, rejected, offer
    application_date = Column(DateTime(timezone=True))
    notes = Column(Text)
    
    # Company research data
    company_research = Column(JSON)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="job_applications")
    cover_letter = relationship("CoverLetter", back_populates="job_application", uselist=False)

# Database utility functions
def create_tables(engine):
    """Create all database tables."""
    Base.metadata.create_all(bind=engine)

def get_or_create_user(session: Session, email: str, full_name: str) -> User:
    """Get existing user or create new one."""
    user = session.query(User).filter(User.email == email).first()
    if not user:
        user = User(email=email, full_name=full_name)
        session.add(user)
        session.commit()
        session.refresh(user)
    return user
'''

with open("src/data/models.py", "w") as f:
    f.write(models_content)

print("✓ Created src/data/models.py")

# Create database connection manager
database_content = '''"""
Database connection and session management.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
from contextlib import contextmanager
from pathlib import Path
import logging

from .models import Base, create_tables
from ..utils.config import config

logger = logging.getLogger(__name__)

class DatabaseManager:
    """Manage database connections and sessions."""
    
    def __init__(self, database_url: str = None):
        """Initialize database manager."""
        self.database_url = database_url or config.database.url
        self.engine = None
        self.SessionLocal = None
        self._initialize_engine()
    
    def _initialize_engine(self):
        """Initialize database engine."""
        try:
            # Expand user path for SQLite
            if self.database_url.startswith("sqlite:///"):
                db_path = self.database_url.replace("sqlite:///", "")
                db_path = Path(db_path).expanduser()
                db_path.parent.mkdir(parents=True, exist_ok=True)
                self.database_url = f"sqlite:///{db_path}"
            
            # Create engine with appropriate configuration
            if "sqlite" in self.database_url:
                self.engine = create_engine(
                    self.database_url,
                    connect_args={"check_same_thread": False},
                    poolclass=StaticPool,
                    echo=config.database.echo
                )
            else:
                self.engine = create_engine(
                    self.database_url,
                    echo=config.database.echo
                )
            
            # Create session factory
            self.SessionLocal = sessionmaker(
                autocommit=False,
                autoflush=False,
                bind=self.engine
            )
            
            # Create tables
            create_tables(self.engine)
            logger.info("Database initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize database: {e}")
            raise
    
    @contextmanager
    def get_session(self):
        """Get database session with context manager."""
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Database session error: {e}")
            raise
        finally:
            session.close()
    
    def get_session_direct(self) -> Session:
        """Get database session directly (remember to close)."""
        return self.SessionLocal()
    
    def close(self):
        """Close database connections."""
        if self.engine:
            self.engine.dispose()

# Global database manager instance
db_manager = DatabaseManager()

# Convenience function for getting database sessions
def get_db_session():
    """Get database session (for dependency injection)."""
    return db_manager.get_session_direct()
'''

with open("src/data/database.py", "w") as f:
    f.write(database_content)

print("✓ Created src/data/database.py")