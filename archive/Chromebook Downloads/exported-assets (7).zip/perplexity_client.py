"""
Perplexity API integration for Enhanced Resume Agent 3.0.
"""

import json
import logging
import time
from typing import Optional, Dict, Any, List
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from ..utils.config import config

logger = logging.getLogger(__name__)

class PerplexityClient:
    """Client for Perplexity API integration."""

    def __init__(self, api_key: str = None):
        """Initialize Perplexity client."""
        self.api_key = api_key or config.api.perplexity_api_key
        self.base_url = "https://api.perplexity.ai"

        if not self.api_key:
            raise ValueError("Perplexity API key is required")

        # Setup session with retry strategy
        self.session = requests.Session()
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

        # Default headers
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        })

        logger.info("Perplexity client initialized")

    def chat_completion(
        self,
        messages: List[Dict[str, str]],
        model: str = "llama-3.1-sonar-small-128k-online",
        temperature: float = 0.2,
        max_tokens: int = 1000,
        timeout: int = 30
    ) -> Optional[str]:
        """Make a chat completion request to Perplexity API."""
        try:
            url = f"{self.base_url}/chat/completions"

            payload = {
                "model": model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
                "return_citations": True,
                "return_images": False
            }

            response = self.session.post(
                url,
                json=payload,
                timeout=timeout
            )

            if response.status_code == 200:
                result = response.json()
                if "choices" in result and result["choices"]:
                    content = result["choices"][0]["message"]["content"]
                    logger.debug(f"Perplexity generated {len(content)} characters")
                    return content
                else:
                    logger.error("No choices in Perplexity response")
                    return None
            else:
                logger.error(f"Perplexity API error: {response.status_code} - {response.text}")
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Perplexity API request error: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error in Perplexity API call: {e}")
            return None

    def research_company(
        self,
        company_name: str,
        include_recent_news: bool = True
    ) -> Optional[Dict[str, Any]]:
        """Research a company using Perplexity's web search capabilities."""
        try:
            research_query = f"""
            Research the company "{company_name}" and provide the following information:

            1. Company Overview (what they do, industry, size)
            2. Mission and Values
            3. Recent News and Developments (if any)
            4. Company Culture and Work Environment
            5. Key Products or Services
            6. Leadership Team (CEO, key executives)
            7. Recent Hiring Trends or Job Opportunities

            Please provide current, factual information with sources when possible.
            """

            if not include_recent_news:
                research_query = research_query.replace("3. Recent News and Developments (if any)\n", "")

            messages = [
                {
                    "role": "system",
                    "content": "You are a professional researcher helping job seekers learn about companies. Provide accurate, current information with proper citations."
                },
                {
                    "role": "user",
                    "content": research_query
                }
            ]

            result = self.chat_completion(
                messages=messages,
                model="llama-3.1-sonar-large-128k-online",
                temperature=0.1,
                max_tokens=2000
            )

            if result:
                return {
                    "company_name": company_name,
                    "research_content": result,
                    "research_date": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "source": "perplexity_api"
                }

            return None

        except Exception as e:
            logger.error(f"Error researching company {company_name}: {e}")
            return None

    def analyze_job_market(
        self,
        job_title: str,
        location: str = None,
        industry: str = None
    ) -> Optional[Dict[str, Any]]:
        """Analyze job market trends for a specific role."""
        try:
            location_part = f" in {location}" if location else ""
            industry_part = f" in the {industry} industry" if industry else ""

            market_query = f"""
            Analyze the current job market for "{job_title}"{location_part}{industry_part}. Provide:

            1. Average salary ranges
            2. In-demand skills and qualifications
            3. Market demand and growth trends
            4. Top hiring companies
            5. Remote work opportunities
            6. Career progression paths
            7. Education/certification requirements

            Use current data and market trends.
            """

            messages = [
                {
                    "role": "system",
                    "content": "You are a career market analyst providing current job market insights with accurate salary and trend data."
                },
                {
                    "role": "user",
                    "content": market_query
                }
            ]

            result = self.chat_completion(
                messages=messages,
                model="llama-3.1-sonar-large-128k-online",
                temperature=0.1,
                max_tokens=1500
            )

            if result:
                return {
                    "job_title": job_title,
                    "location": location,
                    "industry": industry,
                    "market_analysis": result,
                    "analysis_date": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "source": "perplexity_api"
                }

            return None

        except Exception as e:
            logger.error(f"Error analyzing job market for {job_title}: {e}")
            return None

    def research_industry_trends(
        self,
        industry: str,
        focus_areas: List[str] = None
    ) -> Optional[str]:
        """Research current trends in a specific industry."""
        try:
            focus_text = ""
            if focus_areas:
                focus_text = f" Focus particularly on: {', '.join(focus_areas)}."

            trends_query = f"""
            Research current trends and developments in the {industry} industry.{focus_text}

            Include information about:
            1. Emerging technologies and innovations
            2. Market challenges and opportunities
            3. Skills in high demand
            4. Key players and market leaders
            5. Future outlook and predictions

            Provide recent, factual information with sources.
            """

            messages = [
                {
                    "role": "system",
                    "content": "You are an industry analyst providing current market intelligence and trend analysis."
                },
                {
                    "role": "user",
                    "content": trends_query
                }
            ]

            return self.chat_completion(
                messages=messages,
                model="llama-3.1-sonar-large-128k-online",
                temperature=0.1,
                max_tokens=1500
            )

        except Exception as e:
            logger.error(f"Error researching industry trends for {industry}: {e}")
            return None

    def find_similar_companies(
        self,
        company_name: str,
        industry: str = None,
        size: str = None
    ) -> Optional[List[str]]:
        """Find companies similar to the target company."""
        try:
            size_filter = f" of similar size ({size})" if size else ""
            industry_filter = f" in the {industry} industry" if industry else ""

            similarity_query = f"""
            Find 5-10 companies similar to "{company_name}"{industry_filter}{size_filter}.

            Consider companies that:
            1. Operate in similar markets or industries
            2. Have comparable business models
            3. Are competitors or partners
            4. Have similar company culture or values
            5. Target similar customer segments

            Provide just the company names in a numbered list.
            """

            messages = [
                {
                    "role": "system",
                    "content": "You are a business analyst helping identify competitor and similar companies."
                },
                {
                    "role": "user",
                    "content": similarity_query
                }
            ]

            result = self.chat_completion(
                messages=messages,
                temperature=0.1,
                max_tokens=500
            )

            if result:
                # Extract company names from the response
                lines = [line.strip() for line in result.split('\n') if line.strip()]
                companies = []
                for line in lines:
                    # Remove numbering and extract company name
                    clean_line = line.split('.', 1)[-1].strip()
                    if clean_line and len(clean_line) > 1:
                        companies.append(clean_line)

                return companies[:10]  # Limit to 10 companies

            return None

        except Exception as e:
            logger.error(f"Error finding similar companies to {company_name}: {e}")
            return None

# Global Perplexity client instance
try:
    perplexity_client = PerplexityClient()
except ValueError as e:
    logger.warning(f"Perplexity client not initialized: {e}")
    perplexity_client = None
