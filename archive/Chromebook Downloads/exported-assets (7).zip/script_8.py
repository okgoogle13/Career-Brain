# 9. Create API integration clients for Gemini and Perplexity
gemini_client_content = '''"""
Google Gemini API integration for Enhanced Resume Agent 3.0.
"""

import json
import logging
import time
from typing import Optional, Dict, Any, List
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from ..utils.config import config

logger = logging.getLogger(__name__)

class GeminiClient:
    """Client for Google Gemini API integration."""
    
    def __init__(self, api_key: str = None):
        """Initialize Gemini client."""
        self.api_key = api_key or config.api.gemini_api_key
        self.base_url = "https://generativelanguage.googleapis.com/v1beta"
        
        if not self.api_key:
            raise ValueError("Google Gemini API key is required")
        
        # Setup session with retry strategy
        self.session = requests.Session()
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        logger.info("Gemini client initialized")
    
    def generate_content(
        self,
        prompt: str,
        model: str = "gemini-pro",
        temperature: float = 0.7,
        max_tokens: int = 1000,
        timeout: int = 30
    ) -> Optional[str]:
        """Generate content using Gemini API."""
        try:
            url = f"{self.base_url}/models/{model}:generateContent"
            
            headers = {
                "Content-Type": "application/json",
                "x-goog-api-key": self.api_key
            }
            
            payload = {
                "contents": [
                    {
                        "parts": [
                            {
                                "text": prompt
                            }
                        ]
                    }
                ],
                "generationConfig": {
                    "temperature": temperature,
                    "maxOutputTokens": max_tokens,
                    "topP": 0.8,
                    "topK": 10
                }
            }
            
            response = self.session.post(
                url,
                headers=headers,
                json=payload,
                timeout=timeout
            )
            
            if response.status_code == 200:
                result = response.json()
                if "candidates" in result and result["candidates"]:
                    content = result["candidates"][0]["content"]["parts"][0]["text"]
                    logger.debug(f"Gemini generated {len(content)} characters")
                    return content
                else:
                    logger.error("No candidates in Gemini response")
                    return None
            else:
                logger.error(f"Gemini API error: {response.status_code} - {response.text}")
                return None
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Gemini API request error: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error in Gemini API call: {e}")
            return None
    
    def optimize_resume_content(
        self,
        resume_content: str,
        job_description: str,
        target_job_title: str = None
    ) -> Optional[str]:
        """Optimize resume content for a specific job."""
        try:
            prompt = f"""
            As an expert resume writer and ATS optimization specialist, please optimize this resume content for the following job opportunity.

            TARGET JOB TITLE: {target_job_title or "Not specified"}

            JOB DESCRIPTION:
            {job_description}

            CURRENT RESUME CONTENT:
            {resume_content}

            Please provide an optimized version that:
            1. Incorporates relevant keywords from the job description
            2. Emphasizes achievements and skills that match the job requirements
            3. Uses action verbs and quantifiable results
            4. Maintains professional tone and readability
            5. Ensures ATS compatibility

            Return only the optimized resume content without additional commentary.
            """
            
            return self.generate_content(
                prompt=prompt,
                temperature=0.3,  # Lower temperature for more focused output
                max_tokens=2000
            )
            
        except Exception as e:
            logger.error(f"Error optimizing resume content: {e}")
            return None
    
    def generate_achievement_bullets(
        self,
        job_title: str,
        company: str,
        job_description: str,
        achievements: List[str] = None
    ) -> Optional[List[str]]:
        """Generate achievement bullet points for a work experience."""
        try:
            achievements_text = "\\n".join(achievements) if achievements else "No specific achievements provided"
            
            prompt = f"""
            As an expert resume writer, create 3-5 compelling achievement bullet points for this work experience:

            JOB TITLE: {job_title}
            COMPANY: {company}
            JOB DESCRIPTION/RESPONSIBILITIES: {job_description}
            EXISTING ACHIEVEMENTS: {achievements_text}

            Guidelines:
            1. Start each bullet with a strong action verb
            2. Include quantifiable results where possible (numbers, percentages, dollars)
            3. Focus on achievements, not just responsibilities
            4. Keep each bullet to 1-2 lines
            5. Use relevant industry keywords

            Return only the bullet points, one per line, without numbers or dashes.
            """
            
            result = self.generate_content(
                prompt=prompt,
                temperature=0.4,
                max_tokens=800
            )
            
            if result:
                # Split into individual bullets and clean up
                bullets = [line.strip() for line in result.split('\\n') if line.strip()]
                return bullets[:5]  # Limit to 5 bullets
            
            return None
            
        except Exception as e:
            logger.error(f"Error generating achievement bullets: {e}")
            return None
    
    def score_ats_compatibility(
        self,
        resume_content: str,
        job_description: str
    ) -> Optional[Dict[str, Any]]:
        """Score resume ATS compatibility and provide feedback."""
        try:
            prompt = f"""
            As an ATS (Applicant Tracking System) expert, analyze this resume's compatibility with the job description and provide a score and feedback.

            JOB DESCRIPTION:
            {job_description}

            RESUME CONTENT:
            {resume_content}

            Please analyze and return a JSON response with:
            {{
                "ats_score": <number between 0-100>,
                "keyword_matches": ["list", "of", "matched", "keywords"],
                "missing_keywords": ["list", "of", "important", "missing", "keywords"],
                "recommendations": ["list", "of", "specific", "improvement", "suggestions"],
                "formatting_issues": ["list", "of", "formatting", "problems", "if", "any"]
            }}

            Consider factors like keyword density, relevant skills, experience alignment, and formatting.
            """
            
            result = self.generate_content(
                prompt=prompt,
                temperature=0.2,
                max_tokens=1000
            )
            
            if result:
                try:
                    # Try to parse JSON response
                    return json.loads(result)
                except json.JSONDecodeError:
                    logger.error("Failed to parse JSON from ATS scoring response")
                    return None
            
            return None
            
        except Exception as e:
            logger.error(f"Error scoring ATS compatibility: {e}")
            return None
    
    def generate_professional_summary(
        self,
        work_experiences: List[Dict],
        skills: List[str],
        target_job_title: str = None
    ) -> Optional[str]:
        """Generate a professional summary for the resume."""
        try:
            experiences_text = "\\n".join([
                f"- {exp.get('job_title', '')} at {exp.get('company_name', '')}"
                for exp in work_experiences[:3]  # Latest 3 experiences
            ])
            
            skills_text = ", ".join(skills[:10])  # Top 10 skills
            
            prompt = f"""
            Write a compelling professional summary (2-3 sentences) for a resume based on this information:

            TARGET JOB TITLE: {target_job_title or "General professional"}
            
            RECENT WORK EXPERIENCE:
            {experiences_text}

            KEY SKILLS: {skills_text}

            The summary should:
            1. Highlight years of experience and key expertise areas
            2. Mention most relevant skills for the target role
            3. Include a quantifiable achievement if possible
            4. Be concise and impactful
            5. Use professional tone

            Return only the summary text, no additional formatting or commentary.
            """
            
            return self.generate_content(
                prompt=prompt,
                temperature=0.4,
                max_tokens=200
            )
            
        except Exception as e:
            logger.error(f"Error generating professional summary: {e}")
            return None

# Global Gemini client instance
try:
    gemini_client = GeminiClient()
except ValueError as e:
    logger.warning(f"Gemini client not initialized: {e}")
    gemini_client = None
'''

with open("src/integrations/gemini_client.py", "w") as f:
    f.write(gemini_client_content)

print("✓ Created src/integrations/gemini_client.py")

# Create Perplexity client
perplexity_client_content = '''"""
Perplexity API integration for Enhanced Resume Agent 3.0.
"""

import json
import logging
import time
from typing import Optional, Dict, Any, List
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from ..utils.config import config

logger = logging.getLogger(__name__)

class PerplexityClient:
    """Client for Perplexity API integration."""
    
    def __init__(self, api_key: str = None):
        """Initialize Perplexity client."""
        self.api_key = api_key or config.api.perplexity_api_key
        self.base_url = "https://api.perplexity.ai"
        
        if not self.api_key:
            raise ValueError("Perplexity API key is required")
        
        # Setup session with retry strategy
        self.session = requests.Session()
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        # Default headers
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        })
        
        logger.info("Perplexity client initialized")
    
    def chat_completion(
        self,
        messages: List[Dict[str, str]],
        model: str = "llama-3.1-sonar-small-128k-online",
        temperature: float = 0.2,
        max_tokens: int = 1000,
        timeout: int = 30
    ) -> Optional[str]:
        """Make a chat completion request to Perplexity API."""
        try:
            url = f"{self.base_url}/chat/completions"
            
            payload = {
                "model": model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
                "return_citations": True,
                "return_images": False
            }
            
            response = self.session.post(
                url,
                json=payload,
                timeout=timeout
            )
            
            if response.status_code == 200:
                result = response.json()
                if "choices" in result and result["choices"]:
                    content = result["choices"][0]["message"]["content"]
                    logger.debug(f"Perplexity generated {len(content)} characters")
                    return content
                else:
                    logger.error("No choices in Perplexity response")
                    return None
            else:
                logger.error(f"Perplexity API error: {response.status_code} - {response.text}")
                return None
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Perplexity API request error: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error in Perplexity API call: {e}")
            return None
    
    def research_company(
        self,
        company_name: str,
        include_recent_news: bool = True
    ) -> Optional[Dict[str, Any]]:
        """Research a company using Perplexity's web search capabilities."""
        try:
            research_query = f"""
            Research the company "{company_name}" and provide the following information:
            
            1. Company Overview (what they do, industry, size)
            2. Mission and Values
            3. Recent News and Developments (if any)
            4. Company Culture and Work Environment
            5. Key Products or Services
            6. Leadership Team (CEO, key executives)
            7. Recent Hiring Trends or Job Opportunities
            
            Please provide current, factual information with sources when possible.
            """
            
            if not include_recent_news:
                research_query = research_query.replace("3. Recent News and Developments (if any)\\n", "")
            
            messages = [
                {
                    "role": "system",
                    "content": "You are a professional researcher helping job seekers learn about companies. Provide accurate, current information with proper citations."
                },
                {
                    "role": "user",
                    "content": research_query
                }
            ]
            
            result = self.chat_completion(
                messages=messages,
                model="llama-3.1-sonar-large-128k-online",
                temperature=0.1,
                max_tokens=2000
            )
            
            if result:
                return {
                    "company_name": company_name,
                    "research_content": result,
                    "research_date": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "source": "perplexity_api"
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Error researching company {company_name}: {e}")
            return None
    
    def analyze_job_market(
        self,
        job_title: str,
        location: str = None,
        industry: str = None
    ) -> Optional[Dict[str, Any]]:
        """Analyze job market trends for a specific role."""
        try:
            location_part = f" in {location}" if location else ""
            industry_part = f" in the {industry} industry" if industry else ""
            
            market_query = f"""
            Analyze the current job market for "{job_title}"{location_part}{industry_part}. Provide:
            
            1. Average salary ranges
            2. In-demand skills and qualifications
            3. Market demand and growth trends
            4. Top hiring companies
            5. Remote work opportunities
            6. Career progression paths
            7. Education/certification requirements
            
            Use current data and market trends.
            """
            
            messages = [
                {
                    "role": "system",
                    "content": "You are a career market analyst providing current job market insights with accurate salary and trend data."
                },
                {
                    "role": "user",
                    "content": market_query
                }
            ]
            
            result = self.chat_completion(
                messages=messages,
                model="llama-3.1-sonar-large-128k-online",
                temperature=0.1,
                max_tokens=1500
            )
            
            if result:
                return {
                    "job_title": job_title,
                    "location": location,
                    "industry": industry,
                    "market_analysis": result,
                    "analysis_date": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "source": "perplexity_api"
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Error analyzing job market for {job_title}: {e}")
            return None
    
    def research_industry_trends(
        self,
        industry: str,
        focus_areas: List[str] = None
    ) -> Optional[str]:
        """Research current trends in a specific industry."""
        try:
            focus_text = ""
            if focus_areas:
                focus_text = f" Focus particularly on: {', '.join(focus_areas)}."
            
            trends_query = f"""
            Research current trends and developments in the {industry} industry.{focus_text}
            
            Include information about:
            1. Emerging technologies and innovations
            2. Market challenges and opportunities
            3. Skills in high demand
            4. Key players and market leaders
            5. Future outlook and predictions
            
            Provide recent, factual information with sources.
            """
            
            messages = [
                {
                    "role": "system",
                    "content": "You are an industry analyst providing current market intelligence and trend analysis."
                },
                {
                    "role": "user",
                    "content": trends_query
                }
            ]
            
            return self.chat_completion(
                messages=messages,
                model="llama-3.1-sonar-large-128k-online",
                temperature=0.1,
                max_tokens=1500
            )
            
        except Exception as e:
            logger.error(f"Error researching industry trends for {industry}: {e}")
            return None
    
    def find_similar_companies(
        self,
        company_name: str,
        industry: str = None,
        size: str = None
    ) -> Optional[List[str]]:
        """Find companies similar to the target company."""
        try:
            size_filter = f" of similar size ({size})" if size else ""
            industry_filter = f" in the {industry} industry" if industry else ""
            
            similarity_query = f"""
            Find 5-10 companies similar to "{company_name}"{industry_filter}{size_filter}.
            
            Consider companies that:
            1. Operate in similar markets or industries
            2. Have comparable business models
            3. Are competitors or partners
            4. Have similar company culture or values
            5. Target similar customer segments
            
            Provide just the company names in a numbered list.
            """
            
            messages = [
                {
                    "role": "system",
                    "content": "You are a business analyst helping identify competitor and similar companies."
                },
                {
                    "role": "user",
                    "content": similarity_query
                }
            ]
            
            result = self.chat_completion(
                messages=messages,
                temperature=0.1,
                max_tokens=500
            )
            
            if result:
                # Extract company names from the response
                lines = [line.strip() for line in result.split('\\n') if line.strip()]
                companies = []
                for line in lines:
                    # Remove numbering and extract company name
                    clean_line = line.split('.', 1)[-1].strip()
                    if clean_line and len(clean_line) > 1:
                        companies.append(clean_line)
                
                return companies[:10]  # Limit to 10 companies
            
            return None
            
        except Exception as e:
            logger.error(f"Error finding similar companies to {company_name}: {e}")
            return None

# Global Perplexity client instance
try:
    perplexity_client = PerplexityClient()
except ValueError as e:
    logger.warning(f"Perplexity client not initialized: {e}")
    perplexity_client = None
'''

with open("src/integrations/perplexity_client.py", "w") as f:
    f.write(perplexity_client_content)

print("✓ Created src/integrations/perplexity_client.py")