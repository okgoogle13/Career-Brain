# 12. Create Docker configuration files
dockerfile_content = '''# Enhanced Resume Agent 3.0 - Docker Configuration
FROM python:3.11-slim

# Set environment variables
ENV PYTHONUNBUFFERED=1
ENV PYTHONDONTWRITEBYTECODE=1
ENV DEBIAN_FRONTEND=noninteractive

# Set work directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    build-essential \\
    curl \\
    software-properties-common \\
    git \\
    && rm -rf /var/lib/apt/lists/*

# Create non-root user
RUN useradd --create-home --shell /bin/bash app && \\
    chown -R app:app /app
USER app

# Add user's local bin to PATH
ENV PATH="/home/app/.local/bin:$PATH"

# Copy requirements first for better caching
COPY --chown=app:app requirements.txt .

# Install Python dependencies
RUN pip install --user --no-cache-dir -r requirements.txt

# Copy application code
COPY --chown=app:app . .

# Create necessary directories
RUN mkdir -p /home/app/.resume_agent/vector_db && \\
    mkdir -p /home/app/.resume_agent/exports

# Expose port
EXPOSE 8501

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \\
    CMD curl -f http://localhost:8501/_stcore/health || exit 1

# Default command (can be overridden)
CMD ["streamlit", "run", "web/streamlit_app.py", "--server.port=8501", "--server.address=0.0.0.0", "--browser.gatherUsageStats=false"]
'''

with open("Dockerfile", "w") as f:
    f.write(dockerfile_content)

print("✓ Created Dockerfile")

# Create docker-compose.yml
docker_compose_content = '''version: '3.8'

services:
  resume-agent:
    build: .
    container_name: enhanced-resume-agent
    ports:
      - "8501:8501"
    environment:
      - GOOGLE_GEMINI_API_KEY=${GOOGLE_GEMINI_API_KEY}
      - PERPLEXITY_API_KEY=${PERPLEXITY_API_KEY}
      - DATABASE_URL=sqlite:////home/app/.resume_agent/data.sqlite
      - CHROMADB_PATH=/home/app/.resume_agent/vector_db
      - DEBUG=false
      - LOG_LEVEL=INFO
    volumes:
      - resume_agent_data:/home/app/.resume_agent
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8501/_stcore/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

volumes:
  resume_agent_data:
    driver: local
'''

with open("docker-compose.yml", "w") as f:
    f.write(docker_compose_content)

print("✓ Created docker-compose.yml")

# Create .dockerignore
dockerignore_content = '''# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
pip-wheel-metadata/
share/python-wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# PyInstaller
*.manifest
*.spec

# Virtual environments
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# IDEs
.vscode/
.idea/
*.swp
*.swo
*~

# OS
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# Git
.git
.gitignore

# Docker
Dockerfile*
docker-compose*
.dockerignore

# Documentation
README.md
docs/
*.md

# Tests
tests/
.pytest_cache/
.coverage

# Local data
data/
*.sqlite
*.sqlite3
vector_db/
exports/

# Logs
*.log
logs/

# Temporary files
tmp/
temp/
'''

with open(".dockerignore", "w") as f:
    f.write(dockerignore_content)

print("✓ Created .dockerignore")