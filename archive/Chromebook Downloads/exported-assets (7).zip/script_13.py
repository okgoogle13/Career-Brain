# 14. Create GitHub Actions workflow
github_workflow_content = '''name: CI/CD Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

env:
  PYTHON_VERSION: "3.11"
  REGISTRY: gcr.io
  IMAGE_NAME: enhanced-resume-agent

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v4
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: ${{ env.PYTHON_VERSION }}
    
    - name: Cache pip dependencies
      uses: actions/cache@v3
      with:
        path: ~/.cache/pip
        key: ${{ runner.os }}-pip-${{ hashFiles('**/requirements.txt') }}
        restore-keys: |
          ${{ runner.os }}-pip-
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
        pip install pytest pytest-cov black isort flake8 mypy bandit safety
    
    - name: Run linting
      run: |
        black --check src/ web/ tests/ --line-length=88
        isort --check-only src/ web/ tests/ --profile=black
        flake8 src/ web/ tests/ --max-line-length=88 --exclude=__pycache__
    
    - name: Run type checking
      run: |
        mypy src/ --ignore-missing-imports
    
    - name: Run tests
      run: |
        pytest tests/ -v --cov=src --cov-report=xml --cov-report=term-missing
    
    - name: Upload coverage to Codecov
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage.xml
        flags: unittests
        name: codecov-umbrella
        fail_ci_if_error: false

  security:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v4
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: ${{ env.PYTHON_VERSION }}
    
    - name: Install security tools
      run: |
        python -m pip install --upgrade pip
        pip install bandit safety
    
    - name: Run Bandit security scan
      run: |
        bandit -r src/ -f json -o bandit-report.json || true
    
    - name: Run Safety security scan
      run: |
        safety check --json --output safety-report.json || true
    
    - name: Upload security reports
      uses: actions/upload-artifact@v3
      with:
        name: security-reports
        path: |
          bandit-report.json
          safety-report.json

  build:
    runs-on: ubuntu-latest
    needs: [test, security]
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v4
    
    - name: Set up Docker Buildx
      uses: docker/setup-buildx-action@v3
    
    - name: Log in to Container Registry
      uses: docker/login-action@v3
      with:
        registry: ${{ env.REGISTRY }}
        username: _json_key
        password: ${{ secrets.GCP_SA_KEY }}
    
    - name: Extract metadata
      id: meta
      uses: docker/metadata-action@v5
      with:
        images: ${{ env.REGISTRY }}/${{ secrets.GCP_PROJECT_ID }}/${{ env.IMAGE_NAME }}
        tags: |
          type=ref,event=branch
          type=ref,event=pr
          type=sha,prefix={{branch}}-
          type=raw,value=latest,enable={{is_default_branch}}
    
    - name: Build and push Docker image
      uses: docker/build-push-action@v5
      with:
        context: .
        push: true
        tags: ${{ steps.meta.outputs.tags }}
        labels: ${{ steps.meta.outputs.labels }}
        cache-from: type=gha
        cache-to: type=gha,mode=max

  deploy:
    runs-on: ubuntu-latest
    needs: build
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v4
    
    - name: Authenticate to Google Cloud
      uses: google-github-actions/auth@v1
      with:
        credentials_json: ${{ secrets.GCP_SA_KEY }}
    
    - name: Set up Cloud SDK
      uses: google-github-actions/setup-gcloud@v1
    
    - name: Deploy to Cloud Run
      run: |
        gcloud run deploy enhanced-resume-agent \\
          --image ${{ env.REGISTRY }}/${{ secrets.GCP_PROJECT_ID }}/${{ env.IMAGE_NAME }}:latest \\
          --platform managed \\
          --region us-central1 \\
          --allow-unauthenticated \\
          --max-instances 1 \\
          --memory 1Gi \\
          --cpu 1 \\
          --timeout 3600 \\
          --set-env-vars="DATABASE_URL=sqlite:////tmp/data.sqlite,CHROMADB_PATH=/tmp/vector_db" \\
          --set-secrets="GOOGLE_GEMINI_API_KEY=gemini-api-key:latest,PERPLEXITY_API_KEY=perplexity-api-key:latest"
    
    - name: Get service URL
      run: |
        SERVICE_URL=$(gcloud run services describe enhanced-resume-agent --region=us-central1 --format='value(status.url)')
        echo "Service deployed at: $SERVICE_URL"
        echo "SERVICE_URL=$SERVICE_URL" >> $GITHUB_ENV
    
    - name: Create deployment summary
      run: |
        echo "## 🚀 Deployment Summary" >> $GITHUB_STEP_SUMMARY
        echo "- **Service**: Enhanced Resume Agent 3.0" >> $GITHUB_STEP_SUMMARY
        echo "- **URL**: ${{ env.SERVICE_URL }}" >> $GITHUB_STEP_SUMMARY
        echo "- **Region**: us-central1" >> $GITHUB_STEP_SUMMARY
        echo "- **Image**: ${{ env.REGISTRY }}/${{ secrets.GCP_PROJECT_ID }}/${{ env.IMAGE_NAME }}:latest" >> $GITHUB_STEP_SUMMARY

  notify:
    runs-on: ubuntu-latest
    needs: [test, security, build, deploy]
    if: always()
    
    steps:
    - name: Notify deployment status
      run: |
        if [ "${{ needs.deploy.result }}" == "success" ]; then
          echo "✅ Deployment successful!"
        else
          echo "❌ Deployment failed or skipped"
        fi
'''

# Create the .github/workflows directory and file
with open(".github/workflows/ci-cd.yml", "w") as f:
    f.write(github_workflow_content)

print("✓ Created .github/workflows/ci-cd.yml")

# Create a basic test file structure
test_init_content = '''"""
Test suite for Enhanced Resume Agent 3.0
"""
'''

with open("tests/__init__.py", "w") as f:
    f.write(test_init_content)

# Create unit test init
with open("tests/unit/__init__.py", "w") as f:
    f.write("# Unit tests\n")

# Create integration test init  
with open("tests/integration/__init__.py", "w") as f:
    f.write("# Integration tests\n")

# Create sample test file
sample_test_content = '''"""
Sample tests for Enhanced Resume Agent 3.0
"""

import pytest
from unittest.mock import Mock, patch
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from utils.config import Config
from utils.validators import validate_email, validate_phone, validate_url

class TestValidators:
    """Test validation functions."""
    
    def test_validate_email_valid(self):
        """Test valid email validation."""
        assert validate_email("test@example.com") == True
        assert validate_email("user.name+tag@domain.co.uk") == True
    
    def test_validate_email_invalid(self):
        """Test invalid email validation."""
        assert validate_email("invalid-email") == False
        assert validate_email("@domain.com") == False
        assert validate_email("user@") == False
        assert validate_email("") == False
        assert validate_email(None) == False
    
    def test_validate_phone_valid(self):
        """Test valid phone validation."""
        assert validate_phone("1234567890") == True
        assert validate_phone("+1 (555) 123-4567") == True
        assert validate_phone("555-123-4567") == True
    
    def test_validate_phone_invalid(self):
        """Test invalid phone validation."""
        assert validate_phone("123") == False
        assert validate_phone("abc-def-ghij") == False
        assert validate_phone("") == False
        assert validate_phone(None) == False
    
    def test_validate_url_valid(self):
        """Test valid URL validation."""
        assert validate_url("https://example.com") == True
        assert validate_url("http://test.org") == True
        assert validate_url("https://sub.domain.com/path") == True
    
    def test_validate_url_invalid(self):
        """Test invalid URL validation."""
        assert validate_url("not-a-url") == False
        assert validate_url("ftp://example.com") == False  # We only accept http/https
        assert validate_url("") == False
        assert validate_url(None) == False

class TestConfig:
    """Test configuration management."""
    
    def test_config_initialization(self):
        """Test config can be initialized."""
        config = Config()
        assert config.app.name is not None
        assert config.app.version is not None
    
    @patch.dict('os.environ', {'APP_DEBUG': 'true'})
    def test_config_environment_override(self):
        """Test config respects environment variables."""
        config = Config()
        # Note: This test might need adjustment based on actual implementation
        assert config.app.debug in [True, False]  # Should be a boolean

class TestIntegration:
    """Integration tests."""
    
    @pytest.mark.integration
    def test_database_connection(self):
        """Test database connection works."""
        try:
            from data.database import db_manager
            with db_manager.get_session() as session:
                # Simple connection test
                assert session is not None
        except Exception as e:
            pytest.skip(f"Database not available: {e}")
    
    @pytest.mark.integration
    def test_vector_store_initialization(self):
        """Test vector store can be initialized."""
        try:
            from data.vector_store import VectorStoreManager
            vector_store = VectorStoreManager()
            stats = vector_store.get_collection_stats()
            assert isinstance(stats, dict)
            assert 'experiences' in stats
            assert 'job_descriptions' in stats
        except Exception as e:
            pytest.skip(f"Vector store not available: {e}")

@pytest.fixture
def mock_user_data():
    """Fixture for mock user data."""
    return {
        'id': 1,
        'email': 'test@example.com',
        'full_name': 'Test User',
        'phone': '555-123-4567',
        'linkedin_url': 'https://linkedin.com/in/testuser',
        'github_url': 'https://github.com/testuser',
        'location': 'Test City, TC'
    }

@pytest.fixture
def mock_work_experience():
    """Fixture for mock work experience data."""
    return {
        'id': 1,
        'company_name': 'Test Company',
        'job_title': 'Software Engineer',
        'start_date': '2023-01',
        'end_date': '2024-01',
        'location': 'Test City, TC',
        'description': 'Developed software applications',
        'achievements': ['Improved performance by 50%', 'Led team of 3 developers'],
        'technologies': ['Python', 'JavaScript', 'React'],
        'is_current': False
    }

# Parameterized tests
@pytest.mark.parametrize("email,expected", [
    ("valid@email.com", True),
    ("invalid-email", False),
    ("another.valid+email@domain.co.uk", True),
    ("", False),
])
def test_email_validation_parameterized(email, expected):
    """Parameterized test for email validation."""
    assert validate_email(email) == expected

if __name__ == "__main__":
    pytest.main([__file__])
'''

with open("tests/test_basic.py", "w") as f:
    f.write(sample_test_content)

print("✓ Created test files")
print("✓ Created .github/workflows/ci-cd.yml")