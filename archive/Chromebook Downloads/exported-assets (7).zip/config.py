"""
Configuration management for Enhanced Resume Agent 3.0.
"""

import os
import yaml
from pathlib import Path
from typing import Any, Dict, Optional
from pydantic import BaseSettings, Field
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class DatabaseConfig(BaseSettings):
    """Database configuration settings."""
    url: str = Field(default="sqlite:///~/.resume_agent/data.sqlite")
    echo: bool = Field(default=False)

    class Config:
        env_prefix = "DATABASE_"

class APIConfig(BaseSettings):
    """API configuration settings."""
    gemini_api_key: str = Field(default="", env="GOOGLE_GEMINI_API_KEY")
    perplexity_api_key: str = Field(default="", env="PERPLEXITY_API_KEY")

    class Config:
        env_prefix = "API_"

class VectorStoreConfig(BaseSettings):
    """Vector store configuration settings."""
    type: str = Field(default="chromadb")
    chromadb_path: str = Field(default="~/.resume_agent/vector_db")

    class Config:
        env_prefix = "VECTOR_STORE_"

class AppConfig(BaseSettings):
    """Application configuration settings."""
    name: str = Field(default="Enhanced Resume Agent 3.0")
    version: str = Field(default="3.0.0")
    debug: bool = Field(default=False)
    log_level: str = Field(default="INFO")
    secret_key: str = Field(default="change-this-in-production")

    class Config:
        env_prefix = "APP_"

class StreamlitConfig(BaseSettings):
    """Streamlit configuration settings."""
    port: int = Field(default=8501)
    host: str = Field(default="localhost")

    class Config:
        env_prefix = "STREAMLIT_"

class DocumentConfig(BaseSettings):
    """Document generation configuration."""
    max_resume_pages: int = Field(default=2)
    default_theme: str = Field(default="professional_classic")
    output_format: str = Field(default="pdf")

    class Config:
        env_prefix = "DOCUMENT_"

class Config:
    """Main configuration class."""

    def __init__(self, config_path: Optional[Path] = None):
        """Initialize configuration."""
        self.app = AppConfig()
        self.database = DatabaseConfig()
        self.api = APIConfig()
        self.vector_store = VectorStoreConfig()
        self.streamlit = StreamlitConfig()
        self.document = DocumentConfig()

        # Load additional config from YAML if provided
        if config_path and config_path.exists():
            self._load_yaml_config(config_path)

    def _load_yaml_config(self, config_path: Path) -> None:
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as f:
                yaml_config = yaml.safe_load(f)

            # Update configurations with YAML values
            for section, values in yaml_config.items():
                if hasattr(self, section) and isinstance(values, dict):
                    config_obj = getattr(self, section)
                    for key, value in values.items():
                        if hasattr(config_obj, key):
                            setattr(config_obj, key, value)

        except Exception as e:
            print(f"Warning: Could not load YAML config: {e}")

    def validate(self) -> bool:
        """Validate configuration settings."""
        errors = []

        # Check required API keys
        if not self.api.gemini_api_key:
            errors.append("GOOGLE_GEMINI_API_KEY is required")

        if not self.api.perplexity_api_key:
            errors.append("PERPLEXITY_API_KEY is required")

        # Check directories exist
        db_path = Path(self.database.url.replace("sqlite:///", "")).parent
        if not db_path.exists():
            try:
                db_path.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                errors.append(f"Cannot create database directory: {e}")

        vector_path = Path(self.vector_store.chromadb_path).expanduser()
        if not vector_path.exists():
            try:
                vector_path.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                errors.append(f"Cannot create vector store directory: {e}")

        if errors:
            print("Configuration errors:")
            for error in errors:
                print(f"  - {error}")
            return False

        return True

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "app": self.app.dict(),
            "database": self.database.dict(),
            "api": {"gemini_api_key": "***", "perplexity_api_key": "***"},  # Hide secrets
            "vector_store": self.vector_store.dict(),
            "streamlit": self.streamlit.dict(),
            "document": self.document.dict()
        }

# Global configuration instance
config = Config()
